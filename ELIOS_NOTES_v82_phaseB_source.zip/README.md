# ELIOS NOTES

An independent Android notes application built with Kotlin, Jetpack Compose and Room.
Local-first, no account, no cloud, no ads.

## Project state (database schema v4, app 0.6.0 / versionCode 33; v82 handwriting smoothing preview and build hardening)

> **Build status:** the Android app has not been compiled or run in this environment. Java and standalone `kotlinc` are available, but Gradle, the Gradle Wrapper JAR, Android SDK and ADB are not. Focused standalone Kotlin smoke checks were run for selected pure policies/codecs; Android/Compose and Room integration remain unverified until GitHub CI is green and the app has been tried on devices.

### v79–v81 page-management, paper and input additions
- Added a page overview dialog with scaled page previews, text/ink/attachment summaries, direct navigation, explicit move-up / move-down controls, and long-press drag-and-drop reordering with edge auto-scroll.
- Added transactional page duplication. The source page is flushed before duplication; the duplicate receives a fresh page ID and fresh element IDs, while preserving page geometry, template, background, z-order, coordinates, payload versions, and opaque/future payload JSON.
- Media references are intentionally shared because attachment blobs are content-addressed. Removing a reference from one page continues to rely on repository reference counting before deleting a shared blob.
- The page duplication operation reloads the persisted document after the transaction. If the save barrier or transaction fails, the original page remains intact and the UI reports failure.
- The note-body search mirror is rebuilt only when every page TEXT payload is decodable. Newer/corrupt payloads and legacy notes without page-text rows no longer get replaced with an empty mirror during save/duplicate operations.
- Added Room instrumentation regression cases for cloned text, image reference, unknown future elements, fresh identities, presentation metadata, search-body mirror, and rejection of a page belonging to another note.
- Drag reorder validates the complete stable-ID list, flushes pending edits, commits the full order in one repository transaction, and updates observable page order only after persistence succeeds. Failed or invalid reorders leave the in-memory order unchanged.
- Added pure pointer-device arbitration: stylus/eraser/mouse ink remains enabled when finger drawing is disabled; touch ink follows the existing user setting; lasso selection remains finger-accessible; simultaneous touch pointers are suppressed while a stylus/eraser stroke or lasso gesture is active. This is limited concurrent-touch palm mitigation, not a claim of hardware palm detection.
- No Room schema version change or migration was needed. UI gesture behavior and stylus arbitration still require Compose build and physical-device validation.

### Build handoff
- The source archive is a project snapshot, not an APK. Its files are stored at the ZIP root (no enclosing project directory). Two GitHub paths are supported: (A) extract and upload all contents to the repository root, where `.github/workflows/build-apk.yml` runs; or (B) upload `ELIOS_NOTES_v82_source.zip` as a single repository file and separately copy `GITHUB_BOOTSTRAP/build-from-source-zip.yml` to `.github/workflows/build-from-source-zip.yml`. The bootstrap workflow validates and extracts the ZIP before building.
- Both workflows run lint, JVM tests, Debug APK assembly, Room schema verification and emulator instrumentation. A green workflow publishes an installable **Debug** APK plus its SHA-256 checksum as a GitHub Actions artifact. A production-signed release APK requires a separately configured signing keystore and protected GitHub secrets; release signing is not yet claimed ready.
- The project stores the pinned Gradle distribution URL but not the Gradle Wrapper JAR/scripts. Both workflows install Gradle 8.13 explicitly and do not depend on `./gradlew`.

### Implemented in source (verification status is stated per feature)
- Search refinement in v75: Arabic diacritics and tatweel are ignored for matching; common alef variants and alef-maqsura/ya are normalized; repeated whitespace and Latin case are normalized. This affects comparison only and never rewrites saved note/folder content.
- Library: notes, search across note titles/content and folder names (with a clear-search action and context-specific empty states), favorites, pinning, archive, trash (restore / delete forever with confirmation / 30-day auto-purge; moving a note to trash now asks for confirmation from both the library and editor), folders, sorting. Folder deletion now explicitly explains that notes are retained and moved back to All notes; it requires confirmation.
- **Data safety:** no `REPLACE` upserts on `notes` (it cascade-deleted pages and ink). One ordered save queue + one repository lock. Failed saves are retried up to 3 times; if they still fail, a visible banner offers an explicit Retry action that re-queues the current title and all page snapshots. A retried snapshot can never overwrite a newer one. Unreadable (corrupt / newer-version) text or ink payloads are shown as empty but are **never overwritten or deleted** by autosave. Legacy v1 notes have their text copied into page 1 on first open so other pages can no longer replace it.
- Safe migrations 1 -> 2 -> 3 -> 4 (columns added only if missing).
- Pages: individual or continuous scroll, A4 portrait/landscape, templates, page colour, indexed insertion, move up/down, thumbnail overview, long-press drag reorder, duplication, and transient viewport zoom/pan (device gesture validation pending). A page **grows** when its text is taller than the page (on screen and in the PDF) instead of clipping it. Text lines sit on the 32-unit template grid.
- Ink engine: pen, pencil, marker, highlighter, pressure when reported, finger/stylus handling with concurrent-touch suppression while a stylus is active (limited palm mitigation; device validation pending), partial and whole-stroke eraser (the eraser now sweeps the whole path between touch samples), freehand lasso selection, moving, in-memory copy/paste with fresh stroke IDs, deleting selected ink, undo/redo (200 steps), compact versioned payloads. v82 adds a preview-first, three-strength geometric smoothing operation; it preserves stroke identity/style/endpoints and is applied as one undoable edit. It is conservative jitter smoothing, not semantic handwriting normalization, and Arabic/English visual quality still needs device/user-corpus review.
- PDF export (vector, system file picker, re-opened with PdfRenderer to verify the page count; a broken file is deleted).
- **Attachments (partial):** system picker imports files into private SHA-256-addressed storage; metadata is persisted as page elements; attachments remain visible after reopening, image attachments show bounded-memory thumbnails with an in-app enlarged preview dialog, sizes are human-readable, files can be opened through a restricted FileProvider URI after hash verification, and can be removed with shared-blob reference protection. Full-resolution editing/placement, audio/video playback and PDF viewing are still pending. ZIP restore is now implemented in source but still requires end-to-end Android validation.
- Initial handwriting-to-text path: on-device ML Kit Digital Ink Recognition for Arabic and English strokes, line grouping, editable review before insertion, and preservation of the original ink. Recognition now offers Automatic / Arabic / English modes; selecting one language downloads only that model, while Automatic uses both. Models are downloaded over Wi-Fi on first use; after download, recognition runs offline. This is code written, not device-tested or accuracy-benchmarked yet.
- Ink payload validation: malformed, future-tool, non-finite, out-of-range, or oversized stroke payloads are rejected instead of being silently reinterpreted; invalid imported ink remains protected from autosave overwrite.
- **Backup / restore (partial):** JSON backup/restore remains available for notes without media; the JSON file is not encrypted. A separate **Full backup (ZIP)** action now exports metadata plus referenced attachment blobs and reopens the archive to verify it. ZIP restore/import is now wired through the system document picker as a non-destructive merge: archive and metadata validation, SHA-256 verification, attachment installation, stable note IDs for idempotent repeat imports, collision-safe folder mapping, regenerated page/element IDs, and a single Room transaction. This is source-level only; process-death recovery, transaction fault injection, Compose build and device round-trip testing remain required before treating ZIP restore as verified.
- Arabic (default) and English. Dark theme follows the system.

### Not implemented yet
Rich-text formatting, full PDF import/annotation/merge/split, audio recording/playback, video playback, tags, note lock & encryption, text flowing across pages, pen tilt / S-Pen button, hardware-specific palm detection and stylus-button/tilt support. Drag reorder and safe page duplication are implemented in source but await Android/physical-device validation. ZIP attachment backup/restore has source implementation but still needs end-to-end Android validation. Handwriting recognition still needs real-device Arabic/English accuracy evaluation; camera/photo OCR and reliable mixed-language segmentation are not implemented. Automatic mode still selects one whole candidate per line and needs real-device mixed-script validation.

### Known limits
- Changing orientation applies to empty pages only (so ink is never cut off).
- Continuous-scroll mode shows pages without gaps, but a stroke cannot cross a page boundary.
- Black ink on the dark page colour is invisible; pick another colour.
- Room schema JSON is configured for KSP export and the updated CI now requires a generated schema artifact. The baseline schema still needs to be retrieved from a green CI run and committed after review.
- Library versions (AGP 8.13.2, Kotlin 2.2.21, KSP 2.3.10, Compose BOM 2025.09.00 ...) could not be checked offline.

## v80 — page drag reorder and stylus/touch arbitration (0.5.8 / versionCode 31)

- Added long-press drag-and-drop page reordering to the page overview, with a dedicated drag handle, visible-row target detection and edge auto-scroll. Existing move-up/down controls remain available as an alternative.
- Reordering validates a complete unique page-ID order, waits for the editor save barrier, commits the order through the existing Room transaction, and only then updates the in-memory page list. Failed persistence leaves the displayed page order unchanged.
- Added pure `InkPointerPolicy` rules used by both ink and lasso layers: stylus/eraser/mouse can initiate input independently of the finger-drawing preference; touch follows that preference; concurrent touch contacts are consumed while a stylus/eraser gesture is active.
- This is concurrent-touch suppression, not universal hardware palm detection. A standalone touch contact cannot reliably be identified as a palm across Android devices; device-specific validation remains required.
- Added JVM policy tests and page-order metadata-preservation regression coverage. Tests are source-added, not Gradle-executed in this environment.
- No Room schema or migration change. Existing page IDs, element IDs, page payloads, attachment references and backup format are unchanged.
- Added a GitHub bootstrap workflow option for the case where the repository stores the source ZIP as a single file: upload the bootstrap workflow separately to `.github/workflows/build-from-source-zip.yml`; it safely validates/extracts the ZIP, builds the project, runs emulator tests, and publishes the Debug APK artifact.

Verification: ZIP/CRC, path/duplicate-entry checks, extracted-file equivalence, XML parsing, translation parity, standalone pointer-policy execution and static diff checks performed. Gradle, Compose compilation, JUnit, Room instrumentation, APK build and physical-device tests remain unrun because this environment lacks Gradle and Android SDK/ADB.

## v76 phase 1 — parity baseline and execution roadmap

- Accepted target: Samsung Notes functional/experience parity with an original ELIOS identity; handwriting recognition plus reversible handwriting beautification; local-only storage and manual portable backup; phones and tablets with optional stylus capabilities.
- Added `V76_PHASE1_AUDIT.md`: source-backed inventory of implemented/partial/missing features, architecture/data-safety constraints, priority risks, and v77–v83 release gates.
- This phase is intentionally audit/planning-only: no production Kotlin, Room schema, migration, persisted payload, backup format, or UI behavior was changed. Existing functionality is retained.
- Android build, Gradle/JUnit, lint, Room instrumentation and physical-device tests remain not run in this environment; CI must be green before feature work is treated as verified.

## Build

Compose BOM is pinned to `2025.09.00` to avoid the Compose 1.12.x requirement for compileSdk 37 / AGP 9. The project remains on compileSdk 36 / AGP 8.13.2.
Open `ELIOS_NOTES` in a current Android Studio, let Gradle sync, run the `app` configuration.
The archive has no Gradle wrapper JAR; generate one with the version in `gradle/wrapper/gradle-wrapper.properties`.
Library versions in `build.gradle.kts` could not be verified offline and should be checked on first sync.

CI gates now include `:app:lintDebug`, `:app:testDebugUnitTest`, `:app:assembleDebug`, generated Room schema verification, and `:app:connectedDebugAndroidTest` on an API 36 emulator. These are workflow requirements; this local environment has not executed them.

Settings: minSdk 23, compile/target SDK 36, Java/Kotlin 17.

## Principles
- Local-first storage; no AI features; independent identity and assets.
- A feature counts as complete only after it has been implemented **and tested**.

## Getting an APK without installing anything
Push this folder to a GitHub repository. The workflow in `.github/workflows/build-apk.yml`
sets up JDK 17, Android SDK 36 and Gradle 8.13, runs lint and JVM unit tests, builds and verifies
`app/build/outputs/apk/debug/app-debug.apk`, then publishes it under Actions -> Artifacts as
`ELIOS_NOTES-v82-debug-apk`. Pull requests and pushes to `main` run the same checks. A green workflow confirms compilation and JVM tests, not visual parity or device-specific stylus behavior; those still require device testing.

## v46 source update
- Added a freehand lasso selection tool for ink strokes, including crossing-segment hit testing, selection outlines, drag-to-move, and undo/redo integration.
- Added JVM tests for inside/outside selection, crossing strokes, selected IDs, and preserving stroke identity/style/pressure after moving.
- Improved lasso hit-testing to account for the visible width of thick strokes near the selection boundary, with regression coverage for thick-vs-thin edge cases.
- This is a source-level change only. The Android/Compose project has not been compiled or run on a device in this environment; do not treat the new UI as verified until CI and device testing pass.


## v47 source update
- Hardened stroke serialization and parsing against non-finite coordinates/pressure, invalid widths, unknown tool names, integer overflow, and excessively large payloads/point arrays. Rejected payloads return `null` and therefore remain protected by the existing repository safeguards.
- Changed CI so JVM tests are mandatory and run before APK assembly; a failing test no longer produces a misleading successful APK artifact. Added pull-request validation and concurrency cancellation.
- This is a source-level update. It has not yet been compiled with the Android Gradle toolchain or exercised on a physical device in this environment.


## v48 source update (app 0.3.2)
- Added lasso-selection actions in the editor: copy, paste with a small offset, and delete.
- Pasted strokes receive new IDs and preserve tool, colour, width, point positions, and pressure. Delete and paste are integrated with undo/redo and autosave.
- Added JVM tests for clipboard filtering, independent pasted identities, style/pressure preservation, and clearing the clipboard.
- Source-level only: this environment still lacks the Android SDK/Gradle toolchain, so no Android build or device test is claimed.


## v49 source review and update (app 0.3.2)

### Review of v46–v48 before changing code
- Confirmed the v46 lasso geometry and selection path remain present.
- Confirmed v47 ink payload validation and the CI test gate remain present.
- Confirmed v48 copy/paste/delete actions are wired into the editor session undo/redo and autosave path.
- Confirmed the documented feature gaps remain real: rich text, media, PDF import/annotation, audio, handwriting recognition, tags, and note locking/encryption are not implemented. No parity or full-completion claim is made.
- Corrected the next change scope to strengthen clipboard data integrity rather than introducing a large unverified database/schema change.

### v49 changes
- Clipboard copies now take a defensive snapshot of stroke points, so a mutable source list cannot silently mutate copied content.
- Pasted strokes reject generated IDs that are blank, reused, or collide with source IDs.
- Pasted coordinates are checked after applying offsets, preventing finite offsets from overflowing the supported coordinate range.
- Added regression tests for defensive copying, multiple unique IDs, ID collisions, and coordinate overflow.
- Bumped app version to 0.3.2 / versionCode 5.

### Verification status
- Standalone Kotlin compilation and smoke tests for the clipboard are run as part of this source update.
- The full Android Gradle build, JUnit suite, Room schema generation, and physical-device testing remain unverified.


## v50 source update (app 0.3.3)
- Added a handwriting recognition action for the current page.
- Uses ML Kit Digital Ink Recognition with Arabic (`ar`) and English (`en-US`) language models. Both are evaluated per detected handwriting line and the likely script candidate is selected.
- Language packs are fetched over Wi-Fi on first use (roughly 20 MB per language); subsequent recognition runs on-device without an internet connection. No note content is uploaded.
- Recognition results are editable in a review dialog. Insertion appends text without deleting or replacing original strokes.
- Existing v1 ink records do not contain point timestamps; the recognizer uses the supported untimed-point form. This can affect accuracy.
- The line grouping and candidate-selection heuristics are initial implementation choices, not proven accuracy guarantees. Device tests with real Arabic, English, mixed-script and varied handwriting samples remain mandatory.
- Source-level only. Android Gradle compilation, model download, inference, and device accuracy are not verified in this environment.


## v51 source update (app 0.3.4)
- Reviewed the supplied v50 archive before changes. The uploaded archive was v50 / app 0.3.3 / versionCode 6; no v51 archive was attached in that handoff.
- Extracted Arabic/English candidate selection into a pure, independently testable helper.
- Replaced raw cross-language character-count comparison with per-candidate target-script purity.
- Added JVM regression tests for empty candidates, Arabic diacritics, Latin-script evidence, unequal candidate lengths, and deterministic ties.
- Bumped app version to 0.3.4 / versionCode 7.
- The original specification is available in the Library and was re-opened for this review.
- Important: this is still a first-pass heuristic. When both recognizers return clean text in their own scripts, confidence is not reliably comparable and the deterministic tie falls back to Arabic. Mixed Arabic/English on the same line is not reliably segmented. Physical-device recognition tests and the full Android build remain outstanding.

## v52 source update (app 0.3.7)
- Re-reviewed v51 source and the v1.1 engineering specification before editing.
- Replaced narrow Unicode block checks with Unicode script classification for Arabic and Latin letters.
- Iterates by Unicode code point rather than UTF-16 `Char`, avoiding incorrect splitting of supplementary-plane letters.
- Combining marks and punctuation do not affect the script-purity ratio.
- Added regression tests for Arabic Extended-A, Latin Extended, Arabic combining marks, and supplementary-plane Latin letters.
- Bumped app version to 0.3.5 / versionCode 8.
- Seven standalone Kotlin smoke checks passed. Full Android Gradle build, JUnit execution, Room schema generation, ML Kit model download, and device handwriting tests remain unverified.
- The cross-language tie fallback remains Arabic by design pending a user-selectable ambiguous-line review flow; mixed-script line segmentation is still outstanding.


## v53 source update (app 0.3.7)
- Fixed recognition insertion so reviewed output is appended using a real newline, not the two literal characters `\` and `n`.
- Extracted the merge operation into a pure helper and added JVM regression tests for newline correctness, preserving existing text, blank recognition output, and empty-page insertion.
- Source-level change only. Full Android Gradle/JUnit execution and device tests remain pending because this environment has no Android SDK, Gradle distribution, or network access.


## v56 source update (0.3.8 / build 11)

- Added a user-facing Rename note action to active-library and archive note menus.
- Added title normalization (trim, remove control characters, reject blank names, maximum 120 characters).
- Added JVM tests for the title policy.
- The editor title remains directly editable.
- No Room schema change was needed. Android build and device UI tests remain pending.

## v57 source update (0.3.9 / build 12)

- Added a private, content-addressed attachment blob store foundation. Imports stream into a temporary file, enforce a configurable size limit, compute SHA-256, sync the completed bytes, and publish only after a successful copy.
- Added validated attachment references, safe display-name/extension normalization, exact-byte reads, existence checks, and explicit blob deletion.
- Added JVM tests for byte-for-byte round trips, content deduplication, oversized input cleanup, and display-name sanitization.
- This is the storage foundation only: picker integration, Room element metadata, page rendering, deletion/reference counting, and binary backup/restore are not yet complete. Do not present image/PDF/audio/video attachments as user-facing implemented features yet.
- Bumped app version to 0.3.9 / versionCode 12.


## v58 attachment integration (0.4.0 / build 13)

- Connected the private attachment store to `NotesRepository` and the editor's Android document picker.
- Imported files are copied into app-private storage, referenced from the selected page through versioned Room element metadata, and shown in that page's attachment list after load/reopen. Supported metadata categories include images, video, audio, PDF and generic files.
- Failed database commits attempt to remove the newly imported unreferenced blob. Removal API checks remaining metadata references before deleting shared content.
- The existing JSON backup format cannot yet package binary blobs. To avoid silently producing incomplete backups, backup export and restore verification now reject media-bearing backups until a versioned binary package format is implemented.
- This milestone does not yet render image previews, play media, open PDFs, provide attachment removal controls, or include binary blobs in backup/restore.
- Full Android build, Room integration tests and device picker tests remain pending in an environment without Android SDK/Gradle.


## v59 attachment lifecycle follow-up (app 0.4.1 / versionCode 14)
- Attachment elements now retain their Room element IDs in the decoded page model, so a specific attachment can be removed without guessing by filename or content hash.
- The editor exposes remove and open actions. Open uses a non-exported AndroidX `FileProvider` URI with temporary read permission; the private file is SHA-256 verified before handing it to another app.
- Added an integrity regression test that detects same-length content tampering.
- Corrected and validated the Android manifest XML while adding the provider path declaration.
- Source checks: attachment storage Kotlin compiled with the installed standalone compiler; 5/5 independent integrity smoke checks passed; all 6 XML files parsed; Arabic/English resources have 125 matching keys.
- Not verified: Gradle/JUnit, Compose/Android compilation, runtime FileProvider resolution, third-party viewer behavior, Android device tests, inline previews/playback, and complete binary backup/restore.

## v60 source update — binary backup archive foundation (not yet integrated)
- Added a versioned ZIP archive codec with a manifest, streamed metadata and binary entries, bounded sizes, strict entry-name validation, duplicate detection, and SHA-256 verification during staging extraction.
- Added JVM tests for archive round-trip, hash integrity, corrupt binary rejection, invalid archive rejection, and duplicate-entry handling.
- This is a foundational component only. It is **not yet wired** into `NotesRepository` or the Android backup/restore picker. The existing JSON backup remains active and still blocks media-containing backups. Do not treat binary backup/restore as available yet.
- Standalone Kotlin compilation and a separate 4/4 smoke-check harness passed. No Gradle/JUnit/Android build or device test was run.


## v62 — archive metadata integrity hardening (partial)
- Bumped the internal archive format version to 2 (this is not the Android app version).
- The manifest now records the metadata JSON SHA-256 and exact byte count; extraction verifies both before returning staged content.
- Added regression tests for metadata tampering, unsupported archive versions, and staging cleanup, alongside the existing blob integrity tests.
- The archive codec remains unintegrated with repository backup/restore and the Android document picker. Existing JSON backup behavior and attachment-export block remain unchanged.
- Verification performed in this environment: standalone Kotlin compilation of the codec, 3/3 archive round-trip smoke checks, and 2/2 integrity-rejection smoke checks. Full Gradle/JUnit, Android build, and device tests remain unverified.


## v63 source review and attachment-storage repair

- Reviewed the v62 archive codec, JSON backup/restore path, Room schema v4, repository attachment lifecycle, and Android picker wiring before editing.
- Found a data-integrity defect in `AttachmentStorage.import`: when a content-addressed destination already existed, the code compared only byte length. A same-length corrupted blob could therefore be accepted and returned as if it were valid.
- Fixed import deduplication to verify the existing destination's SHA-256. A damaged destination is quarantined and replaced only after the newly streamed temporary file has been fully written and hashed; if publication fails, the prior file is restored where possible.
- Added a regression test that corrupts a stored file without changing its length, re-imports the original bytes, and verifies exact repair plus temporary-file cleanup.
- Verification actually performed: standalone Kotlin compilation of `AttachmentStorage.kt`; executable JVM smoke test for same-length corruption repair; XML parsing (5 resource XML files); Arabic/English string-key parity (125/125).
- Not performed: Gradle/JUnit suite, Android build, instrumentation, device testing, or binary archive integration. App version remains 0.4.1 / versionCode 14.
- Binary archive v2 remains a codec foundation only. Android backup UI still uses JSON and backup remains blocked when media references exist; no end-to-end binary backup/restore claim is made.


## v64 — binary backup export integration (partial)
- Added a repository export path that snapshots folders, notes, pages and all elements, extracts every media reference, verifies each referenced private blob by SHA-256, and writes metadata plus deduplicated content-addressed blobs through the version-2 streaming ZIP archive codec.
- Added archive verification that extracts to temporary staging, verifies archive metadata/blob checksums, parses the embedded backup JSON, and checks that the referenced attachment set exactly matches packaged blobs. Staging is removed in a finally block.
- Added a separate Android SAF “Full backup (ZIP)” export action. It reopens and verifies the written document and deletes the destination document on failure. Existing JSON backup and restore remain unchanged.
- App version advanced to 0.4.2 / versionCode 15 because full ZIP export is now user-accessible.
- ZIP restore/import is now integrated in source with validation, ID remapping, transactional Room merge and guarded cleanup. Runtime validation, process-death recovery/orphan reconciliation, storage-failure injection and full round-trip tests remain pending. Do not claim binary backup/restore production-complete.
- Verification in this environment: standalone Kotlin codec/storage checks and resource/ZIP checks only; Gradle, JUnit, Android build and device tests were not run.


## v65 — safer everyday note deletion
- Moving a note to trash from the library now opens a confirmation dialog instead of immediately changing its location.
- Moving a note to trash from inside the editor now uses the same confirmation, and only then flushes pending edits and queues the move.
- The confirmation explains the 30-day recovery window; permanent deletion and empty-trash confirmations remain separate. The editor title field now sanitizes control characters and caps live drafts at the same 120-character limit used by rename dialogs, while still allowing an empty title to display as Untitled.
- Arabic and English resources updated with matching keys.
- App version advanced to 0.4.3 / versionCode 16 for this user-visible interaction change.
- Verification: source-level path checks, XML parsing, and translation-key parity only. Gradle, Compose compilation, JUnit, Android runtime and device tests were not run.


## v67 — await safe persistence before leaving the editor (0.4.5 / build 18)

- Review finding: editor Back actions called asynchronous `flush()` and immediately navigated away. A pending save could still be queued or fail after the editor had disappeared.
- Added `flushAndAwait()`: it cancels the debounce, snapshots the complete current document (including title and all pages), assigns fresh sequence numbers so older queued snapshots cannot overwrite it, and waits for the ordered database queue. Cancellation is propagated; on write failure, dirty state is restored and the editor remains open.
- System Back and the app-bar Back action now wait for the save result. A blocking progress dialog prevents edits during the final snapshot. If saving fails, navigation is cancelled and the user receives a clear message.
- Moving a note to Trash now awaits a successful full-document save before performing the soft-delete. A failed save leaves the note active and open.
- Added matching Arabic and English feedback strings.
- Verification boundary: source inspection and focused static checks only; Gradle/Compose/JUnit and Android process-death/device tests remain unrun. This is not a verified APK.


## v68 — safer folder management and library clarity (2026-11-16)
- Review found that deleting a folder immediately detached its notes without confirmation. The folder action now opens a localized confirmation explaining that only the folder is deleted and its notes remain in All notes. Cancel is non-destructive; confirm uses the existing repository transaction that detaches notes before deleting the folder.
- If the folder currently being viewed is deleted, the library returns to the Folders tab rather than leaving a stale folder selection.
- Removed a duplicate app-name title rendered twice in the library top bar.
- Advanced app version to 0.4.6 / versionCode 19.
- Validation boundary: source assertions, XML parsing, translation parity and ZIP integrity are checked for this package. Gradle/Compose/JUnit, Android runtime and physical-device tests remain unrun; no APK build is claimed.


## v69 — predictable library search (2026-11-16)
- Fixed a usability defect: the search field remained visible in the Folders tab but did not filter the folder list. Folder search now filters folder names and uses a specific field label and no-results state.
- Added a clear-search action inside the field. Closing search clears its query so hidden filters cannot silently continue affecting the library.
- Replaced the generic first-note empty state with context-aware messages for empty folders and Favorites; search no-results remain distinct.
- Arabic and English resources added in parity.
- Validation: source assertions, XML parsing, resource-key parity, and ZIP integrity. No Gradle/Compose/JUnit or device execution; no APK claimed.
- App version 0.4.7 / versionCode 20.


## v70 — inline image attachment thumbnails (2026-11-16)

- Review finding: attachments were persisted and listed below each page, but image attachments appeared only as filenames and MIME/byte-count metadata. Students had to leave the note and open another app just to identify a photo or scanned handout.
- Added a compact 56dp image thumbnail beside image attachment rows. Non-image attachments retain their existing filename and open flow.
- Thumbnail decoding runs on `Dispatchers.IO`, first reads image bounds, then decodes a sampled RGB_565 bitmap with a maximum decoded dimension of approximately 512px. This avoids decoding full-resolution camera images solely for a small preview.
- Thumbnail failure (unsupported/corrupt image) falls back to a neutral placeholder; tapping the attachment still uses the existing SHA-256 verification and secure FileProvider open flow. Removing an attachment remains an explicit action.
- App version advanced to 0.4.8 / versionCode 21.
- Validation: source-level checks for IO dispatch, bounds-first sampled decoding, image-only rendering, preserved secure-open path, XML parsing, translation-key parity, and ZIP integrity. No Gradle/Compose compile, JUnit, Android runtime, memory profiling, or physical-device testing was available. This is not a verified APK.


## v71 source update (app 0.4.9 / versionCode 22)
- Improved the everyday image-attachment workflow: tapping an image thumbnail opens an in-app preview dialog, while tapping the attachment row continues to use the existing hash-verified external open flow. The dialog reuses the already sampled bitmap, avoiding a second full-resolution decode and keeping memory bounded; it is an enlarged preview, not a full-resolution image editor.
- Attachment byte counts now use Android's localized short file-size formatter rather than raw byte integers.
- Existing non-image attachment behavior and explicit remove action are unchanged.
- Validation: source inspection, XML parsing, Arabic/English key parity, targeted source assertions and ZIP integrity. Android Gradle/Compose compilation, JUnit, TalkBack, screen-size and physical-device tests were not run.


## v72 — full ZIP restore integration and restore hardening (app 0.5.0 / versionCode 23)

- Added a separate `Restore full backup (ZIP)` action using Android's document picker; the existing JSON restore action remains available for legacy backups without media.
- ZIP restore extracts to private temporary staging, verifies archive manifest/metadata/blob hashes, validates unique entity IDs and folder→note→page→element relationships, and requires the set of referenced media blobs to exactly match the packaged blobs.
- Imported folders, notes, pages and elements receive fresh IDs (except notes already present by original ID, which are skipped with their child rows). This prevents collisions from overwriting existing content. Element restoration uses an ABORT insert, never an upsert/replace.
- Attachment blobs are verified and imported before the Room transaction. If the transaction fails, only newly installed blobs with no database references are removed; pre-existing/shared blobs are never removed. Newly installed blobs unused because all referencing notes were skipped are also cleaned up. A process kill between file installation and the database transaction can still leave an orphan; startup orphan reconciliation is not yet implemented.
- Hardened the streaming JSON parser to reject duplicate top-level sections, duplicate object fields, and incomplete backups. Legacy JSON restore retains an existing folder with the same ID, remaps page/element IDs, and uses insert-only element writes.
- Validation: XML parsed 6/6; Arabic/English string keys match 138/138 with no duplicates; source assertions passed for ZIP restore wiring, validation, ID remapping, strict parser and SAF picker; standalone Kotlin compilation + smoke execution passed for archive streaming round-trip, attachment SHA-256 verification and same-length corruption repair; source ZIP integrity passed. Gradle/Compose/JUnit/Room integration tests and physical-device restore round trips were not run. This is not a verified APK and binary restore remains pending runtime validation.


## v73 — conservative orphan-attachment reconciliation (app 0.5.1 / versionCode 24)

- Added repository-serialized attachment reconciliation at app startup. The scan obtains all Room note elements while holding the same repository mutex used by attachment imports/removals and ZIP/JSON restore, then performs file enumeration, hashing and deletion on `Dispatchers.IO`.
- Builds the live attachment set from decoded references across all media element types. If any media payload is malformed, has an unsupported reference version, or an unknown element type is present, content-addressed attachment deletion is disabled for that pass.
- Only considers files directly inside the app-private `files/attachments/<first-two-hash-chars>/` layout whose filename is a lowercase 64-character SHA-256 plus a valid extension, whose shard matches the hash prefix, whose canonical parent is the expected shard, and whose contents hash to the filename hash.
- Preserves referenced/shared blobs and every file younger than the 24-hour grace period. Unexpected names, paths, directories, symlinks, malformed files and tampered content are skipped rather than inferred to be orphaned.
- Removes only old files in `attachments/.tmp/` whose names match the application's `import-*.part` or `damaged-*.bak` temporary naming patterns. The same grace period applies.
- Returns structured cleaned/skipped/error counts and an unsafe-reference flag; startup logs the outcome without surfacing routine cleanup as a user interruption.
- Added JVM regression tests for old orphan deletion, recent-file protection, referenced/shared-file protection, corrupt/unknown references, unexpected names/paths, tampered content, and owned temporary-file cleanup.
- Reviewed ZIP restore and legacy JSON restore paths. Existing note-ID idempotency, folder collision remapping, regenerated page/element IDs, exact archive blob/reference matching, insert-only element restore, and rollback cleanup of newly installed unreferenced blobs remain unchanged. Process death between blob installation and Room commit is now recoverable by the 24-hour-delayed startup reconciliation.
- Verification boundary: source inspection and static/resource/archive checks are performed for v73. Kotlin/JUnit/Gradle/Compose, Room instrumentation, fault injection, process-death, storage-full, and physical-device tests are not claimed because this environment has no Gradle executable/wrapper JAR, Kotlin compiler, Android SDK, or connected device. Added JUnit tests are source additions, not executed results.


## v74 — storage-boundary and archive-path regression hardening (2026-11-16)
- Re-reviewed the actual v73 source archive and its attachment reconciliation, binary archive codec, restore integration and existing JVM test coverage before changing code.
- Added a JVM regression test proving reconciliation does not follow symlinked shard or blob paths outside the app-private attachment root.
- Added a ZIP extraction regression test proving path-traversal entry names are rejected and failed extraction clears staging without creating files outside it.
- App version advanced to 0.5.2 / versionCode 25. No Room schema, migration, persistence format, or user-facing behavior changed.
- Verification: compiled the actual `AttachmentStorage.kt` and `BackupArchiveCodec.kt` with the available Kotlin 1.9 compiler and ran five executable smoke checks: old verified orphan deletion, recent/live blob preservation, symlink containment, valid ZIP round-trip, and ZIP traversal rejection/staging cleanup. All five passed.
- JUnit, Gradle, Compose, Android build, Room instrumentation, restore idempotency/fault injection, and physical-device tests were not run. The project still has no Gradle wrapper scripts/JAR, Gradle executable, or Android SDK in this environment.


## v75 — student search quality and Arabic text discovery (2026-11-16)

- Reviewed the supplied v74 source archive and its three project documents before changing the source. ZIP integrity and CRC validation passed for all 60 entries; extraction was performed into a separate work directory.
- Improved library search matching for note titles, legacy note body text, and folder names through a new comparison-only `NoteSearchNormalizer`.
- Arabic search ignores combining diacritics and tatweel, folds common alef forms (`أ`, `إ`, `آ`, `ٱ`) to alef, and folds alef-maqsura (`ى`) to ya (`ي`). Search also collapses repeated whitespace and ignores Latin letter case.
- The normalizer is used only to compare search strings. It does not mutate, migrate, or rewrite user-authored titles, note bodies, page text, or folder names.
- Added four JVM unit-test cases covering diacritics/tatweel, Arabic letter variants, whitespace/case, and preservation of original text.
- App version advanced to 0.5.3 / versionCode 26. No Room schema, migration, attachment format, backup format, or restore semantics changed.
- Documentation updated in README, AUDIT_REPORT and SPEC_TRACEABILITY.
- Verification in this environment: ZIP CRC/integrity and safe-path checks, Kotlin-source structural assertions, XML parsing, Arabic/English string-key parity, duplicate-key checks, and final archive integrity were performed. The new JUnit tests, Gradle, Compose, Android APK, Room instrumentation, and physical-device scenarios could not be run: Java is present, but Gradle, wrapper scripts/JAR, `kotlinc`, Android SDK and ADB are absent. No build or runtime success is claimed.
- Remaining risks: search normalization needs review against a broader Arabic corpus (especially dialect-specific spelling and mixed-script punctuation); real-device UX and performance remain unverified. v76 should prioritize configured CI/device verification and end-to-end ZIP restore fault-injection before expanding editor features.


## v77 — Document engine and page operations

Version 0.5.5 (versionCode 28) adds indexed page insertion, page reordering, and document viewport zoom/pan. Existing page IDs and page content are preserved; Room schema remains v4. See `V77_PHASE2_REPORT.md` for scope and verification boundaries, and `V77_NEXT_AGENT_PROMPT.md` for the mandatory continuation workflow. Android build, JUnit, Room instrumentation and physical-device checks remain blocked/not run in the current environment; do not treat this source archive as a verified APK release.


## v78 phase 3 — CI quality gates and Room page transaction regression tests

- Bumped app version to 0.5.6 / versionCode 29; Room schema remains v4.
- CI now runs Android lint, JVM unit tests, debug APK assembly, verifies that KSP emitted at least one Room schema JSON, and runs Android instrumentation tests on an API 36 emulator.
- Added `NotesRepositoryPageTransactionTest` to exercise real in-memory Room transactions for page insertion/reordering, stable page IDs, preservation of opaque future element payloads, and rejection of invalid orders without changing persisted order.
- Added a presentation-settings preservation case to `PageOrderPolicyTest`.
- No production repository, entity, DAO, Room schema, migration, ink, attachment, backup, or restore implementation was changed. No existing source file was deleted.
- Local Gradle/Android build, lint, JVM JUnit, emulator instrumentation and physical-device tests remain NOT RUN because the environment has no Gradle executable/wrapper JAR or Android SDK/ADB. CI must run successfully before these tests or APK are considered verified.


### v81 — per-page paper presentation and expanded templates
- Page template and background color changes now target the currently selected page only. Other pages retain their own paper settings; no Room schema or migration change was needed.
- Added Music staff, Cornell notes, Isometric grid, and Daily planner templates while retaining Blank, Ruled, Grid and Dots.
- The same `PageBackgrounds` renderer is used by on-screen pages and PDF export, so new paper templates follow the existing rendering path.
- Expanded page-color choices and clarified in the settings dialog that presentation changes apply only to the current page.
- Orientation changes are validated and apply only to the selected empty page. Non-empty pages are not resized or clipped.
- Added pure `PagePresentationPolicy` and unit tests for per-page scope, supported template IDs, unknown-template rejection, background metadata preservation and safe orientation changes.
- GitHub ZIP bootstrap now pins the v81 ZIP/version, enforces archive-size/entry limits, rejects duplicate or case-colliding names, traversal, symlinks, special files, encrypted entries and file/directory collisions before extraction.

### Build and validation boundary
- Source-only checks and focused standalone Kotlin policy checks are recorded in `V81_PHASE6_REPORT.md`.
- Android Gradle/Compose compilation, Android Lint, full JUnit, Room instrumentation, emulator UI tests, APK installation and physical pen tests still require a successful GitHub Actions run and device QA. No APK is included in this source ZIP.


## v82 — handwriting smoothing preview and CI/source hardening (0.6.0 / versionCode 33)

- Added `InkBeautifier`, a pure Kotlin and deterministic geometric smoothing operation with Light / Medium / Strong strengths. It does not invoke OCR, does not convert handwriting into a typeface, and does not change stroke order, IDs, tool, color, width, point count or endpoints. The original stroke list remains immutable and the editor records Apply as one undoable edit.
- Added a before/after preview dialog before applying the operation. This is a limited jitter-smoothing implementation, not full handwriting style reconstruction; it does not regularize character spacing, slant, baseline, or Arabic joins. Review with real Arabic and English handwriting is still required.
- Explicitly set `targetSdk = 36`, matching the approved API 36 target (the previous Gradle configuration relied on the plugin default). `minSdk = 23` remains unchanged.
- Updated both GitHub workflows, ZIP filename checks, version assertions and artifact names to v82 / 0.6.0 / versionCode 33. Hardened the ZIP bootstrap against malformed path components, Windows alternate-stream/drive paths, case-colliding parent directories, file/directory type inconsistencies, suspicious compression ratios and non-empty directory entries.
- Room remains schema v4. No database entities, migrations, existing ink codec, attachment payloads or backup/restore formats were changed.
- Verification: pure Kotlin compile passed; four beautifier test methods passed through a temporary local assertion harness (not Gradle/JUnit); XML parse, translation parity, shell syntax, YAML parse, archive CRC/path/extraction and workflow bootstrap fixtures are recorded in `V82_PHASE7_REPORT.md`.
- Not verified: Android Gradle/Compose build, Android Lint, complete JUnit suite, Room instrumentation, emulator UI, APK generation, device visual QA, stylus behavior, and real handwriting quality. v82 is a source update, not a final product-complete release.
