# ELIOS NOTES — next completion phase after v82

Start only from `ELIOS_NOTES_v82_source.zip`. The governing reference is `مشروع ايلي.txt`, approved engineering specification v1.1, followed by the user's fixed decisions and cumulative audit. Re-open the actual source and compare it before editing.

Fixed contract: ELIOS branding; Android phones/tablets; minSdk 23 / targetSdk 36; Kotlin, Compose and Room; Arabic/English RTL/LTR; local-only storage and backup; no account, cloud sync, AI, analytics or external content processing. Preserve every existing note, page, ink payload, attachment and unknown/future payload. Baseline 0.6.0 / code 33 / Room v4.

First close CI: lint, JVM tests, assembleDebug, Room schema generation and emulator instrumentation. Do not add features on top of a known build failure and do not claim Android success without running it.

Remaining requirements requiring real implementation and tests:
1. Rich text with backward-compatible persisted formatting; verify copy/paste/search/PDF/backup.
2. PDF SAF import, PdfRenderer viewing/navigation, independent annotation layer, quality-preserving export, then page operations/merge/split only after library/license/minSdk validation.
3. Audio recording, pause/resume, playback/seeking, permission denial/interruption handling, local storage and note linkage; time-linked notes only if actually implemented.
4. Video playback/preview with lifecycle-safe Android media APIs and streaming.
5. Multiple tags, management, search and filtering without breaking folders/favorites/pin/archive/trash.
6. Real note encryption using Android Keystore + AES-GCM, including attachments; safe migration and v4→v5 tests if required. Never call UI hiding encryption.
7. Stylus tilt/orientation/buttons only through confirmed APIs; optional compatible payload fields; robust unknown/corrupt payload tests; do not overclaim palm rejection.
8. Arabic/English/mixed Ink-to-Text evaluation with a documented corpus and accuracy measurements; keep original ink and separate digital-ink recognition from image OCR.
9. Improve v82 beautification only after Arabic/English visual comparison; preserve original, preview and undo. Do not substitute OCR/typeface rendering.
10. Full backup/restore round trips and corruption, storage-full, interruption, duplicate, rollback and shared-blob tests.
11. Phone/tablet, portrait/landscape, dark/light, RTL/LTR, TalkBack, touch-target and contrast QA.
12. Review the approved Jetpack Ink 1.0.0 decision; do not replace the custom engine with an unverified dependency. Benchmark and test before migration.

Non-negotiable data rules: no destructive migrations; no Room REPLACE on cascade parents; await save queues before destructive/structural/export/backup actions; atomic DB transactions; rollback on failure; stream large files; never delete shared blobs while referenced; never overwrite unknown/corrupt payloads; version and test every format change.

Deliver `ELIOS_NOTES_v83_source.zip`, `V83_PHASE8_REPORT.md`, updated project docs and ZIP bootstrap, SHA-256/count/size/CRC/extraction equivalence, and actual CI results. Classify each feature as IMPLEMENTED+TESTED, DEVICE TEST PENDING, PARTIAL, BLOCKED or NOT IMPLEMENTED. Do not label the product final while mandatory features, CI or device QA remain incomplete. Never fabricate an APK.
