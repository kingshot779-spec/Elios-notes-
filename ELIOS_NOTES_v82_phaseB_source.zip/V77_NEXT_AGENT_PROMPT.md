# ELIOS NOTES — Next Engineering Agent Instructions (Starting from v77)

You are continuing the Android Kotlin/Jetpack Compose/Room project ELIOS NOTES from the supplied `ELIOS_NOTES_v77_source.zip`. Treat that archive as the only authoritative project baseline. Do not assume any feature is complete merely because a class, resource, or code path exists.

## 1. Product contract — mandatory

1. Target practical functional and interaction parity with Samsung Notes workflows, while using original ELIOS NOTES branding, logo, visual assets, and implementation. Do not copy Samsung trademarks, proprietary assets, or claim pixel-identical ownership.
2. Handwriting scope has two independent deliverables:
   - Ink-to-editable-text recognition.
   - Handwriting beautification that retains the handwriting character.
   They must be separately invoked, separately tested, and reversible. Never overwrite original ink.
3. Local-first only. No mandatory login, cloud account, or cloud sync. Notes, pages, ink, attachments, preferences, and indexes stay local. Manual export/import must support device migration.
4. Support Android phones and tablets. Stylus pressure, tilt, orientation, hover, buttons and eraser are optional hardware capabilities; detect them and degrade safely.
5. Absolute non-regression rule: never delete or silently rewrite existing notes, page IDs, page elements, ink payloads, attachment references, folders, backup contents, or user preferences. No destructive reset fallback.
6. Do not mark a feature complete based on source presence. Require build/test evidence and device validation appropriate to the feature.

## 2. Required workflow for every change

### A. Establish the baseline
- Verify the supplied ZIP with `ZipFile.testzip()`; reject path traversal and duplicate archive entries.
- Extract into a fresh working directory; never modify the input archive in place.
- Read `README.md`, `AUDIT_REPORT.md`, `SPEC_TRACEABILITY.md`, `V76_PHASE1_AUDIT.md`, `V77_PHASE2_REPORT.md`, and this prompt.
- Inventory Kotlin, XML, Gradle, Room schemas/migrations, tests, assets and CI workflow.
- Inspect the exact implementation and call sites before changing a feature. Search all references to every modified API.
- Record baseline app version, Room schema version, source file count, and archive hash.

### B. Plan before coding
- Map each requirement to: existing implementation, gap, planned change, affected files, data risk, tests, and release gate.
- Group work only when changes share a stable architectural boundary. Prefer small cohesive batches (for example: page model + repository transaction + session + UI + tests).
- Do not combine unrelated features just to increase the version number.
- Prefer additive, backward-compatible changes. Avoid schema changes unless unavoidable.

### C. Implement safely
- Preserve IDs for existing objects. For reorder/move, update ordering metadata only.
- Use Room transactions for multi-row structural operations.
- Use the repository mutex and existing `SaveQueue` ordering; do not create a competing persistence path.
- Validate complete ID sets before reorder/delete operations. Reject duplicates, unknown IDs and partial orders.
- Keep original ink/text/media payloads intact. Never decode an unknown payload and then overwrite it with an empty/default value.
- For any future schema change: export Room schema JSON, add explicit forward migration(s), test migrations from every supported schema version, test backup compatibility, and never use destructive migration.
- For attachment operations: validate MIME, extension, byte size, content hash, archive paths and app-private path containment. Preserve shared content-addressed blobs until all references are gone.
- Keep expensive I/O and recognition work off the main thread; expose loading, failure, retry and cancellation states.
- Add accessibility descriptions and Arabic/English strings together. Keep resource keys in parity.

### D. Test every batch
- Add focused unit tests for pure logic and edge cases.
- Add repository/Room integration tests for transactions, collisions, missing IDs, rollback and persistence.
- Add regression tests for existing note loading/saving, ink decoding, attachment references, backup export/import and process recreation.
- Test repeated/rapid operations, cancellation, app backgrounding and low-storage/error paths where relevant.
- Do not weaken, delete, skip, or rewrite existing tests merely to get a green result.
- Run `./gradlew test`, `./gradlew lint`, `./gradlew assembleDebug`, and Android instrumentation tests when the environment supports them.
- If wrapper scripts/JAR or Android SDK are absent, report this as BLOCKED; do not claim a successful build. Prefer repairing reproducible CI/wrapper configuration in a dedicated change rather than silently relying on a local Gradle installation.
- For gesture, stylus, handwriting, audio/video, PDF and performance work, require real-device checks on at least one phone and one tablet.

### E. Review before packaging
- Review the full diff, not only the last patch.
- Search for accidental deletions, TODO placeholders, hard-coded UI text, unsafe `!!`, swallowed exceptions, main-thread disk I/O, schema drift, and changed backup formats.
- Parse every XML resource and manifest.
- Check Arabic/English resource parity and duplicate resource names.
- Confirm no Room schema version change unless migrations and schema exports are present.
- Confirm versionCode increments monotonically and versionName is updated.
- Run tests/build again after final edits.
- Update README, AUDIT_REPORT, SPEC_TRACEABILITY, and a version-specific engineering report with exact changes, tests, blocked checks and known gaps.
- Package from a clean directory, verify CRC, duplicate names, unsafe paths, extracted file count and byte-for-byte equality.
- Calculate SHA-256 and provide the exact archive path. Never claim APK readiness unless a real APK was built and verified.

## 3. v77 source-specific facts to preserve

- Room schema is version 4.
- `NotePageEntity` and `NoteElementEntity` are already the persisted document model.
- `PageOrderPolicy` provides page normalization, insertion, movement and complete-ID reorder validation.
- `NotesRepository.insertPageAt` and `reorderPages` use Room transactions and the repository mutex.
- `EditorSession` exposes insert-at-position and one-step page movement.
- `EditorScreen` exposes insert-before/after, move-up/down, and viewport zoom/pan.
- Zoom/pan is transient view state and must not rewrite stored page or ink coordinates.
- Page IDs are stable through reorder. Existing content, ink and attachment references remain attached to page IDs.
- Current known gaps include page thumbnail/sorter UX, safe duplicate-page support, real-device zoom/scroll validation, text flow across pages, CI build verification and Room integration tests.
- Do not assume that page duplication or drag-and-drop sorting exists; inspect source before extending.

## 4. Priority for the next version

Start by resolving P0 engineering gates:
1. Reproducible Gradle wrapper and CI build, including unit tests, lint and debug APK.
2. Room schema export and migration test matrix for supported historical schemas.
3. Repository integration tests for insert/reorder/delete, save queue ordering, app restart and backup/restore.
4. Validate v77 gestures on real phone/tablet; fix conflicts between pinch/pan, vertical scroll, text input and stylus drawing.

Then continue the document engine:
- Page overview/thumbnails and safe drag-and-drop reorder.
- Duplicate page only after a transactional clone design covers text, ink IDs, attachment references and future/unknown payloads without blob duplication or data loss.
- Viewport controls and per-device layout polish.
- Decide text-flow semantics between pages before implementing; do not silently redistribute existing text.

Then proceed to v78 ink and notebook appearance:
- Input cancellation/palm rejection audit, stylus capability handling, latency profiling.
- Render-only smoothing, selection transforms, shapes, richer original page templates.
- Keep the persisted original stroke samples immutable unless the user explicitly applies a reversible edit.

Do not jump to handwriting beautification until source-ink provenance, undo/redo, persistence and evaluation strategy are designed.

## 5. Required delivery format

For each release, deliver:
1. Source ZIP and SHA-256.
2. Concise change log and exact file-level summary.
3. Test matrix with PASSED / FAILED / BLOCKED / NOT RUN.
4. Explicit statement whether an APK was actually built.
5. Known limitations and next release scope.
6. Updated engineering report and next-agent prompt.
7. No false claims of feature parity, build success, device validation, or release readiness.

Work carefully and efficiently. Parallelize independent static inspections and documentation where possible, but serialize edits to shared source files and rerun the full relevant verification after integration.
