# Building ELIOS NOTES

Requirements: JDK 17, Android SDK (platform 36, build-tools 36.0.0), Gradle 8.13.

## 1. Gradle Wrapper (one-time)

The repository does **not** yet contain `gradlew`, `gradlew.bat` or `gradle/wrapper/gradle-wrapper.jar`.
The JAR is a Gradle-generated binary and was deliberately not written by hand.

1. GitHub → Actions → **Generate Gradle Wrapper (one-time, manual)** → Run workflow.
2. Download the `ELIOS_NOTES-gradle-wrapper` artifact.
3. Copy `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar` and
   `gradle/wrapper/gradle-wrapper.properties` into the repository root and commit them.
   The properties file will pin Gradle 8.13 with the official `distributionSha256Sum`.

Locally, with Gradle 8.13 installed, the same result comes from:

    gradle wrapper --gradle-version 8.13 --distribution-type bin \
      --gradle-distribution-sha256-sum "$(curl -fsSL https://services.gradle.org/distributions/gradle-8.13-bin.zip.sha256)"

Until the wrapper is committed, CI and `scripts/ci-build-apk.sh` use Gradle 8.13 installed by
`gradle/actions/setup-gradle`. Once `./gradlew` exists, both prefer it automatically.

## 2. Build, lint, unit tests

    bash scripts/ci-build-apk.sh

Runs `:app:lintDebug :app:testDebugUnitTest :app:assembleDebug`, checks that the APK and the Room schema
JSON exist, compares the schema with the committed one (once committed) and writes the APK checksum.

## 3. Instrumentation tests (needs an emulator or device)

    ./gradlew :app:connectedDebugAndroidTest

Includes `NotesDatabaseMigrationTest` (schema 1→4, 2→4, 3→4, downgrade refusal, cascade, partial
upgrade) and `NotesDatabaseIntegrityTest` (ABORT semantics, foreign keys, locked payload protection).
In CI this runs on an API 36 emulator.

## 4. Room schema export

See `app/schemas/README.md`.
