# GitHub build handoff — ELIOS NOTES v82

## Delivered source

`ELIOS_NOTES_v82_source.zip` is the complete Android Kotlin/Compose/Room source project, not an APK. ZIP entries are at the project root. App version is `0.6.0` / `versionCode 33`, `minSdk 23`, `targetSdk 36`, Room schema v4.

## Upload method A — extracted project

1. Create an empty GitHub repository.
2. Extract `ELIOS_NOTES_v82_source.zip`.
3. Upload all extracted contents to the repository root, including hidden `.github` files.
4. Commit to `main`; `.github/workflows/build-apk.yml` runs automatically.
5. When every required job is green, download `ELIOS_NOTES-v82-debug-apk` from Actions artifacts. It contains `app-debug.apk` and its SHA-256 checksum.

## Upload method B — ZIP bootstrap

1. Create an empty GitHub repository.
2. Upload `ELIOS_NOTES_v82_source.zip` to its root.
3. Create `.github/workflows/build-from-source-zip.yml`.
4. Copy the complete contents of `GITHUB_BOOTSTRAP/build-from-source-zip.yml` from this delivery into that workflow.
5. Commit both files to `main`. The bootstrap validates CRC, paths, case collisions, file/directory conflicts, entry and expanded sizes, compression ratios, symlinks, special files and encryption before extraction. It then verifies the project root and version before building.
6. When the workflow is green, download `ELIOS_NOTES-v82-debug-apk` from Actions artifacts.

The bootstrap expects the exact filename `ELIOS_NOTES_v82_source.zip`. GitHub does not execute a workflow stored only inside a ZIP; the separate bootstrap file is required for method B.

## CI gates

The workflow installs JDK 17, Android platform/build tools API 36 and Gradle 8.13, then runs `:app:lintDebug`, `:app:testDebugUnitTest`, `:app:assembleDebug`, checks generated Room schema and runs `:app:connectedDebugAndroidTest` on an API 36 emulator. It uploads APK/checksum and build reports.

A green CI run verifies configured build and test tasks; it does not prove visual parity, real stylus/palm behavior, Arabic/English handwriting quality, media playback, or physical-device behavior. No remote GitHub Actions result has been observed for this delivery.

## Release signing

The artifact is a Debug APK. A production-signed release requires a private keystore and protected GitHub secrets. Never commit signing material or passwords into the source ZIP or repository. Verify certificate, package ID, version code, checksum and update/install behavior before release.

## Gradle wrapper note

`gradle/wrapper/gradle-wrapper.properties` pins Gradle 8.13, but the project intentionally does not contain wrapper launcher scripts or the Wrapper JAR. The workflows install Gradle 8.13 and invoke `gradle` directly.
