# برومبت الإكمال التالي — ELIOS NOTES بعد v82

أنت مهندس Android/Kotlin Senior. ابدأ حصراً من `ELIOS_NOTES_v82_source.zip` بعد فحص CRC وSHA-256 ومقارنة محتويات المصدر. المرجع الأعلى هو `مشروع ايلي.txt`، وثيقة المواصفات الهندسية المعتمدة v1.1، ثم قرارات المستخدم المثبتة وتقارير التدقيق المتراكمة. لا تعتبر تقارير الإصدارات السابقة بديلاً عن فتح المصدر الفعلي.

## القرارات الثابتة
- الاسم والهوية: ELIOS NOTES، دون نسخ أصول Samsung.
- Android فقط، هواتف وأجهزة لوحية، minSdk 23 وtargetSdk 36.
- Kotlin + Compose + Room 2.8.5، الإصدار الأساسي 0.6.0 / code 33، Room v4.
- العربية والإنجليزية وRTL/LTR.
- التخزين والنسخ الاحتياطي محليان بالكامل؛ لا حساب ولا cloud sync.
- لا تضف AI أو تحليلات أو إرسال محتوى المستخدم لخدمات خارجية.
- لا تفقد أو تعِد كتابة أو تحذف بيانات أو payload غير معروف.

## ابدأ بالبوابة صفر
1. افحص كامل ملفات المشروع والـ diff والوثائق وملفات CI والـ bootstrap.
2. شغّل GitHub CI فعلياً إن أمكن: Lint، JVM tests، assembleDebug، Room schema، emulator instrumentation.
3. أصلح أي فشل بناء قبل أي ميزة جديدة. لا تدّعِ نجاح Android إذا لم تنفذه.
4. راجع نتيجة v82 beautifier بصرياً، وتأكد أن Undo يعيد نفس نقاط الحبر والهوية، وأن معاينة قبل/بعد لا تحفظ شيئاً قبل Apply.

## المهام المتبقية — لا تعتبرها مكتملة إلا باختبارات
1. Rich Text حقيقي: Bold/Italic/Underline، ألوان وأحجام، عناوين، محاذاة واتجاه، قوائم وروابط وجداول عند إمكانها. حافظ على صيغة النص القديمة، واختبر البحث والنسخ/PDF/backup.
2. PDF: استيراد SAF، عرض PdfRenderer مع تنقل الصفحات، طبقة تعليق/حبر مستقلة لا تعدل الأصل، تصدير يحافظ على الجودة، ثم عمليات الصفحات/الدمج/التقسيم فقط بعد اختبار مكتبة مرخصة ومناسبة لـ minSdk.
3. Audio: تسجيل/إيقاف/استكمال/تشغيل/تنقل، أذونات وحالات رفض/انقطاع، حفظ آمن وربط بالملاحظة، streaming ودورة حياة سليمة. لا تدّعِ time-linked notes قبل تنفيذها.
4. Video: معاينة/تشغيل عبر مكتبة Android متوافقة مع minSdk، lifecycle وإغلاق الموارد، وعدم تحميل الملف كاملاً في الذاكرة.
5. Tags: وسوم متعددة مع إدارة وبحث وفلترة، دون كسر المجلدات والمفضلة والتثبيت والأرشيف والسلة.
6. Lock/encryption: لا تنفذ إخفاء واجهة وتسميه تشفيراً. استخدم Android Keystore وAES-GCM، حماية المرفقات والبيانات، وMigration آمن واختبارات v4→v5 إذا تطلب التصميم ذلك.
7. Stylus: tilt/orientation/buttons عبر APIs متاحة فعلياً، payload اختياري متوافق، اختبارات v1/unknown/corrupt، وتحسين palm rejection دون مبالغة.
8. Ink-to-Text: اختبر ML Kit على corpus عربي/إنجليزي/مختلط مع قياس موثق، واحتفظ بالأصل، ولا تخلط digital ink recognition مع OCR الصور.
9. Beautification: طوّرها فقط بناء على مقارنة بصرية عربية وإنجليزية؛ احتفظ بالأصل وUndo وPreview. لا تحولها إلى OCR أو خط طباعي.
10. Backup/Restore: round-trip كامل للبيانات والمرفقات، فساد الملفات، المساحة غير الكافية، انقطاع العملية، التكرار، rollback، ومراجع blobs المشتركة.
11. UX: هاتف/تابلت، portrait/landscape، dark/light، RTL/LTR، TalkBack، أحجام اللمس والتباين.
12. راجع قرار Jetpack Ink 1.0.0 في المرجع؛ لا تغيّر المحرك الحالي إلى dependency غير متحقق منها. اعمل مقارنة تقنية وترخيصية وأداء واختبر التوافق قبل الاستبدال.

## قواعد سلامة غير قابلة للتفاوض
- لا destructive migration.
- لا Room REPLACE على جداول الأب ذات cascade.
- لا تعدّل state قبل commit دون rollback.
- flush/await قبل duplicate/delete/reorder/export/backup/restore.
- معاملات DB ذرية، ومعالجة ملفات streaming.
- لا تحذف blob مشتركة قبل التحقق من عدم وجود أي مرجع.
- لا تكتب فوق payload مجهول/تالف؛ احمه من autosave.
- لا تغيّر backup أو ink format دون إصدار ومهاجر واختبارات توافق.

## التسليم
- `ELIOS_NOTES_v83_source.zip`، ملفات المشروع عند جذر ZIP.
- `V83_PHASE8_REPORT.md` مع حالة كل مطلب: IMPLEMENTED+TESTED / DEVICE TEST PENDING / PARTIAL / BLOCKED / NOT IMPLEMENTED.
- تحديث README/AUDIT_REPORT/SPEC_TRACEABILITY/GITHUB_BUILD_HANDOFF.
- Bootstrap منفصل متوافق مع اسم ZIP والإصدار، مع CRC/path/size/type/collision checks.
- SHA-256، عدد الملفات، الحجم، CRC، مقارنة مع v82، ونتائج CI الحقيقية.
- لا تسمِّ الإصدار نهائياً إذا بقيت ميزة أساسية أو CI أو QA غير مكتمل. لا تضع APK وهمياً داخل التسليم.
