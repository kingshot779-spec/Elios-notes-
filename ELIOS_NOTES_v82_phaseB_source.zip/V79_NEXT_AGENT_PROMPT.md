# Next engineering agent instructions — ELIOS NOTES v79 baseline

You are working on an Android Kotlin / Jetpack Compose / Room project named ELIOS NOTES. Fixed product decisions:

- Target functional and experiential parity with Samsung Notes, with original ELIOS NOTES branding and logo.
- Handwriting consists of two separate capabilities: ink-to-digital-text and handwriting beautification that can revert to the original.
- Local-first storage with backup/restore; no cloud service is required.
- Android phones and tablets, including stylus-capable devices.
- Never remove an existing feature or drop a data type. Do not change storage formats without a demonstrated need, safe migration and tests.

## Mandatory starting point

Start from `ELIOS_NOTES_v79_source.zip` only. Verify ZIP integrity, extract it, read README, AUDIT_REPORT, SPEC_TRACEABILITY, v76-v79 reports and previous agent prompts, then inspect Kotlin/Gradle/Room/CI source before editing. Do not substitute conversation summaries or prior reports for the actual source.

## v79 delivered in source

- Page overview with navigation and text/ink/attachment indicators.
- Explicit move-up/move-down page controls.
- Transactional page duplication with new page and element IDs, preserving payload fields, future/opaque elements and attachment references.
- SaveQueue barrier before duplication and document reload after commit.
- Room instrumentation tests added but not yet executed.
- Room remains v4; build/CI is not yet confirmed green.

## Priority zero: CI and build

1. Inspect GitHub Actions after extracting the project contents into the repository root.
2. Run `scripts/ci-build-apk.sh` on JDK 17, Android SDK 36 and Gradle 8.13.
3. Fix any Lint, JUnit, KSP, Room, APK assembly or emulator-test failures before feature expansion.
4. Never claim a test passed without an actual execution result.
5. The project currently does not contain Gradle Wrapper JAR/launcher scripts; CI installs Gradle explicitly. Do not assume `./gradlew` works.

## Next technical phase

After CI is green:
- Test page overview and duplication on a phone and tablet.
- Add drag-and-drop page reordering only after tests prove stable identity/content and safe drag cancellation.
- Test cloning pages containing text, decodable ink, protected/unknown ink, images, attachments and future payloads.
- Verify deleting an attachment reference from one clone does not delete the blob while the other clone still references it.
- Do not add a Room migration unless the feature genuinely requires it.
- Then improve stylus input and palm rejection, with physical-device testing.

## Fast but safe working method

Group changes within the same layer/feature into coherent batches, but after every batch:
1. Review the diff.
2. Run unit tests for pure logic.
3. Run Room/instrumentation tests for transactions and data safety.
4. Check Arabic/English resource parity.
5. Check that no files or legacy data were removed/rewritten.
6. Update documentation and audit trail.

Do not bundle unrelated changes into one batch. Avoid broad blind replacements without inspecting every changed location.

## GitHub and APK

The ZIP is the source project, not an APK. Extract its contents into the GitHub repository root, preserving `.github/workflows/build-apk.yml`. GitHub Actions builds a debug APK and publishes checksum/artifacts. Uploading the ZIP as the only repository file does not cause Actions to unpack it automatically. Never commit a keystore or signing passwords. Production-signed APK generation is a separate phase after feature completion.

## Delivery gates

- ZIP opens and CRC is valid; no unsafe paths or duplicate names.
- All required files are present; no local build outputs or secrets.
- Extracted files match ZIP contents byte-for-byte.
- versionCode is greater than 30; any Room migration is documented and tested.
- State exactly what changed and what did not.
- Separate executed tests from tests merely added and tests blocked/not run.
- Never claim an APK exists or provide an unverified link.
