#!/usr/bin/env bash
# Lint, JVM unit tests, debug APK and Room schema export check.
# Uses the committed Gradle Wrapper when present (preferred), otherwise a Gradle 8.13 on PATH.
set -euo pipefail

if [[ -x ./gradlew ]]; then
  GRADLE=(./gradlew)
elif command -v gradle >/dev/null 2>&1; then
  GRADLE=(gradle)
else
  echo "ERROR: neither ./gradlew nor gradle on PATH. See docs/BUILD.md." >&2
  exit 2
fi

if [[ -z "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ]]; then
  echo "ERROR: ANDROID_HOME or ANDROID_SDK_ROOT must point to an installed Android SDK." >&2
  exit 2
fi

"${GRADLE[@]}" --version | tee /tmp/gradle-version.txt
grep -q '^Gradle 8\.13' /tmp/gradle-version.txt || { echo "ERROR: Gradle 8.13 is required." >&2; exit 2; }

"${GRADLE[@]}" --no-daemon :app:lintDebug :app:testDebugUnitTest :app:assembleDebug --stacktrace

apk="app/build/outputs/apk/debug/app-debug.apk"
if [[ ! -s "$apk" ]]; then
  echo "ERROR: Debug APK was not produced at $apk" >&2
  exit 3
fi

schema_dir="app/schemas"
schema_count=0
if [[ -d "$schema_dir" ]]; then
  schema_count=$(find "$schema_dir" -type f -name '*.json' | wc -l | tr -d ' ')
fi
if [[ "$schema_count" -lt 1 ]]; then
  echo "ERROR: Room schema export produced no JSON files in $schema_dir" >&2
  exit 4
fi

# Once schema 4 has been committed, the generated file must match it exactly.
if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  if git ls-files --error-unmatch "$schema_dir" >/dev/null 2>&1; then
    if ! git diff --exit-code -- "$schema_dir"; then
      echo "ERROR: Room schema changed without a version bump / committed schema update." >&2
      exit 5
    fi
  fi
fi

(cd "$(dirname "$apk")" && sha256sum "$(basename "$apk")" > "$(basename "$apk").sha256")
echo "Verified APK: $apk"
echo "Room schema JSON files: $schema_count"
cat "$apk.sha256"
