# ELIOS NOTES — v76 Phase 1: Baseline audit and delivery plan

Date: 2026-11-16  
Baseline: `ELIOS_NOTES_v75_source.zip`  
Product target: Samsung Notes functional/experience parity, with an independent ELIOS identity and original assets.  
Device target: Android phones and tablets; stylus features are capability-detected.  
Storage target: local-first, no cloud account or cloud sync; portable local backup/import remains required.

## 1. Accepted product decisions

1. **Parity target:** match the reference app's user-facing workflows and practical capabilities as closely as possible. Do not copy Samsung branding, logos, proprietary assets, or claim exact pixel identity. ELIOS keeps its own design system and iconography.
2. **Handwriting:** deliver both (a) ink-to-editable-text recognition and (b) handwriting beautification that retains editable/vector ink and can be reverted. These are separate operations and must not overwrite the source strokes.
3. **Local storage:** notes, ink, page content, media, settings, and search remain on-device. No mandatory sign-in or cloud dependency. Provide verified export/import for device migration.
4. **Devices:** responsive phone/tablet layouts, with optional stylus pressure/tilt/hover/button capabilities only when hardware and Android APIs expose them.
5. **No regressions:** every phase preserves old note IDs, page content, ink payloads, attachment references, and backup compatibility. No destructive migration, reset fallback, or silent content rewrite.

## 2. v75 source baseline (source presence is not runtime proof)

| Area | Evidence in v75 source | Status for product parity |
|---|---|---|
| Library and organization | Notes/folders, favorites, pin/archive/trash, sorting and local search | Present in source; full device UX validation pending |
| Autosave and data protection | Ordered save queue, retry UI, guarded decoding, Room repository | Present in source; stress/process-death tests pending |
| Pages | Paged and continuous modes, A4 portrait/landscape, blank/ruled/grid/dots, page color, add/delete | Partial: no insert-at-position, no robust page reorder, text does not flow across pages; zoom absent |
| Ink | Pen/pencil/marker/highlighter, eraser, lasso, move, clipboard, undo/redo, pressure when reported | Partial: no tilt/hover/button support; palm cancellation path needs Android MotionEvent audit; device latency unmeasured |
| Handwriting recognition | ML Kit Digital Ink Recognition path for Arabic and English, line grouping, candidate selection, review/merge UI | Partial: no measured Arabic/English accuracy, mixed-script line handling is limited, point timestamps are not persisted, camera/image OCR absent |
| Handwriting beautification | No dedicated beautification engine or reversible beautified-ink model found | Not implemented |
| Text editing | Basic page text field and text codec | Partial: rich text, lists, tables, typography controls and robust text/ink layout not implemented |
| Attachments | Private content-addressed storage, attachment elements, image thumbnail/preview, open/remove | Partial: full inline placement/editing, PDF viewer/annotation, audio/video playback and recording absent |
| PDF | Vector PDF export | Partial: PDF import, annotation, merge/split and round-trip fidelity absent |
| Backup | JSON backup plus ZIP full backup/restore source path | Partial: end-to-end Android restore, fault injection and large-archive validation outstanding; JSON backup is not encrypted |
| Search | Arabic-aware title/body/folder matching | Partial: recognized handwriting is not indexed as searchable text; OCR image search absent |
| Local multi-device transfer | ZIP backup/import path | Partial: no automated device sync by accepted product decision; manual export/import should be verified |
| Accessibility and localization | Arabic and English resources, RTL support declarations | Partial: accessibility audit, large-screen and font-scale review pending |
| Build/release | AGP/Kotlin/Compose/Room setup and CI workflow in source | Unverified: no Gradle wrapper scripts/JAR in archive; no Android SDK/Gradle/ADB in audit environment |

## 3. Architecture and safety constraints

- Keep Room schema v4 unchanged during the v76 audit-only baseline. Any later schema change must include exported schema JSON, explicit forward migration, migration tests from every supported version, and backup compatibility tests.
- Preserve `NoteEntity` identity and the existing page/element relationship. Avoid replacing parent note rows with conflict strategies that cascade-delete pages/elements.
- Keep unknown/future/corrupt payloads protected from autosave overwrite and attachment garbage collection.
- All media imports remain app-private and content-addressed. Validate MIME/extension, size limits, hash, path containment, and archive entry names.
- Recognition must be an explicit, reversible transformation. Preserve original strokes, candidate text, language choice, and provenance; never silently replace handwriting.
- Beautification should produce a separate derived stroke layer/version with a restore-original action. Do not destructively smooth the only stored ink.
- Local-only means no cloud sync dependency. Model-pack downloads for on-device recognition are a separately disclosed optional first-use download; recognition itself can run offline after the relevant model is installed.
- Treat stylus pressure, tilt, orientation, hover and hardware buttons as optional capabilities. Gracefully degrade to ordinary finger/stylus coordinates.

## 4. v76 phase-1 exit criteria

- [x] Re-open and integrity-check the v75 source archive.
- [x] Inventory the current architecture and map existing/partial/missing capabilities.
- [x] Record data-safety constraints and non-regression rules.
- [x] Define the versioned implementation roadmap and objective release gates.
- [x] Keep production behavior, Room schema and user data formats unchanged in this phase.
- [ ] Run Gradle/JUnit/Android build and lint in configured CI (not available in this environment).
- [ ] Run Room migration/backup-restore instrumentation tests on Android (not available in this environment).
- [ ] Validate pen, finger, palm rejection and recognition on physical phone/tablet devices (not available in this environment).

## 5. Version roadmap after v76

### v77 — Document engine and page model

- Define a stable document command model for page/element operations, undo/redo, selection, clipboard and autosave.
- Add insert-at-position, reorder, duplicate and move-page operations with transactional page-index normalization.
- Add zoom/pan and viewport state without changing stored page coordinates.
- Add tests for page ordering, duplicate/delete, undo/redo, process recreation, and old-document compatibility.
- Exit gate: multi-page documents remain stable through repeated edits, app restart, export and restore.

### v78 — Ink engine and notebook appearance

- Add template catalog and per-page background options (ruled variants, grid, dots, blank, planner, Cornell/study, music/staff and other original templates).
- Improve pen rendering, smoothing as a render-only option, selection handles, shape recognition, lasso transforms and eraser UX.
- Add optional stylus tilt/orientation/hover/button support and proper cancellation/rollback for canceled pointer streams.
- Add phone/tablet responsive toolbars and low-latency profiling.
- Exit gate: no lost/corrupted strokes; input cancellation, rotation, scrolling, undo/redo and palm-touch scenarios pass on real devices.

### v79 — Handwriting recognition and beautification

- Build a recognizer adapter with explicit model availability/download state, Arabic, English and user-selected language modes.
- Preserve point timestamps in a backward-compatible ink payload revision; old strokes remain readable.
- Improve line/block segmentation, reading order, mixed Arabic/Latin/number handling, confidence display and editable review.
- Add a reversible beautification pipeline for stroke geometry: baseline alignment, spacing, scale consistency and optional style presets while preserving character identity and original ink.
- Keep recognition and beautification separate; support accept/reject/restore and store derived results independently.
- Create a consented evaluation corpus and report character/word error rate separately for Arabic, English, mixed-script, digits and symbols.
- Exit gate: publish measured accuracy on representative devices/handwriting samples; do not call it complete based on a demo alone.

### v80 — Media, documents and PDF

- Add inline image placement/crop/resize/rotate and element selection/reorder.
- Add PDF import/view/annotation and export fidelity; assess merge/split only after core annotation is stable.
- Add audio recording/playback with note linkage and lifecycle-safe recording state; add video playback or a reliable external-open fallback.
- Add document import/open behavior for supported formats and clear fallback for unsupported formats.
- Exit gate: attachments survive app restart, backup/restore, deletion and low-storage/error paths.

### v81 — Organization, search and local portability

- Add tags/labels, advanced filters, note locking/encryption design, and searchable recognized text.
- Harden full ZIP backup/restore with checksums, idempotence, interrupted restore recovery and large archive testing.
- Provide explicit manual device-transfer workflow; no background cloud sync.
- Exit gate: repeat export/import across two devices/emulators preserves notes, pages, ink, attachments and metadata without duplicates or loss.

### v82 — Product polish and accessibility

- Complete original ELIOS visual identity, icon set, launch assets and consistent component system.
- Audit Arabic RTL, English LTR, tablet split layouts, keyboard/IME, accessibility labels, contrast, dynamic font scale and dark mode.
- Profile startup, scrolling, large notes, many pages, image memory and database queries.
- Exit gate: usability checklist and performance budgets pass on a low/mid-range phone and a tablet.

### v83 — Release candidate and handoff

- Freeze feature scope; resolve P0/P1 bugs; complete regression and migration matrix.
- Build signed release APK/AAB, verify signing, versioning, permissions, privacy disclosures and offline behavior.
- Produce install guide, user guide, backup/restore guide, known-limitations list and reproducible build instructions.
- Exit gate: green CI, instrumented tests, device matrix, backup round-trip and signed release artifacts.

## 6. Priority order

P0 (must precede feature expansion): reproducible Android build; Room schema export; migration tests; autosave/data-loss regression tests; backup/restore integration tests; pointer cancellation/palm rejection review.

P1: document/page command model, page ordering/zoom, ink latency and stylus handling, Arabic recognition evaluation and reversible beautification architecture.

P2: inline media and PDF workflows, audio/video, tags, encryption, expanded templates and advanced formatting.

P3: visual polish, accessibility, performance, release packaging and handoff.

## 7. Verification boundary for this v76 archive

This phase changes project documentation and app version metadata only. It does not claim a feature implementation, Android compilation, JUnit execution, APK build, Room instrumentation, or physical-device verification. Static archive/XML/resource checks are reported separately in the delivery note. The next engineering change should begin only after the baseline CI build is green, or should first repair any build blocker it reveals.
