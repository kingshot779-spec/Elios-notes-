# ELIOS NOTES v82 — Consolidated completion agent brief

Continue exclusively from `ELIOS_NOTES_v81_source.zip`. Preserve the product contract: Samsung Notes functional/experience parity target with original ELIOS branding, local-only storage, phones and tablets, separate ink-to-text and reversible handwriting beautification, and strict preservation of all existing notes/pages/ink/attachments/backups.

Read `V81_PHASE6_REPORT.md`, `README.md`, `AUDIT_REPORT.md`, `SPEC_TRACEABILITY.md`, `GITHUB_BUILD_HANDOFF.md`, the ZIP bootstrap, all prior phase reports/prompts, and inspect the actual source before editing. Baseline is app 0.5.9 / versionCode 32 / Room v4.

## Work sequence

1. **CI gate first:** run/fix Gradle, KSP, Room schema export, Lint, JVM tests, debug assembly, instrumentation and emulator tests. Do not build new features on top of a known build failure. If Android tooling is unavailable, state that and leave CI configured; never claim success.
2. **Pages and paper:** verify v81's page-specific paper settings and all eight templates on phone/tablet/PDF; finish overview, reorder, duplication, insertion/deletion and safe persistence.
3. **Stylus/ink:** preserve v1 stroke payload compatibility. Add tilt/orientation/buttons only through APIs confirmed in the project's AndroidX/SDK versions. Improve palm mitigation using actual pointer cancellation/device information. Test physical pens; do not overclaim hardware palm rejection.
4. **Handwriting beautification:** implement as a separate reversible operation, with preview, intensity controls, original ink retained, undo/restore, Arabic/English visual corpus, and measurable acceptance. Do not confuse it with OCR or Ink-to-Text.
5. **Ink-to-Text:** validate Arabic, English, numerals, punctuation, diacritics, connected Arabic words and mixed-script lines. Keep review-before-insert and preserve ink. Separate digital ink recognition from camera/photo OCR.
6. **Rich text:** add real formatting (bold/italic/underline, size/color, RTL/LTR alignment, lists/headings/links as supported) with backward-compatible storage, search, PDF and backup tests.
7. **Media/PDF:** implement in-app PDF preview/navigation and safe annotations, image handling, audio recording/playback and video preview/playback where stable Android dependencies support it. Use streaming/bounded memory, SAF permissions, hash verification and attachment reference counting. Test large files and lifecycle cleanup.
8. **Organization/privacy:** add multi-tag support. Add local note lock/encryption only with Android Keystore + authenticated encryption and protected key handling; never fake encryption. If schema change is necessary, provide Room v4→v5 migration, export schema and migration/backup tests. No cloud sync.
9. **UI/identity:** polish home/editor/toolbars/templates, phone/tablet layouts, RTL/LTR, light/dark theme, accessibility and error/loading states. Preserve original ELIOS branding; no Samsung logo/assets or inert controls.
10. **Backup/restore:** full round-trip tests for JSON and ZIP, attachments, duplicates, corrupt archives, process interruption, low storage and locked notes.
11. **GitHub APK path:** update the single-ZIP bootstrap for `ELIOS_NOTES_v82_source.zip`, safe validation/extraction, pinned toolchain, lint/tests/Room/APK/emulator, SHA-256 and artifacts. Release signing must use GitHub Secrets only; never commit keystore/passwords.

## Engineering rules

- Batch only related changes; after each vertical slice run focused tests and review the full diff.
- No destructive migrations, no Room REPLACE cascade hazards, no silent payload rewrites, no deletion of unknown/future data.
- Flush SaveQueue before duplicate/delete/reorder/export/backup/restore. Commit DB changes transactionally and update UI only after successful persistence or implement rollback.
- Preserve stable IDs on reorder; create fresh IDs on duplicate. Shared attachment blobs may only be deleted after the last reference is removed.
- Keep legacy stroke/text/backup readers compatible. Any new format must be versioned and tested against old fixtures.
- Do not create placeholder controls, fake feature toggles or empty UI shells.
- Do not say “done” for untested work. Mark every feature IMPLEMENTED + TESTED, DEVICE TEST PENDING, PARTIAL, BLOCKED or NOT IMPLEMENTED.

## Required delivery

Produce a complete `ELIOS_NOTES_v82_source.zip` with project files at ZIP root, updated README/audit/traceability/handoff, separate bootstrap workflow, `V82_PHASE7_REPORT.md`, and SHA-256/CRC/file-count/extraction comparison. If any core requirement remains unimplemented or CI is not green, do not call v82 a final release; document the blocker and keep the source safe.

The full Arabic acceptance matrix and detailed instructions are in `V81_NEXT_AGENT_PROMPT_AR.md`. Start by reopening and auditing v81 itself, not by trusting this brief alone.
