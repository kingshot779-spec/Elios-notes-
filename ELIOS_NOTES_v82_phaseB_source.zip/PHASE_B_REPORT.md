# ELIOS NOTES — تقرير المرحلة B (استقرار البناء)

الأساس: `ELIOS_NOTES_v82_source.zip` (SHA-256 `b4782704…a745`، مطابق). الإصدار 0.6.0 / 33 دون تغيير. لا ميزات جديدة، ولا مساس بالمرحلة D.

## 1. الحكم الصريح

**لم يتحقق أي بناء Gradle ولا Lint ولا أي اختبار في هذه الجلسة.** بيئة التنفيذ فيها Java 21 فقط: لا Gradle ولا Android SDK ولا مصرّف Kotlin ولا محاكي ولا شبكة. بحثت في كامل نظام الملفات عن `gradle-wrapper.jar` أو توزيعة Gradle أو `android.jar` فلم أجد شيئاً. لذلك:

- لا يوجد APK، ولا سجل أخطاء بناء، ولا نتيجة اختبار فعلية.
- كل الكود الجديد **مكتوب وغير مُصرَّف وغير مُشغَّل**، ولا يُعدّ ميزة مكتملة.
- شرط الانتقال إلى المرحلة D (نجاح البناء والاختبارات الأساسية) **غير متحقق**. لن أنتقل إليها.

## 2. ما الذي لم أستطع تسليمه، ولماذا

| المطلوب | الحالة | السبب |
|---|---|---|
| `gradlew` و`gradle-wrapper.jar` | لم يُسلَّما | الـ JAR ملف ثنائي يولّده Gradle نفسه. كتابة `gradlew` دونه لا تعمل، وتزوير JAR غير مقبول أمنياً. سير عمل توليده جاهز (القسم 4) |
| `app/schemas/*.json` | لم تُولَّد | يولّدها مصرّف Room (KSP) ويحسب `identityHash` بنفسه. كتابتها يدوياً تعني بصمة مختلقة. أنشأت المجلد مع README يشرح الخطوة |
| بناء/Lint/اختبارات فعلية | لم تُنفَّذ | القسم 1 |

## 3. الملفات التي تغيّرت (مقارنة بـ v82 الأصلي: 93 ملفاً → 99، صفر ملفات محذوفة)

**معدّل (4):**

| الملف | التغيير | السبب |
|---|---|---|
| `app/src/main/java/com/eliosnotes/app/data/NotesDatabase.kt` | `private val MIGRATION_*` → `internal val`، وإضافة `ALL_MIGRATIONS`، و`addMigrations(*ALL_MIGRATIONS)` | تستخدم الاختبارات نفس الهجرات المشحونة. السلوك وقت التشغيل مطابق تماماً. أعدت قراءة `diff`: 8 أسطر فقط |
| `scripts/ci-build-apk.sh` | يفضّل `./gradlew` ثم `gradle`، ويتحقق أن الإصدار 8.13، ويفشل إن اختلف المخطط المولَّد عن المُلتزَم (بعد التزامه) | منع تغيير مخطط بلا إصدار/هجرة |
| `.github/workflows/build-apk.yml` | خطوة اختبارات الأجهزة تستخدم `./gradlew` إن وُجد | توافق مع الـ Wrapper بعد التزامه |
| `GITHUB_BOOTSTRAP/build-from-source-zip.yml` | اسم الأرشيف المتوقع `ELIOS_NOTES_v82_phaseB_source.zip`، وخطوة الأجهزة تدعم `gradlew` | يطابق الأرشيف الجديد |

**جديد (6):**

| الملف | الغرض |
|---|---|
| `.github/workflows/generate-gradle-wrapper.yml` | يولّد الـ Wrapper الرسمي مثبتاً على 8.13 مع `distributionSha256Sum` الرسمي ويتحقق منه بـ `wrapper-validation` |
| `app/src/androidTest/.../NotesDatabaseMigrationTest.kt` | 8 اختبارات هجرة (القسم 5) |
| `app/src/androidTest/.../NotesDatabaseIntegrityTest.kt` | 8 اختبارات سلامة بيانات |
| `app/schemas/README.md` | خطوات توليد والتزام مخططات Room |
| `docs/BUILD.md` | تعليمات البناء وتوليد الـ Wrapper |
| `PHASE_B_REPORT.md` | هذا التقرير |

## 4. الخطوات المطلوبة منك للحصول على نتيجة فعلية

1. ارفع الأرشيف إلى مستودع GitHub (أو استخدم `GITHUB_BOOTSTRAP/build-from-source-zip.yml`) وشغّل **Validate and build ELIOS NOTES**. أرسل لي سجل أي فشل.
2. شغّل **Generate Gradle Wrapper** مرة واحدة، نزّل الـ artifact والتزم ملفاته.
3. بعد أول بناء ناجح، التزم `app/schemas/.../4.json` من artifact `ELIOS_NOTES-v82-room-schemas`.
4. أرسل لي النتائج وأصلح ما يفشل قبل أي عمل على D.

## 5. اختبارات الهجرة

لا توجد ملفات مخطط للإصدارات 1–3، فلا يمكن استخدام `MigrationTestHelper`. بنيت قواعد قديمة من DDL **أعدت بناءه من تاريخ الكيانات وكود الهجرة** (وهو استنتاج، وليس نسخة مأخوذة من تثبيت حقيقي قديم)، ثم فتحتها عبر Room بالهجرات الحقيقية. فتح Room يتحقق تلقائياً من مطابقة المخطط للكيانات.

تغطي: v1→4 و v2→4 و v3→4، حفظ البيانات حرفياً (بما فيها حمولة الحبر بايتاً ببايت ونص عربي)، القيم الافتراضية للأعمدة الجديدة، مطابقة المخطط المهاجَر لمخطط قاعدة جديدة (أعمدة، فهارس، مفاتيح أجنبية)، تحمّل أعمدة موجودة مسبقاً، بقاء حذف cascade لملاحظة واحدة فقط، رفض قاعدة بإصدار أحدث دون مسحها، واستقرار إعادة الفتح.

## 6. جدول الاختبارات

لا اختبار منها نُفِّذ. العمود الأخير هو الحالة الفعلية.

| الاختبار | النوع | الحالة |
|---|---|---|
| NotesDatabaseMigrationTest.v1ToV4KeepsLegacyNoteAndGivesNewColumnsSafeDefaults | Instrumentation (جديد) | لم يُنفَّذ |
| NotesDatabaseMigrationTest.v2ToV4KeepsFlagsPagesAndInkPayloadsByteForByte | Instrumentation (جديد) | لم يُنفَّذ |
| NotesDatabaseMigrationTest.v3ToV4KeepsFoldersAndAssignments | Instrumentation (جديد) | لم يُنفَّذ |
| NotesDatabaseMigrationTest.migratedSchemaMatchesFreshlyCreatedSchema | Instrumentation (جديد) | لم يُنفَّذ |
| NotesDatabaseMigrationTest.migrationToleratesColumnsThatAlreadyExist | Instrumentation (جديد) | لم يُنفَّذ |
| NotesDatabaseMigrationTest.cascadeDeleteStillRemovesOnlyThatNotesPagesAndElementsAfterMigration | Instrumentation (جديد) | لم يُنفَّذ |
| NotesDatabaseMigrationTest.databaseFromNewerAppVersionIsRefusedAndLeftUntouched | Instrumentation (جديد) | لم يُنفَّذ |
| NotesDatabaseMigrationTest.reopeningAMigratedDatabaseIsStable | Instrumentation (جديد) | لم يُنفَّذ |
| NotesDatabaseIntegrityTest.insertingADuplicateNoteAbortsAndKeepsTheOriginal | Instrumentation (جديد) | لم يُنفَّذ |
| NotesDatabaseIntegrityTest.upsertingAnElementNeverCascadeDeletesItsPageOrSiblings | Instrumentation (جديد) | لم يُنفَّذ |
| NotesDatabaseIntegrityTest.foreignKeysAreEnforcedForOrphanPagesAndElements | Instrumentation (جديد) | لم يُنفَّذ |
| NotesDatabaseIntegrityTest.failedBatchInsertRollsBackEveryElementInIt | Instrumentation (جديد) | لم يُنفَّذ |
| NotesDatabaseIntegrityTest.savePageNeverDeletesUndecodableInkOrUnknownElementTypes | Instrumentation (جديد) | لم يُنفَّذ |
| NotesDatabaseIntegrityTest.savePageDoesNotOverwriteUnreadableTextWhenWriteTextIsFalse | Instrumentation (جديد) | لم يُنفَّذ |
| NotesDatabaseIntegrityTest.deletingOneNoteLeavesOtherNotesUntouched | Instrumentation (جديد) | لم يُنفَّذ |
| NotesDatabaseIntegrityTest.trashAndRestoreKeepPagesAndElements | Instrumentation (جديد) | لم يُنفَّذ |
| NotesRepositoryPageTransactionTest.insertAndReorderKeepStablePageAndElementIdentity | Instrumentation (موجود) | لم يُنفَّذ |
| NotesRepositoryPageTransactionTest.duplicatePageCopiesAllPayloadsWithFreshIdentitiesAndSharedMediaReference | Instrumentation (موجود) | لم يُنفَّذ |
| NotesRepositoryPageTransactionTest.duplicatePageKeepsSharedAttachmentBlobUntilLastReferenceIsRemoved | Instrumentation (موجود) | لم يُنفَّذ |
| NotesRepositoryPageTransactionTest.duplicatePagePreservesSearchMirrorWhenTextPayloadIsUnknown | Instrumentation (موجود) | لم يُنفَّذ |
| NotesRepositoryPageTransactionTest.duplicatePagePreservesLegacyBodyWhenNoTextElementsExistYet | Instrumentation (موجود) | لم يُنفَّذ |
| NotesRepositoryPageTransactionTest.duplicatePageRejectsAmbiguousMultipleTextRowsAtomically | Instrumentation (موجود) | لم يُنفَّذ |
| NotesRepositoryPageTransactionTest.duplicatePageRejectsPageFromAnotherNoteWithoutChangingEitherDocument | Instrumentation (موجود) | لم يُنفَّذ |
| NotesRepositoryPageTransactionTest.invalidReorderDoesNotChangePersistedOrder | Instrumentation (موجود) | لم يُنفَّذ |
| NoteSearchNormalizerTest (4 اختبار) | JVM unit | لم يُنفَّذ |
| NoteTitlePolicyTest (6 اختبار) | JVM unit | لم يُنفَّذ |
| BackupArchiveCodecTest (8 اختبار) | JVM unit | لم يُنفَّذ |
| PageOrderPolicyTest (7 اختبار) | JVM unit | لم يُنفَّذ |
| PagePresentationPolicyTest (5 اختبار) | JVM unit | لم يُنفَّذ |
| TextCodecTest (3 اختبار) | JVM unit | لم يُنفَّذ |
| AttachmentRefCodecTest (3 اختبار) | JVM unit | لم يُنفَّذ |
| AttachmentStorageTest (14 اختبار) | JVM unit | لم يُنفَّذ |
| InkBeautifierTest (5 اختبار) | JVM unit | لم يُنفَّذ |
| InkCodecTest (6 اختبار) | JVM unit | لم يُنفَّذ |
| InkGeometryTest (10 اختبار) | JVM unit | لم يُنفَّذ |
| LassoGeometryTest (7 اختبار) | JVM unit | لم يُنفَّذ |
| StrokeClipboardTest (7 اختبار) | JVM unit | لم يُنفَّذ |
| RecognitionHeuristicsTest (12 اختبار) | JVM unit | لم يُنفَّذ |
| RecognitionTextMergeTest (4 اختبار) | JVM unit | لم يُنفَّذ |
| InkPointerPolicyTest (5 اختبار) | JVM unit | لم يُنفَّذ |

الإجمالي المكتوب: 106 اختبار JVM + 8 أجهزة موجودة + 16 أجهزة جديدة. **المنفَّذ فعلياً: 0.**

### فحوص نفّذتها فعلياً (ليست اختبارات Gradle)

| الفحص | النتيجة |
|---|---|
| SHA-256 وCRC للأرشيف الأصلي | ناجح |
| صلاحية YAML للـ workflows الثلاثة | ناجح (PyYAML) |
| صياغة `ci-build-apk.sh` (`bash -n`) | ناجح |
| استيرادات المشروع الداخلية: 0 غير محلولة (عدا `R` المولَّد) | ناجح |
| مفاتيح `R.string`: 169 مستخدماً، 0 مفقوداً، العربية والإنجليزية متطابقتان | ناجح |
| توازن الأقواس والاستيرادات غير المستخدمة في الملفات الثلاثة المعدّلة/الجديدة | ناجح |
| ترجمة Kotlin، Lint، Room KSP | **لم يُنفَّذ** |

## 7. حماية البيانات

- لا تغيير في الكيانات أو DAO أو مخطط Room (ما زال v4) أو ترميز الحبر أو المرفقات أو صيغة النسخ الاحتياطي.
- لا migration جديدة ولا `fallbackToDestructiveMigration`. تعليق في الكود يمنعهما.
- التعديل الوحيد في كود الإنتاج إعادة تسمية ظهور (visibility) دون أثر وقت التشغيل.

## 8. مخاطر معروفة

- DDL القواعد القديمة في الاختبارات مُعاد بناؤه. إن اختلف تثبيت حقيقي قديم (مثلاً بأعمدة إضافية)، فالأفضل إضافة اختبار من نسخة قاعدة بيانات حقيقية قديمة إن وُجدت.
- أخطاء ترجمة محتملة في الاختبارات الجديدة لأن أحداً لم يصرّفها.
- `org.gradle.configuration-cache=true` قد يتعارض مع بعض إضافات AGP/KSP. لم أغيّره دون دليل.
- تحقق التبعيات (AGP 8.13.2، Kotlin 2.2.21، KSP 2.3.10، Compose BOM 2025.09.00 ...) لم يُجرَّ.
