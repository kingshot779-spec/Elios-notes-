package com.eliosnotes.app.data.media

import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.nio.file.Files
import java.io.File

class AttachmentStorageTest {
    @Test fun importsAndReadsExactBytes() {
        val root = Files.createTempDirectory("elios-media").toFile()
        try {
            val bytes = "ELIOS attachment".toByteArray()
            val store = AttachmentStorage(root)
            val ref = store.import(ByteArrayInputStream(bytes), "photo.PNG", "image/png")
            assertTrue(store.exists(ref))
            assertArrayEquals(bytes, store.open(ref).use { it.readBytes() })
            assertEquals("png", ref.extension)
            assertEquals(bytes.size.toLong(), ref.byteCount)
        } finally { root.deleteRecursively() }
    }

    @Test fun identicalContentUsesSameBlob() {
        val root = Files.createTempDirectory("elios-dedupe").toFile()
        try {
            val store = AttachmentStorage(root)
            val data = byteArrayOf(1, 2, 3, 4)
            val a = store.import(ByteArrayInputStream(data), "a.bin", "application/octet-stream")
            val b = store.import(ByteArrayInputStream(data), "b.bin", "application/octet-stream")
            assertEquals(a.sha256, b.sha256)
            assertEquals(store.resolve(a), store.resolve(b))
        } finally { root.deleteRecursively() }
    }

    @Test fun rejectsOversizedInputAndLeavesNoPartialBlob() {
        val root = Files.createTempDirectory("elios-limit").toFile()
        try {
            val store = AttachmentStorage(root, maxBytes = 3)
            try {
                store.import(ByteArrayInputStream(byteArrayOf(1, 2, 3, 4)), "large.bin", "application/octet-stream")
                fail("Expected size limit")
            } catch (_: IllegalArgumentException) { }
            val temp = java.io.File(root, "attachments/.tmp")
            assertEquals(0, temp.listFiles()?.size ?: 0)
        } finally { root.deleteRecursively() }
    }

    @Test fun detectsContentTamperingEvenWhenFileLengthIsUnchanged() {
        val root = Files.createTempDirectory("elios-integrity").toFile()
        try {
            val store = AttachmentStorage(root)
            val ref = store.import(ByteArrayInputStream(byteArrayOf(10, 20, 30)), "proof.bin", "application/octet-stream")
            assertTrue(store.verify(ref))
            store.resolve(ref).writeBytes(byteArrayOf(10, 20, 31))
            assertFalse(store.verify(ref))
        } finally { root.deleteRecursively() }
    }

    @Test fun reimportRepairsSameLengthCorruptedExistingBlob() {
        val root = Files.createTempDirectory("elios-repair").toFile()
        try {
            val store = AttachmentStorage(root)
            val original = byteArrayOf(4, 8, 15, 16, 23, 42)
            val ref = store.import(ByteArrayInputStream(original), "proof.bin", "application/octet-stream")
            store.resolve(ref).writeBytes(byteArrayOf(4, 8, 15, 16, 23, 41))
            assertFalse(store.verify(ref))

            val repaired = store.import(ByteArrayInputStream(original), "proof.bin", "application/octet-stream")
            assertEquals(ref.sha256, repaired.sha256)
            assertTrue("Re-import must repair a damaged same-length blob", store.verify(repaired))
            assertArrayEquals(original, store.open(repaired).use { it.readBytes() })
            assertEquals(0, java.io.File(root, "attachments/.tmp").listFiles()?.size ?: 0)
        } finally { root.deleteRecursively() }
    }

    @Test fun stripsPathAndControlCharactersFromDisplayName() {
        assertEquals("scan.pdf", AttachmentStorage.sanitizeDisplayName("../scan\n.pdf"))
    }

    @Test fun reconciliationDeletesOnlyOldVerifiedOrphans() {
        val root = Files.createTempDirectory("elios-reconcile-old").toFile()
        try {
            val store = AttachmentStorage(root)
            val orphanBytes = "old orphan".toByteArray()
            val orphan = store.import(ByteArrayInputStream(orphanBytes), "orphan.bin", "application/octet-stream")
            val now = System.currentTimeMillis()
            assertTrue(store.resolve(orphan).setLastModified(now - AttachmentStorage.DEFAULT_RECONCILIATION_GRACE_MS - 5_000))
            val result = store.reconcile(emptySet(), now)
            assertEquals(1, result.cleanedFiles)
            assertFalse(store.resolve(orphan).exists())
            assertFalse(result.unsafeReferences)
        } finally { root.deleteRecursively() }
    }

    @Test fun reconciliationPreservesRecentUnreferencedBlob() {
        val root = Files.createTempDirectory("elios-reconcile-recent").toFile()
        try {
            val store = AttachmentStorage(root)
            val ref = store.import(ByteArrayInputStream(byteArrayOf(1, 3, 5)), "recent.bin", "application/octet-stream")
            val result = store.reconcile(emptySet(), System.currentTimeMillis())
            assertTrue(store.resolve(ref).exists())
            assertEquals(1, result.skippedFiles)
        } finally { root.deleteRecursively() }
    }

    @Test fun reconciliationPreservesReferencedAndSharedBlobs() {
        val root = Files.createTempDirectory("elios-reconcile-shared").toFile()
        try {
            val store = AttachmentStorage(root)
            val ref = store.import(ByteArrayInputStream(byteArrayOf(2, 4, 6)), "shared.bin", "application/octet-stream")
            val old = System.currentTimeMillis() - AttachmentStorage.DEFAULT_RECONCILIATION_GRACE_MS - 1_000
            assertTrue(store.resolve(ref).setLastModified(old))
            // The set is built from all elements, so removing one of two references leaves the
            // second reference represented by the same content-addressed key.
            val payload = AttachmentRefCodec.encode(ref)
            val twoLiveRows = listOf("IMAGE" to payload, "ATTACHMENT" to payload)
            val allReferences = AttachmentRefCodec.collectReferencedKeys(
                twoLiveRows, setOf("IMAGE", "VIDEO", "AUDIO", "PDF_CONTENT", "ATTACHMENT")
            )!!
            val afterOneReferenceRemoved = AttachmentRefCodec.collectReferencedKeys(
                twoLiveRows.drop(1), setOf("IMAGE", "VIDEO", "AUDIO", "PDF_CONTENT", "ATTACHMENT")
            )!!
            assertEquals(allReferences, afterOneReferenceRemoved)
            val result = store.reconcile(afterOneReferenceRemoved, System.currentTimeMillis())
            assertTrue(store.resolve(ref).exists())
            assertEquals(1, result.skippedFiles)
        } finally { root.deleteRecursively() }
    }

    @Test fun undecodableMediaReferenceDisablesBlobDeletion() {
        val ref = StoredAttachment("c".repeat(64), "pdf", 10, "application/pdf", "x.pdf")
        val valid = AttachmentRefCodec.encode(ref)
        val mediaTypes = setOf("IMAGE", "VIDEO", "AUDIO", "PDF_CONTENT", "ATTACHMENT")
        assertNull(AttachmentRefCodec.collectReferencedKeys(
            listOf("IMAGE" to valid, "VIDEO" to """{"version":99}"""), mediaTypes
        ))
        assertNull(AttachmentRefCodec.collectReferencedKeys(listOf("FUTURE_MEDIA" to valid), mediaTypes))

        val root = Files.createTempDirectory("elios-reconcile-corrupt-ref").toFile()
        try {
            val store = AttachmentStorage(root)
            val orphan = store.import(ByteArrayInputStream(byteArrayOf(3, 1, 4)), "candidate.bin", "application/octet-stream")
            val old = System.currentTimeMillis() - AttachmentStorage.DEFAULT_RECONCILIATION_GRACE_MS - 1_000
            assertTrue(store.resolve(orphan).setLastModified(old))
            val result = store.reconcile(null, System.currentTimeMillis())
            assertTrue(result.unsafeReferences)
            assertTrue(store.resolve(orphan).exists())
        } finally { root.deleteRecursively() }
    }

    @Test fun reconciliationPreservesUnexpectedNamesPathsAndTamperedContent() {
        val root = Files.createTempDirectory("elios-reconcile-unknown").toFile()
        try {
            val store = AttachmentStorage(root)
            val bytes = byteArrayOf(7, 7, 7)
            val ref = store.import(ByteArrayInputStream(bytes), "known.bin", "application/octet-stream")
            val shard = store.resolve(ref).parentFile
            val unexpected = File(shard, "not-a-content-address.bin").apply { writeBytes(bytes) }
            val wrongShard = File(File(root, "attachments"), "ff").apply { mkdirs() }
            val unexpectedPath = File(wrongShard, "${"d".repeat(64)}.bin").apply { writeBytes(bytes) }
            val tamperedShard = File(File(root, "attachments"), "ee").apply { mkdirs() }
            val tampered = File(tamperedShard, "${"e".repeat(64)}.bin").apply { writeBytes(bytes) }
            val old = System.currentTimeMillis() - AttachmentStorage.DEFAULT_RECONCILIATION_GRACE_MS - 1_000
            listOf(unexpected, unexpectedPath, tampered).forEach { assertTrue(it.setLastModified(old)) }

            store.reconcile(emptySet(), System.currentTimeMillis())
            assertTrue(unexpected.exists())
            assertTrue(unexpectedPath.exists())
            assertTrue(tampered.exists())
            assertTrue(store.resolve(ref).exists())
        } finally { root.deleteRecursively() }
    }

    @Test fun reconciliationCleansOnlyOldRecognizedApplicationTempFiles() {
        val root = Files.createTempDirectory("elios-reconcile-temp").toFile()
        try {
            val store = AttachmentStorage(root)
            val tempDir = File(root, "attachments/.tmp").apply { mkdirs() }
            val oldOwned = File(tempDir, "import-test_123.part").apply { writeText("partial") }
            val oldUnknown = File(tempDir, "user-file.tmp").apply { writeText("keep") }
            val recentOwned = File(tempDir, "import-recent.part").apply { writeText("keep") }
            val old = System.currentTimeMillis() - AttachmentStorage.DEFAULT_RECONCILIATION_GRACE_MS - 1_000
            assertTrue(oldOwned.setLastModified(old))
            assertTrue(oldUnknown.setLastModified(old))

            val result = store.reconcile(emptySet(), System.currentTimeMillis())
            assertFalse(oldOwned.exists())
            assertTrue(oldUnknown.exists())
            assertTrue(recentOwned.exists())
            assertEquals(1, result.cleanedFiles)
            assertTrue(result.skippedFiles >= 2)
        } finally { root.deleteRecursively() }
    }

    @Test fun referencedOldBlobSurvivesACompletedCleanupPass() {
        val root = Files.createTempDirectory("elios-reconcile-failure").toFile()
        try {
            val store = AttachmentStorage(root)
            val ref = store.import(ByteArrayInputStream(byteArrayOf(9, 8, 7)), "safe.bin", "application/octet-stream")
            val old = System.currentTimeMillis() - AttachmentStorage.DEFAULT_RECONCILIATION_GRACE_MS - 1_000
            assertTrue(store.resolve(ref).setLastModified(old))
            // A referenced blob is not a deletion candidate even when it is old; a filesystem
            // cleanup failure therefore cannot mutate or cascade into Room note data.
            val result = store.reconcile(setOf("${ref.sha256}.${ref.extension}"), System.currentTimeMillis())
            assertTrue(store.resolve(ref).exists())
            assertEquals(1, result.skippedFiles)
            assertTrue(result.errors.isEmpty())
        } finally { root.deleteRecursively() }
    }


    @Test fun reconciliationDoesNotFollowSymlinkedShardOrBlobPaths() {
        val root = Files.createTempDirectory("elios-reconcile-symlink-root").toFile()
        val outside = Files.createTempDirectory("elios-reconcile-symlink-outside").toFile()
        try {
            val store = AttachmentStorage(root)
            val bytes = "external-but-valid-content".toByteArray()
            val hash = java.security.MessageDigest.getInstance("SHA-256").digest(bytes)
                .joinToString("") { "%02x".format(it) }
            val old = System.currentTimeMillis() - AttachmentStorage.DEFAULT_RECONCILIATION_GRACE_MS - 5_000

            val outsideShard = File(outside, hash.take(2)).apply { mkdirs() }
            val outsideBlob = File(outsideShard, "$hash.bin").apply {
                writeBytes(bytes)
                assertTrue(setLastModified(old))
            }

            val attachments = File(root, "attachments").apply { mkdirs() }
            val linkedShard = File(attachments, hash.take(2))
            Files.createSymbolicLink(linkedShard.toPath(), outsideShard.toPath())

            val ordinaryShard = File(attachments, "ab").apply { mkdirs() }
            val linkedBlob = File(ordinaryShard, "${"b".repeat(64)}.bin")
            Files.createSymbolicLink(linkedBlob.toPath(), outsideBlob.toPath())

            val result = store.reconcile(emptySet(), System.currentTimeMillis())

            assertTrue("A symlinked shard must not expose external files to cleanup", outsideBlob.exists())
            assertTrue("A symlinked blob must not be followed or deleted", linkedBlob.exists())
            assertEquals(0, result.cleanedFiles)
            assertTrue(result.skippedFiles >= 1)
        } catch (unsupported: UnsupportedOperationException) {
            org.junit.Assume.assumeNoException("Symbolic links are unavailable on this test filesystem", unsupported)
        } catch (denied: java.nio.file.FileSystemException) {
            org.junit.Assume.assumeNoException("Symbolic links are not permitted on this test filesystem", denied)
        } finally {
            root.deleteRecursively()
            outside.deleteRecursively()
        }
    }

}
