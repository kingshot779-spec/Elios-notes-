package com.eliosnotes.app.data.backup

import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class BackupArchiveCodecTest {
    private fun hash(bytes: ByteArray) = MessageDigest.getInstance("SHA-256").digest(bytes)
        .joinToString("") { "%02x".format(it) }

    @Test fun roundTripMetadataAndBinaryBlobVerifiesHash() {
        val blobBytes = "ELIOS attachment bytes".toByteArray()
        val blob = BackupArchiveCodec.Blob(hash(blobBytes), "bin", blobBytes.size.toLong())
        val output = ByteArrayOutputStream()
        BackupArchiveCodec.write(output, ByteArrayInputStream("{\"notes\":[]}".toByteArray()), listOf(blob)) {
            ByteArrayInputStream(blobBytes)
        }
        val staging = createTempDir(prefix = "elios-archive-test-")
        try {
            val result = BackupArchiveCodec.extract(ByteArrayInputStream(output.toByteArray()), staging)
            assertEquals("{\"notes\":[]}", result.metadataFile.readText())
            assertEquals(blobBytes.size.toLong(), result.attachmentFiles.getValue(blob.entryName).length())
            assertEquals(blob.sha256, hash(result.attachmentFiles.getValue(blob.entryName).readBytes()))
        } finally { staging.deleteRecursively() }
    }

    @Test fun damagedBlobIsRejectedAndStagingCleaned() {
        val bytes = "correct".toByteArray()
        val blob = BackupArchiveCodec.Blob(hash(bytes), "bin", bytes.size.toLong())
        val output = ByteArrayOutputStream()
        BackupArchiveCodec.write(output, ByteArrayInputStream("{}".toByteArray()), listOf(blob)) {
            ByteArrayInputStream("broken!".toByteArray())
        }
        val staging = createTempDir(prefix = "elios-archive-bad-")
        try {
            assertThrows(IllegalArgumentException::class.java) {
                BackupArchiveCodec.extract(ByteArrayInputStream(output.toByteArray()), staging)
            }
            assertTrue(staging.listFiles().isNullOrEmpty())
        } finally { staging.deleteRecursively() }
    }

    @Test fun rejectsNonArchiveInput() {
        val staging = createTempDir(prefix = "elios-archive-invalid-")
        try {
            assertThrows(Exception::class.java) {
                BackupArchiveCodec.extract(ByteArrayInputStream("not a zip".toByteArray()), staging)
            }
        } finally { staging.deleteRecursively() }
    }

    @Test fun writerRejectsSameLengthTamperedSourceBeforeCompletingArchive() {
        val declared = "original".toByteArray()
        val tampered = "tampered".toByteArray()
        assertEquals(declared.size, tampered.size)
        val blob = BackupArchiveCodec.Blob(hash(declared), "bin", declared.size.toLong())
        assertThrows(IllegalArgumentException::class.java) {
            BackupArchiveCodec.write(ByteArrayOutputStream(), ByteArrayInputStream("{}".toByteArray()), listOf(blob)) {
                ByteArrayInputStream(tampered)
            }
        }
    }


    private fun rewriteZip(source: ByteArray, targetName: String, replacement: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        ZipInputStream(ByteArrayInputStream(source)).use { input ->
            ZipOutputStream(out).use { output ->
                while (true) {
                    val entry = input.nextEntry ?: break
                    output.putNextEntry(java.util.zip.ZipEntry(entry.name))
                    if (entry.name == targetName) output.write(replacement) else input.copyTo(output)
                    output.closeEntry()
                    input.closeEntry()
                }
            }
        }
        return out.toByteArray()
    }

    @Test fun metadataIsHashedAndTamperingIsRejected() {
        val output = ByteArrayOutputStream()
        BackupArchiveCodec.write(output, ByteArrayInputStream("{\"notes\":[]}".toByteArray()), emptyList()) {
            error("No blobs expected")
        }
        val changed = rewriteZip(output.toByteArray(), BackupArchiveCodec.METADATA_ENTRY, "{\"notes\":[1]}".toByteArray())
        val staging = createTempDir(prefix = "elios-archive-metadata-")
        try {
            assertThrows(IllegalArgumentException::class.java) {
                BackupArchiveCodec.extract(ByteArrayInputStream(changed), staging)
            }
            assertTrue(staging.listFiles().isNullOrEmpty())
        } finally { staging.deleteRecursively() }
    }

    @Test fun rejectsUnsupportedArchiveVersion() {
        val output = ByteArrayOutputStream()
        BackupArchiveCodec.write(output, ByteArrayInputStream("{}".toByteArray()), emptyList()) {
            error("No blobs expected")
        }
        val original = output.toByteArray()
        val zipEntries = ByteArrayOutputStream()
        ZipInputStream(ByteArrayInputStream(original)).use { input ->
            ZipOutputStream(zipEntries).use { zipOut ->
                while (true) {
                    val entry = input.nextEntry ?: break
                    val bytes = input.readBytes()
                    zipOut.putNextEntry(java.util.zip.ZipEntry(entry.name))
                    if (entry.name == BackupArchiveCodec.MANIFEST_ENTRY) {
                        zipOut.write(bytes.toString(Charsets.UTF_8).replace("\n2\n", "\n99\n").toByteArray())
                    } else zipOut.write(bytes)
                    zipOut.closeEntry()
                }
            }
        }
        val staging = createTempDir(prefix = "elios-archive-version-")
        try {
            assertThrows(IllegalArgumentException::class.java) {
                BackupArchiveCodec.extract(ByteArrayInputStream(zipEntries.toByteArray()), staging)
            }
        } finally { staging.deleteRecursively() }
    }

    @Test fun rejectsDuplicateBlobHashesBeforeWriting() {
        val bytes = "same".toByteArray()
        val blob = BackupArchiveCodec.Blob(hash(bytes), "bin", bytes.size.toLong())
        assertThrows(IllegalArgumentException::class.java) {
            BackupArchiveCodec.write(ByteArrayOutputStream(), ByteArrayInputStream("{}".toByteArray()), listOf(blob, blob)) {
                ByteArrayInputStream(bytes)
            }
        }
    }

    @Test fun rejectsPathTraversalEntriesBeforeWritingOutsideStaging() {
        val parent = createTempDir(prefix = "elios-archive-traversal-")
        val staging = File(parent, "staging")
        val escaped = File(parent, "escape.txt")
        val malicious = ByteArrayOutputStream().also { bytes ->
            ZipOutputStream(bytes).use { zip ->
                zip.putNextEntry(java.util.zip.ZipEntry("../escape.txt"))
                zip.write("must-not-escape".toByteArray())
                zip.closeEntry()
            }
        }.toByteArray()
        try {
            assertThrows(IllegalArgumentException::class.java) {
                BackupArchiveCodec.extract(ByteArrayInputStream(malicious), staging)
            }
            assertFalse("Archive entry must not create a file outside staging", escaped.exists())
            assertTrue("Failed extraction must clear its staging directory", staging.listFiles().isNullOrEmpty())
        } finally {
            parent.deleteRecursively()
        }
    }

}
