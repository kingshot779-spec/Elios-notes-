package com.eliosnotes.app.ui.editor

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class InkPointerPolicyTest {
    @Test fun stylusAndEraserCanDrawWhenFingerDrawingIsDisabled() {
        assertTrue(InkPointerPolicy.canStartInk(InkPointerDevice.STYLUS, false))
        assertTrue(InkPointerPolicy.canStartInk(InkPointerDevice.ERASER, false))
    }

    @Test fun fingerDrawingRespectsTheUserSetting() {
        assertFalse(InkPointerPolicy.canStartInk(InkPointerDevice.TOUCH, false))
        assertTrue(InkPointerPolicy.canStartInk(InkPointerDevice.TOUCH, true))
    }

    @Test fun mouseRemainsSupportedButUnknownDevicesDoNotStartInk() {
        assertTrue(InkPointerPolicy.canStartInk(InkPointerDevice.MOUSE, false))
        assertFalse(InkPointerPolicy.canStartInk(InkPointerDevice.OTHER, true))
    }

    @Test fun lassoRemainsAvailableToTouchInPenOnlyInkMode() {
        assertTrue(InkPointerPolicy.canStartLasso(InkPointerDevice.TOUCH))
        assertTrue(InkPointerPolicy.canStartLasso(InkPointerDevice.STYLUS))
        assertFalse(InkPointerPolicy.canStartLasso(InkPointerDevice.OTHER))
    }

    @Test fun stylusSuppressesConcurrentTouchButNotOtherStylus() {
        assertTrue(InkPointerPolicy.shouldSuppressConcurrentPointer(InkPointerDevice.STYLUS, InkPointerDevice.TOUCH))
        assertTrue(InkPointerPolicy.shouldSuppressConcurrentPointer(InkPointerDevice.ERASER, InkPointerDevice.TOUCH))
        assertFalse(InkPointerPolicy.shouldSuppressConcurrentPointer(InkPointerDevice.STYLUS, InkPointerDevice.STYLUS))
        assertFalse(InkPointerPolicy.shouldSuppressConcurrentPointer(InkPointerDevice.TOUCH, InkPointerDevice.TOUCH))
    }
}
