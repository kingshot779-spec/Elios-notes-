package com.eliosnotes.app.data.document

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertNotNull
import org.junit.Test

class PagePresentationPolicyTest {
    private fun page(id: String, index: Int) = NotePageEntity(
        id = id, noteId = "note", pageIndex = index,
        widthDp = PageSize.A4_WIDTH, heightDp = PageSize.A4_HEIGHT,
        createdAt = 1L, updatedAt = 2L
    )

    @Test fun templateChangeTargetsOnlyRequestedPageAndPreservesOtherMetadata() {
        val original = page("p1", 3).copy(backgroundColorArgb = 0xFF123456L)
        val changed = PagePresentationPolicy.withTemplate(original, PageTemplate.CORNELL, 9L)
        assertNotNull(changed)
        assertEquals(PageTemplate.CORNELL, changed!!.template)
        assertEquals(original.id, changed.id)
        assertEquals(original.pageIndex, changed.pageIndex)
        assertEquals(original.backgroundColorArgb, changed.backgroundColorArgb)
        assertEquals(9L, changed.updatedAt)
    }

    @Test fun unknownTemplateIsRejectedWithoutChangingStoredValue() {
        assertNull(PagePresentationPolicy.withTemplate(page("p1", 0), "FUTURE_TEMPLATE", 9L))
    }

    @Test fun backgroundChangePreservesTemplateAndGeometry() {
        val original = page("p1", 1).copy(template = PageTemplate.GRID, widthDp = 900f)
        val changed = PagePresentationPolicy.withBackground(original, 0xFFABCDEF, 10L)
        assertEquals(0xFFABCDEFL, changed.backgroundColorArgb)
        assertEquals(PageTemplate.GRID, changed.template)
        assertEquals(900f, changed.widthDp, 0f)
        assertEquals(original.id, changed.id)
    }

    @Test fun orientationChangesOnlyAnEmptyPageAndUsesA4Dimensions() {
        val original = page("p1", 0)
        val landscape = PagePresentationPolicy.withOrientation(original, PageOrientation.LANDSCAPE, true, 11L)
        assertNotNull(landscape)
        assertEquals(PageSize.A4_HEIGHT, landscape!!.widthDp, 0f)
        assertEquals(PageSize.A4_WIDTH, landscape.heightDp, 0f)
        assertNull(PagePresentationPolicy.withOrientation(original, PageOrientation.LANDSCAPE, false, 11L))
        assertNull(PagePresentationPolicy.withOrientation(original, "SIDEWAYS", true, 11L))
    }

    @Test fun allPaperTemplatesHaveStableIdentifiers() {
        assertEquals(
            listOf("BLANK", "RULED", "GRID", "DOTS", "MUSIC", "CORNELL", "ISOMETRIC", "PLANNER"),
            PageTemplate.supported
        )
    }
}
