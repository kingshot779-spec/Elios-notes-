package com.eliosnotes.app.recognition

import org.junit.Assert.assertEquals
import org.junit.Test

class RecognitionHeuristicsTest {
    @Test fun explicitArabicModeNeverSubstitutesEnglishCandidate() {
        assertEquals("مرحبا", RecognitionHeuristics.selectCandidate("مرحبا", "hello", RecognitionLanguage.ARABIC))
        assertEquals("", RecognitionHeuristics.selectCandidate("", "hello", RecognitionLanguage.ARABIC))
    }

    @Test fun explicitEnglishModeNeverSubstitutesArabicCandidate() {
        assertEquals("hello", RecognitionHeuristics.selectCandidate("مرحبا", "hello", RecognitionLanguage.ENGLISH))
        assertEquals("", RecognitionHeuristics.selectCandidate("مرحبا", "", RecognitionLanguage.ENGLISH))
    }

    @Test fun automaticModeUsesMixedScriptHeuristic() {
        assertEquals("مرحبا", RecognitionHeuristics.selectCandidate("مرحبا", "hello", RecognitionLanguage.AUTO))
    }

    @Test fun returnsOnlyNonBlankCandidate() {
        assertEquals("مرحبا", RecognitionHeuristics.chooseScriptCandidate("مرحبا", ""))
        assertEquals("hello", RecognitionHeuristics.chooseScriptCandidate("", "hello"))
    }

    @Test fun selectsArabicCandidateByArabicScriptPurity() {
        assertEquals(
            "السَّلَامُ عَلَيْكُمْ",
            RecognitionHeuristics.chooseScriptCandidate("السَّلَامُ عَلَيْكُمْ", "hello world from a longer candidate")
        )
    }

    @Test fun selectsEnglishCandidateByLatinScriptPurity() {
        assertEquals(
            "A longer English sentence",
            RecognitionHeuristics.chooseScriptCandidate("مرحبا hello", "A longer English sentence")
        )
    }

    @Test fun doesNotCompareRawCharacterCountsAcrossScripts() {
        val arabic = "هذا نص عربي"
        val english = "A very long English candidate containing many Latin letters"
        assertEquals(arabic, RecognitionHeuristics.chooseScriptCandidate(arabic, english))
    }

    @Test fun deterministicTiePrefersArabicCandidate() {
        assertEquals("مرحبا", RecognitionHeuristics.chooseScriptCandidate("مرحبا", "hello"))
    }

    @Test fun recognizesArabicExtendedLettersOutsideBasicBlock() {
        val extendedArabic = "ࢠࢡࢢ"
        assertEquals(extendedArabic, RecognitionHeuristics.chooseScriptCandidate(extendedArabic, "hello"))
    }

    @Test fun recognizesLatinExtendedLetters() {
        val latinExtended = "École déjà vu"
        assertEquals(latinExtended, RecognitionHeuristics.chooseScriptCandidate("مرحبا hello", latinExtended))
    }

    @Test fun ignoresCombiningMarksWhenScoringScriptPurity() {
        val arabicWithMarks = "اَّبْج"
        assertEquals(arabicWithMarks, RecognitionHeuristics.chooseScriptCandidate(arabicWithMarks, "hello"))
    }

    @Test fun handlesSupplementaryCodePointsWithoutSplittingSurrogates() {
        // A supplementary-plane letter is classified by its Unicode script as a single code point.
        val latin = String(Character.toChars(0x1DF00))
        assertEquals(latin, RecognitionHeuristics.chooseScriptCandidate("مرحبا hello", latin))
    }
}
