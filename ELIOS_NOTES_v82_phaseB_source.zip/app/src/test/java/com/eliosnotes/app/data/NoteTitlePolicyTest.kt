package com.eliosnotes.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class NoteTitlePolicyTest {
    @Test fun trimsWhitespace() { assertEquals("Lecture 1", NoteTitlePolicy.normalize("  Lecture 1  ")) }
    @Test fun rejectsBlankTitle() { assertNull(NoteTitlePolicy.normalize("  \n\t ")) }
    @Test fun removesControlCharacters() { assertEquals("ArabicEnglish", NoteTitlePolicy.normalize("Arabic\u0000English")) }
    @Test fun capsLength() { assertEquals(120, NoteTitlePolicy.normalize("x".repeat(140))?.length) }
    @Test fun editorDraftAllowsBlankTitle() { assertEquals("  ", NoteTitlePolicy.sanitizeDraft("  ")) }
    @Test fun editorDraftCapsLengthAndRemovesControls() {
        assertEquals(120, NoteTitlePolicy.sanitizeDraft("a\u0000" + "b".repeat(140)).length)
        assertEquals("ab", NoteTitlePolicy.sanitizeDraft("a\u0000b"))
    }
}
