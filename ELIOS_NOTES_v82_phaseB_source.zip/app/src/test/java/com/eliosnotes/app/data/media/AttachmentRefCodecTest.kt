package com.eliosnotes.app.data.media

import org.junit.Assert.*
import org.junit.Test

class AttachmentRefCodecTest {
    @Test fun roundTripsValidatedReference() {
        val original = StoredAttachment(
            sha256 = "a".repeat(64), extension = "png", byteCount = 1234,
            mimeType = "image/png", displayName = "photo.png"
        )
        assertEquals(original, AttachmentRefCodec.decodeOrNull(AttachmentRefCodec.encode(original)))
    }

    @Test fun rejectsUnknownPayloadVersion() {
        assertNull(AttachmentRefCodec.decodeOrNull("""{"version":99}"""))
    }

    @Test fun rejectsMalformedHashAndUnsafeNameIsNormalized() {
        val malformed = """{"version":1,"sha256":"bad","extension":"pdf","byteCount":10,"mimeType":"application/pdf","displayName":"../scan.pdf"}"""
        assertNull(AttachmentRefCodec.decodeOrNull(malformed))
        val valid = """{"version":1,"sha256":"${"b".repeat(64)}","extension":"pdf","byteCount":10,"mimeType":"application/pdf","displayName":"../scan.pdf"}"""
        assertEquals("scan.pdf", AttachmentRefCodec.decodeOrNull(valid)?.displayName)
    }
}
