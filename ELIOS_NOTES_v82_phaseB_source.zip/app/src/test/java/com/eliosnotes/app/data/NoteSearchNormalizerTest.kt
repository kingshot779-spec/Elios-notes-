package com.eliosnotes.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NoteSearchNormalizerTest {
    @Test
    fun ignoresArabicDiacriticsAndTatweel() {
        val query = NoteSearchNormalizer.normalize("الدرس")
        assertTrue(NoteSearchNormalizer.matches("اَلدَّرْسُ", query))
        assertTrue(NoteSearchNormalizer.matches("الـدرس", query))
    }

    @Test
    fun foldsAlefAndAlefMaqsuraVariants() {
        val query = NoteSearchNormalizer.normalize("ابراهيم على")
        assertTrue(NoteSearchNormalizer.matches("إبراهيم علي", query))
        assertTrue(NoteSearchNormalizer.matches("آبراهيم عَلَى", query))
    }

    @Test
    fun collapsesWhitespaceAndIgnoresCase() {
        assertEquals("hello world", NoteSearchNormalizer.normalize("  HELLO   World  "))
        assertTrue(NoteSearchNormalizer.matches("Hello\nWorld", "hello world"))
    }

    @Test
    fun doesNotChangeOriginalContent() {
        val original = "إِنَّ الطَّالِبَ يَكْتُبُ"
        NoteSearchNormalizer.normalize(original)
        assertEquals("إِنَّ الطَّالِبَ يَكْتُبُ", original)
    }
}
