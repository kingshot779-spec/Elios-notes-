package com.eliosnotes.app.data.document

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class PageOrderPolicyTest {
    private fun page(id: String, index: Int = 0) = NotePageEntity(
        id = id,
        noteId = "note",
        pageIndex = index,
        widthDp = 794f,
        heightDp = 1123f,
        createdAt = 1L,
        updatedAt = 1L
    )

    @Test
    fun insertAtBeginningPreservesExistingIdsAndNormalizesIndexes() {
        val first = page("first", 7)
        val second = page("second", 12)
        val inserted = page("new", 99)

        val result = PageOrderPolicy.insert(listOf(first, second), inserted, 0)

        assertEquals(listOf("new", "first", "second"), result.map { it.id })
        assertEquals(listOf(0, 1, 2), result.map { it.pageIndex })
        assertEquals(first.copy(pageIndex = 1), result[1])
        assertEquals(second.copy(pageIndex = 2), result[2])
    }

    @Test
    fun insertPreservesPagePresentationSettings() {
        val reference = page("reference").copy(
            widthDp = 900f,
            heightDp = 1200f,
            orientation = PageOrientation.LANDSCAPE,
            template = PageTemplate.GRID,
            backgroundColorArgb = 0xFF123456L
        )
        val inserted = page("inserted").copy(
            widthDp = reference.widthDp,
            heightDp = reference.heightDp,
            orientation = reference.orientation,
            template = reference.template,
            backgroundColorArgb = reference.backgroundColorArgb
        )

        val result = PageOrderPolicy.insert(listOf(reference), inserted, 0)

        assertEquals(inserted.copy(pageIndex = 0), result.first())
        assertEquals(reference.copy(pageIndex = 1), result.last())
    }

    @Test
    fun movePreservesPageContentAndNormalizesIndexes() {
        val pages = listOf(page("a"), page("b"), page("c"))

        val result = PageOrderPolicy.move(pages, 0, 2)

        assertEquals(listOf("b", "c", "a"), result.map { it.id })
        assertEquals(listOf(0, 1, 2), result.map { it.pageIndex })
        assertEquals("a", result[2].id)
    }

    @Test
    fun invalidMoveIsSafeAndDoesNotReorderPages() {
        val pages = listOf(page("a"), page("b"))

        val result = PageOrderPolicy.move(pages, -1, 1)

        assertEquals(listOf("a", "b"), result.map { it.id })
        assertEquals(listOf(0, 1), result.map { it.pageIndex })
    }

    @Test
    fun reorderRejectsMissingDuplicateOrUnknownIds() {
        val pages = listOf(page("a"), page("b"))

        assertThrows(IllegalArgumentException::class.java) {
            PageOrderPolicy.reorderByIds(pages, listOf("a"))
        }
        assertThrows(IllegalArgumentException::class.java) {
            PageOrderPolicy.reorderByIds(pages, listOf("a", "a"))
        }
        assertThrows(IllegalArgumentException::class.java) {
            PageOrderPolicy.reorderByIds(pages, listOf("a", "unknown"))
        }
    }

    @Test
    fun reorderByIdsPreservesPageIdentityAndPresentationMetadata() {
        val first = page("first").copy(
            widthDp = 900f, heightDp = 1200f, orientation = PageOrientation.LANDSCAPE,
            template = PageTemplate.GRID, backgroundColorArgb = 0xFF123456L
        )
        val second = page("second").copy(
            widthDp = 700f, heightDp = 1000f, orientation = PageOrientation.PORTRAIT,
            template = PageTemplate.DOTS, backgroundColorArgb = 0xFFABCDEF
        )

        val result = PageOrderPolicy.reorderByIds(listOf(first, second), listOf("second", "first"))

        assertEquals(listOf("second", "first"), result.map { it.id })
        assertEquals(listOf(0, 1), result.map { it.pageIndex })
        assertEquals(second.copy(pageIndex = 0), result[0])
        assertEquals(first.copy(pageIndex = 1), result[1])
    }

    @Test
    fun insertRejectsDuplicatePageIdentity() {
        assertThrows(IllegalArgumentException::class.java) {
            PageOrderPolicy.insert(listOf(page("same")), page("same"), 0)
        }
    }
}
