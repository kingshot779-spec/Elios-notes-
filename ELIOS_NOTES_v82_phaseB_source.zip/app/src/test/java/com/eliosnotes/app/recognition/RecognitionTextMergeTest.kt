package com.eliosnotes.app.recognition

import org.junit.Assert.assertEquals
import org.junit.Test

class RecognitionTextMergeTest {
    @Test fun appendsUsingRealLineBreak() {
        val result = RecognitionTextMerge.append("ملاحظة قديمة", "نص جديد")
        assertEquals("ملاحظة قديمة\nنص جديد", result)
        assertEquals(-1, result.indexOf("\\n"))
    }

    @Test fun trimsOnlyTheBoundaryAndPreservesExistingContent() {
        assertEquals(
            "السطر الأول\nالسطر الثاني\nنتيجة التعرف",
            RecognitionTextMerge.append("السطر الأول\nالسطر الثاني  ", "  نتيجة التعرف  ")
        )
    }

    @Test fun blankRecognitionDoesNotChangeExistingText() {
        assertEquals("النص الأصلي  ", RecognitionTextMerge.append("النص الأصلي  ", " \n "))
    }

    @Test fun emptyExistingTextReturnsTrimmedRecognition() {
        assertEquals("Recognized text", RecognitionTextMerge.append(" \n", " Recognized text "))
    }
}
