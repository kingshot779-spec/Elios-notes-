package com.eliosnotes.app.ink

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LassoGeometryTest {
    private fun stroke(id: String, points: List<InkPoint>) =
        Stroke(id, InkTool.PEN, 0xFF123456.toInt(), 3f, points)

    private val square = listOf(
        InkPoint(10f, 10f), InkPoint(100f, 10f),
        InkPoint(100f, 100f), InkPoint(10f, 100f)
    )

    @Test fun selectsStrokeInsidePolygon() {
        val s = stroke("inside", listOf(InkPoint(20f, 20f), InkPoint(40f, 40f)))
        assertTrue(LassoGeometry.intersects(s, square))
    }

    @Test fun rejectsStrokeOutsidePolygon() {
        val s = stroke("outside", listOf(InkPoint(150f, 150f), InkPoint(180f, 180f)))
        assertFalse(LassoGeometry.intersects(s, square))
    }

    @Test fun selectsSegmentCrossingPolygonEvenWhenEndpointsAreOutside() {
        val s = stroke("cross", listOf(InkPoint(0f, 50f), InkPoint(120f, 50f)))
        assertTrue(LassoGeometry.intersects(s, square))
    }

    @Test fun selectsThickStrokeWhoseEdgeTouchesPolygon() {
        val s = Stroke("thick", InkTool.PEN, 0xFF123456.toInt(), 8f,
            listOf(InkPoint(5f, 50f), InkPoint(5f, 70f)))
        assertTrue(LassoGeometry.intersects(s, square))
    }

    @Test fun rejectsThinStrokeOutsidePolygonEvenWhenBoundsOverlapBroadly() {
        val s = Stroke("thin", InkTool.PEN, 0xFF123456.toInt(), 1f,
            listOf(InkPoint(5f, 50f), InkPoint(5f, 70f)))
        assertFalse(LassoGeometry.intersects(s, square))
    }

    @Test fun selectionReturnsOnlyIntersectingStrokeIds() {
        val strokes = listOf(
            stroke("a", listOf(InkPoint(20f, 20f))),
            stroke("b", listOf(InkPoint(150f, 150f)))
        )
        assertEquals(setOf("a"), LassoGeometry.select(strokes, square))
    }

    @Test fun translationPreservesStrokeIdentityStyleAndPressure() {
        val original = stroke("a", listOf(InkPoint(20f, 30f, 0.8f)))
        val untouched = stroke("b", listOf(InkPoint(200f, 200f)))
        val moved = LassoGeometry.translate(listOf(original, untouched), setOf("a"), 5f, -7f)
        assertEquals("a", moved[0].id)
        assertEquals(original.tool, moved[0].tool)
        assertEquals(original.colorArgb, moved[0].colorArgb)
        assertEquals(original.width, moved[0].width)
        assertEquals(25f, moved[0].points[0].x, 0.001f)
        assertEquals(23f, moved[0].points[0].y, 0.001f)
        assertEquals(0.8f, moved[0].points[0].pressure, 0.001f)
        assertEquals(untouched.points[0].x, moved[1].points[0].x, 0.001f)
    }
}
