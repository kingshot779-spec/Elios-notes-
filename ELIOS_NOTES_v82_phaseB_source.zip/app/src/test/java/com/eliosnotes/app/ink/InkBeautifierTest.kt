package com.eliosnotes.app.ink

import org.junit.Assert.*
import org.junit.Test

class InkBeautifierTest {
    private fun sample() = Stroke(
        id = "stable-id",
        tool = InkTool.PEN,
        colorArgb = 0xFF123456.toInt(),
        width = 3f,
        points = listOf(
            InkPoint(0f, 0f, 0.2f),
            InkPoint(10f, 2f, 0.4f),
            InkPoint(20f, -2f, 0.8f),
            InkPoint(30f, 1f, 0.6f),
            InkPoint(40f, 0f, 0.5f)
        )
    )

    @Test fun emptyAndShortStrokesArePreserved() {
        val short = sample().derive("short", sample().points.take(3))
        val input = listOf(short)
        assertSame(input, InkBeautifier.beautify(input, InkBeautificationLevel.STRONG))
        assertSame(emptyList<Stroke>(), InkBeautifier.beautify(emptyList(), InkBeautificationLevel.MEDIUM))
    }

    @Test fun smoothingPreservesEndpointsIdentityAndStyle() {
        val original = sample()
        val result = InkBeautifier.beautify(listOf(original), InkBeautificationLevel.MEDIUM).single()
        assertEquals(original.id, result.id)
        assertEquals(original.tool, result.tool)
        assertEquals(original.colorArgb, result.colorArgb)
        assertEquals(original.width, result.width)
        assertEquals(original.points.first(), result.points.first())
        assertEquals(original.points.last(), result.points.last())
        assertEquals(original.points.size, result.points.size)
        assertNotEquals(original.points, result.points)
    }

    @Test fun inputIsNotMutatedAndRepeatedOutputIsDeterministic() {
        val original = sample()
        val input = listOf(original)
        val first = InkBeautifier.beautify(input, InkBeautificationLevel.STRONG)
        val second = InkBeautifier.beautify(input, InkBeautificationLevel.STRONG)
        assertSame(original, input.single())
        assertEquals(first.single().points, second.single().points)
        assertEquals(sample().points, original.points)
    }

    @Test fun malformedNonFiniteStrokeIsLeftUntouched() {
        val malformed = sample().derive(
            "malformed",
            sample().points.toMutableList().also { it[2] = InkPoint(Float.NaN, 2f, 0.5f) }
        )
        val input = listOf(malformed)
        assertSame(input, InkBeautifier.beautify(input, InkBeautificationLevel.STRONG))
    }

    @Test fun strongerLevelDoesNotMoveEndpointsOrChangePointCount() {
        val original = sample()
        val light = InkBeautifier.beautify(listOf(original), InkBeautificationLevel.LIGHT).single()
        val strong = InkBeautifier.beautify(listOf(original), InkBeautificationLevel.STRONG).single()
        assertEquals(original.points.size, strong.points.size)
        assertEquals(original.points.first(), strong.points.first())
        assertEquals(original.points.last(), strong.points.last())
        assertNotEquals(light.points, strong.points)
        assertTrue(strong.points.all { it.pressure in 0f..1f })
    }
}
