package com.eliosnotes.app.ink

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class StrokeClipboardTest {
    private fun stroke(id: String, x: Float) = Stroke(
        id, InkTool.PEN, 0xFF123456.toInt(), 4f, listOf(InkPoint(x, 30f, 0.8f))
    )

    @Test fun copyKeepsOnlySelectedStrokes() {
        val clipboard = StrokeClipboard()
        clipboard.copy(listOf(stroke("a", 10f), stroke("b", 20f)), setOf("b"))
        val pasted = clipboard.paste()
        assertEquals(1, pasted.size)
        assertEquals(44f, pasted.single().points.single().x, 0.001f)
    }

    @Test fun pasteCreatesFreshIdsAndPreservesStyleAndPressure() {
        val clipboard = StrokeClipboard(newId = { "fresh-id" })
        val original = stroke("source", 10f)
        clipboard.copy(listOf(original), setOf("source"))
        val pasted = clipboard.paste(5f, -7f).single()
        assertNotEquals(original.id, pasted.id)
        assertEquals(original.tool, pasted.tool)
        assertEquals(original.colorArgb, pasted.colorArgb)
        assertEquals(original.width, pasted.width, 0.001f)
        assertEquals(15f, pasted.points.single().x, 0.001f)
        assertEquals(23f, pasted.points.single().y, 0.001f)
        assertEquals(0.8f, pasted.points.single().pressure, 0.001f)
        assertEquals(10f, original.points.single().x, 0.001f)
    }

    @Test fun clipboardUsesDefensiveSnapshotOfMutablePointList() {
        val mutablePoints = mutableListOf(InkPoint(10f, 20f, 0.5f))
        val original = Stroke("source", InkTool.PEN, 7, 3f, mutablePoints)
        val clipboard = StrokeClipboard(newId = { "copy" })
        clipboard.copy(listOf(original), setOf("source"))
        mutablePoints[0] = InkPoint(900f, 900f, 1f)
        val pasted = clipboard.paste(0f, 0f).single()
        assertEquals(10f, pasted.points.single().x, 0.001f)
        assertEquals(20f, pasted.points.single().y, 0.001f)
    }

    @Test fun repeatedPastesRequireUniqueFreshIds() {
        var next = 0
        val clipboard = StrokeClipboard(newId = { "copy-${++next}" })
        clipboard.copy(listOf(stroke("source", 1f), stroke("second", 2f)), setOf("source", "second"))
        val pasted = clipboard.paste()
        assertEquals(2, pasted.map { it.id }.toSet().size)
        assertTrue(pasted.none { it.id == "source" || it.id == "second" })
    }

    @Test fun rejectsIdGeneratorThatReusesAnId() {
        val clipboard = StrokeClipboard(newId = { "same" })
        clipboard.copy(listOf(stroke("a", 1f), stroke("b", 2f)), setOf("a", "b"))
        assertThrows(IllegalArgumentException::class.java) { clipboard.paste() }
    }

    @Test fun rejectsCoordinateOverflowAfterOffset() {
        val clipboard = StrokeClipboard(newId = { "copy" })
        clipboard.copy(listOf(stroke("a", 999_999f)), setOf("a"))
        assertThrows(IllegalArgumentException::class.java) { clipboard.paste(2f, 0f) }
    }

    @Test fun emptySelectionClearsClipboard() {
        val clipboard = StrokeClipboard()
        clipboard.copy(listOf(stroke("a", 10f)), setOf("a"))
        clipboard.copy(listOf(stroke("a", 10f)), emptySet())
        assertTrue(clipboard.isEmpty)
        assertTrue(clipboard.paste().isEmpty())
    }
}
