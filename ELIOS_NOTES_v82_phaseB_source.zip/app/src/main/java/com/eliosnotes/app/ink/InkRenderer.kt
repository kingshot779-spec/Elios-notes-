package com.eliosnotes.app.ink

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Draws strokes in page units onto any android.graphics.Canvas. The same code paints the
 * on-screen page and the exported PDF, so what you see is what you export.
 * Not thread-safe: use one instance per drawing pass/thread.
 */
class InkPainter {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()

    fun draw(canvas: Canvas, s: Stroke) {
        val pts = s.points
        if (pts.isEmpty()) return
        val alphaMul = when (s.tool) {
            InkTool.PENCIL -> 0.8f
            InkTool.HIGHLIGHTER -> 0.35f
            else -> 1f
        }
        paint.color = s.colorArgb
        paint.alpha = (Color.alpha(s.colorArgb) * alphaMul).roundToInt().coerceIn(0, 255)
        paint.strokeCap = if (s.tool == InkTool.HIGHLIGHTER) Paint.Cap.SQUARE else Paint.Cap.ROUND

        if (pts.size == 1) {
            paint.style = Paint.Style.FILL
            canvas.drawCircle(pts[0].x, pts[0].y, s.width / 2f, paint)
            paint.style = Paint.Style.STROKE
            return
        }

        val pressureSensitive = (s.tool == InkTool.PEN || s.tool == InkTool.PENCIL) && pressureVaries(pts)
        if (pressureSensitive) {
            for (i in 1 until pts.size) {
                val a = pts[i - 1]
                val b = pts[i]
                paint.strokeWidth = s.width * pressureFactor(s.tool, (a.pressure + b.pressure) / 2f)
                canvas.drawLine(a.x, a.y, b.x, b.y, paint)
            }
        } else {
            paint.strokeWidth = s.width
            path.rewind()
            path.moveTo(pts[0].x, pts[0].y)
            if (pts.size == 2) {
                path.lineTo(pts[1].x, pts[1].y)
            } else {
                for (i in 1 until pts.size - 1) {
                    val a = pts[i]
                    val b = pts[i + 1]
                    path.quadTo(a.x, a.y, (a.x + b.x) / 2f, (a.y + b.y) / 2f)
                }
                path.lineTo(pts.last().x, pts.last().y)
            }
            canvas.drawPath(path, paint)
        }
    }

    // Devices without pressure report a constant value; treat that as "no pressure".
    private fun pressureVaries(pts: List<InkPoint>): Boolean {
        val first = pts[0].pressure
        for (p in pts) if (abs(p.pressure - first) > 0.02f) return true
        return false
    }

    private fun pressureFactor(tool: InkTool, p: Float): Float =
        if (tool == InkTool.PENCIL) 0.6f + 0.6f * p else 0.45f + 1.0f * p
}

object PageBackgrounds {
    const val SPACING = 32f

    /** Fills the page with its colour and a deterministic paper template. Coordinates are page units. */
    fun draw(canvas: Canvas, template: String, bgArgb: Int, w: Float, h: Float) {
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bgArgb; style = Paint.Style.FILL }
        canvas.drawRect(0f, 0f, w, h, fill)

        val luminance = (0.299f * Color.red(bgArgb) + 0.587f * Color.green(bgArgb) + 0.114f * Color.blue(bgArgb)) / 255f
        val lineColor = if (luminance < 0.5f) Color.argb(72, 255, 255, 255) else Color.argb(88, 70, 90, 120)
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = lineColor
            strokeWidth = 1f
            style = Paint.Style.STROKE
        }
        when (template) {
            "RULED" -> drawRuled(canvas, line, w, h, 88f)
            "GRID" -> drawGrid(canvas, line, w, h, SPACING, SPACING)
            "DOTS" -> drawDots(canvas, line, w, h, SPACING)
            "MUSIC" -> drawMusic(canvas, line, w, h)
            "CORNELL" -> drawCornell(canvas, line, w, h)
            "ISOMETRIC" -> drawIsometric(canvas, line, w, h)
            "PLANNER" -> drawPlanner(canvas, line, w, h)
            // Unknown template identifiers are intentionally rendered as plain paper.
        }
    }

    private fun drawRuled(canvas: Canvas, paint: Paint, w: Float, h: Float, start: Float) {
        var y = start
        while (y < h - 24f) { canvas.drawLine(0f, y, w, y, paint); y += SPACING }
    }

    private fun drawGrid(canvas: Canvas, paint: Paint, w: Float, h: Float, dx: Float, dy: Float) {
        var y = dy
        while (y < h) { canvas.drawLine(0f, y, w, y, paint); y += dy }
        var x = dx
        while (x < w) { canvas.drawLine(x, 0f, x, h, paint); x += dx }
    }

    private fun drawDots(canvas: Canvas, paint: Paint, w: Float, h: Float, spacing: Float) {
        val dots = Paint(paint).apply { style = Paint.Style.FILL; strokeWidth = 1f }
        var y = spacing
        while (y < h) {
            var x = spacing
            while (x < w) { canvas.drawCircle(x, y, 1.6f, dots); x += spacing }
            y += spacing
        }
    }

    private fun drawMusic(canvas: Canvas, paint: Paint, w: Float, h: Float) {
        val groupHeight = 176f
        var top = 72f
        while (top + 4 * 12f < h) {
            for (i in 0..4) canvas.drawLine(36f, top + i * 12f, w - 36f, top + i * 12f, paint)
            top += groupHeight
        }
    }

    private fun drawCornell(canvas: Canvas, paint: Paint, w: Float, h: Float) {
        drawRuled(canvas, paint, w, h, 88f)
        val divider = Paint(paint).apply { strokeWidth = 1.4f }
        canvas.drawLine(w * 0.28f, 56f, w * 0.28f, h - 32f, divider)
        canvas.drawLine(36f, 72f, w - 36f, 72f, divider)
        canvas.drawLine(36f, h - 88f, w - 36f, h - 88f, divider)
    }

    private fun drawIsometric(canvas: Canvas, paint: Paint, w: Float, h: Float) {
        val spacing = 28f
        val rise = spacing * 0.8660254f
        var y = -h
        while (y < h * 2f) {
            canvas.drawLine(0f, y, w, y + w * 0.57735f, paint)
            canvas.drawLine(0f, y, w, y - w * 0.57735f, paint)
            y += rise
        }
        var x = 0f
        while (x < w) { canvas.drawLine(x, 0f, x, h, paint); x += spacing }
    }

    private fun drawPlanner(canvas: Canvas, paint: Paint, w: Float, h: Float) {
        val margin = 36f
        val headerBottom = 132f
        canvas.drawRect(margin, margin, w - margin, headerBottom, paint)
        val contentTop = headerBottom + 24f
        canvas.drawLine(w / 2f, contentTop, w / 2f, h - margin, paint)
        var y = contentTop + 72f
        while (y < h - margin) { canvas.drawLine(margin, y, w - margin, y, paint); y += 72f }
        canvas.drawLine(margin, contentTop, w - margin, contentTop, paint)
        // Small check circles make the planner rows visually scannable without adding text.
        val marker = Paint(paint).apply { style = Paint.Style.STROKE; strokeWidth = 1.2f }
        y = contentTop + 36f
        while (y < h - margin) {
            canvas.drawCircle(margin + 18f, y, 5f, marker)
            canvas.drawCircle(w / 2f + 18f, y, 5f, marker)
            y += 72f
        }
    }
}
