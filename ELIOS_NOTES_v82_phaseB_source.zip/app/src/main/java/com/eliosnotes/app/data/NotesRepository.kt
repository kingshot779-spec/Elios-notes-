package com.eliosnotes.app.data

import androidx.room.withTransaction
import com.eliosnotes.app.data.document.NoteDocument
import com.eliosnotes.app.data.document.NoteElementDao
import com.eliosnotes.app.data.document.NoteElementEntity
import com.eliosnotes.app.data.document.NoteElementType
import com.eliosnotes.app.data.document.NotePageDao
import com.eliosnotes.app.data.document.NotePageEntity
import com.eliosnotes.app.data.document.PageContent
import com.eliosnotes.app.data.document.PageOrderPolicy
import com.eliosnotes.app.data.document.PageAttachment
import com.eliosnotes.app.data.document.PageOrientation
import com.eliosnotes.app.data.document.PageSize
import com.eliosnotes.app.data.document.PageTemplate
import com.eliosnotes.app.data.document.TextCodec
import com.eliosnotes.app.data.media.AttachmentStorage
import com.eliosnotes.app.data.media.AttachmentReconciliationResult
import com.eliosnotes.app.data.media.AttachmentRefCodec
import com.eliosnotes.app.data.media.StoredAttachment
import com.eliosnotes.app.data.backup.BackupArchiveCodec
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import com.eliosnotes.app.ink.InkCodec
import com.eliosnotes.app.ink.Stroke
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.util.JsonWriter
import java.io.InputStream
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.util.UUID
import java.util.LinkedHashMap
import java.util.LinkedHashSet

/**
 * Single entry point for document persistence. Text and ink of a page are written in one
 * transaction, and all operations share one lock so a save can never interleave with a load.
 */
class NotesRepository(private val db: NotesDatabase, private val attachmentStorage: AttachmentStorage) {
    val noteDao: NoteDao = db.noteDao()
    val folderDao: FolderDao = db.folderDao()
    private val pageDao: NotePageDao = db.notePageDao()
    private val elementDao: NoteElementDao = db.noteElementDao()
    private val lock = Mutex()

    fun newPage(noteId: String, index: Int, now: Long) = NotePageEntity(
        id = UUID.randomUUID().toString(),
        noteId = noteId,
        pageIndex = index,
        widthDp = PageSize.A4_WIDTH,
        heightDp = PageSize.A4_HEIGHT,
        orientation = PageOrientation.PORTRAIT,
        template = PageTemplate.BLANK,
        createdAt = now,
        updatedAt = now
    )

    suspend fun createNote(folderId: String?): NoteEntity = lock.withLock {
        db.withTransaction {
            val now = System.currentTimeMillis()
            val note = NoteEntity(
                id = UUID.randomUUID().toString(),
                title = "", body = "", createdAt = now, updatedAt = now, folderId = folderId
            )
            noteDao.insert(note)
            pageDao.insert(newPage(note.id, 0, now))
            note
        }
    }

    suspend fun loadDocument(noteId: String): NoteDocument? = lock.withLock {
        db.withTransaction {
            val note = noteDao.getById(noteId) ?: return@withTransaction null
            var pages = pageDao.getPages(noteId)
            if (pages.isEmpty()) {
                // Notes created before the page model existed get their first page lazily.
                val first = newPage(noteId, 0, System.currentTimeMillis())
                pageDao.insert(first)
                pages = listOf(first)
            }
            val now = System.currentTimeMillis()
            val noteHasTextElement = pages.any { pg ->
                elementDao.getElements(pg.id).any { it.elementType == NoteElementType.TEXT }
            }
            val content = pages.mapIndexed { index, page ->
                var text = ""
                var hasTextElement = false
                var textLocked = false
                val strokes = ArrayList<Stroke>()
                val lockedInk = HashSet<String>()
                val attachments = ArrayList<PageAttachment>()
                for (e in elementDao.getElements(page.id)) {
                    when (e.elementType) {
                        NoteElementType.TEXT -> {
                            hasTextElement = true
                            val decoded = if (e.payloadVersion > TEXT_PAYLOAD_VERSION) null else TextCodec.decodeOrNull(e.payloadJson)
                            if (decoded == null) textLocked = true else text = decoded
                        }
                        NoteElementType.ATTACHMENT, NoteElementType.IMAGE, NoteElementType.VIDEO, NoteElementType.AUDIO, NoteElementType.PDF_CONTENT -> {
                            AttachmentRefCodec.decodeOrNull(e.payloadJson)?.let { attachments.add(PageAttachment(e.id, it)) }
                        }
                        NoteElementType.INK -> {
                            val stroke = if (e.payloadVersion > InkCodec.PAYLOAD_VERSION) null else InkCodec.decode(e.id, e.payloadJson)
                            if (stroke == null) lockedInk.add(e.id) else strokes.add(stroke)
                        }
                    }
                }
                // Legacy v1 note: its text lived in notes.body. Copy it into the first page's TEXT
                // element right now. Without this, saving any other page would rebuild the body from
                // TEXT elements only and silently replace the legacy text.
                if (!hasTextElement && index == 0 && !noteHasTextElement && note.body.isNotEmpty()) {
                    text = note.body
                    elementDao.upsert(
                        NoteElementEntity(
                            id = "text-${page.id}", pageId = page.id, elementType = NoteElementType.TEXT,
                            payloadVersion = TEXT_PAYLOAD_VERSION, payloadJson = TextCodec.encode(text),
                            x = 0f, y = 0f, width = page.widthDp, height = page.heightDp,
                            zIndex = 0, createdAt = now, updatedAt = now
                        )
                    )
                }
                PageContent(page, text, strokes, textLocked, lockedInk, attachments)
            }
            NoteDocument(note, content)
        }
    }

    /** Imports a binary into private storage, then commits its reference to the page. */
    suspend fun addAttachment(
        pageId: String,
        input: InputStream,
        displayName: String,
        mimeType: String
    ): StoredAttachment = lock.withLock {
        val stored = attachmentStorage.import(input, displayName, mimeType)
        try {
            db.withTransaction {
                val page = pageDao.getById(pageId) ?: error("Page no longer exists")
                val now = System.currentTimeMillis()
                val type = when {
                    stored.mimeType.startsWith("image/") -> NoteElementType.IMAGE
                    stored.mimeType.startsWith("video/") -> NoteElementType.VIDEO
                    stored.mimeType.startsWith("audio/") -> NoteElementType.AUDIO
                    stored.mimeType == "application/pdf" -> NoteElementType.PDF_CONTENT
                    else -> NoteElementType.ATTACHMENT
                }
                elementDao.upsert(
                    NoteElementEntity(
                        id = "attachment-${UUID.randomUUID()}", pageId = pageId,
                        elementType = type, payloadVersion = AttachmentRefCodec.VERSION,
                        payloadJson = AttachmentRefCodec.encode(stored),
                        x = 24f, y = 24f, width = 0f, height = 0f,
                        zIndex = elementDao.getElements(pageId).size,
                        createdAt = now, updatedAt = now
                    )
                )
                pageDao.touch(page.id, now)
            }
            stored
        } catch (failure: Throwable) {
            // A failed DB commit must not leave an unreferenced binary behind.
            if (runCatching { elementDao.countPayloadReferences(stored.sha256) == 0 && attachmentStorage.delete(stored) }.isFailure) {
                /* A failed cleanup leaves a recoverable orphan; never delete a shared blob. */
            }
            throw failure
        }
    }

    /** Removes the page reference; shared content-addressed blobs survive while referenced elsewhere. */
    suspend fun removeAttachment(elementId: String): Boolean = lock.withLock {
        val element = elementDao.getById(elementId) ?: return@withLock false
        val ref = AttachmentRefCodec.decodeOrNull(element.payloadJson) ?: return@withLock false
        db.withTransaction { elementDao.deleteById(elementId) }
        if (elementDao.countPayloadReferences(ref.sha256) == 0) attachmentStorage.delete(ref)
        true
    }

    fun openAttachment(ref: StoredAttachment): InputStream = attachmentStorage.open(ref)

    fun attachmentFile(ref: StoredAttachment): java.io.File = attachmentStorage.resolve(ref)

    fun verifyAttachment(ref: StoredAttachment): Boolean = attachmentStorage.verify(ref)

    /**
     * Conservatively reconciles app-private attachment files against every media element in Room.
     * The repository mutex excludes imports, removals, saves and both restore paths for the entire
     * scan. File enumeration, hashing and deletion run on IO. A single undecodable media payload
     * disables attachment-blob deletion for this pass; only old, recognizably app-owned temp files
     * remain eligible.
     */
    suspend fun reconcileOrphanAttachments(
        nowMillis: Long = System.currentTimeMillis(),
        gracePeriodMillis: Long = AttachmentStorage.DEFAULT_RECONCILIATION_GRACE_MS
    ): AttachmentReconciliationResult = lock.withLock {
        val elements = elementDao.getAllElements()
        val references = AttachmentRefCodec.collectReferencedKeys(
            elements.map { it.elementType to it.payloadJson },
            MEDIA_ELEMENT_TYPES
        )
        withContext(Dispatchers.IO) {
            attachmentStorage.reconcile(
                referencedKeys = references,
                nowMillis = nowMillis,
                gracePeriodMillis = gracePeriodMillis
            )
        }
    }

    suspend fun saveTitle(noteId: String, title: String) = lock.withLock {
        noteDao.updateTitle(noteId, title, System.currentTimeMillis())
    }

    suspend fun savePage(
        noteId: String,
        pageId: String,
        text: String,
        strokes: List<Stroke>,
        writeText: Boolean = true,
        protectedInkIds: Set<String> = emptySet()
    ) = lock.withLock {
        db.withTransaction {
            val page = pageDao.getById(pageId) ?: return@withTransaction // page was deleted meanwhile
            val now = System.currentTimeMillis()

            if (writeText) {
                elementDao.upsert(
                    NoteElementEntity(
                        id = "text-$pageId", pageId = pageId, elementType = NoteElementType.TEXT,
                        payloadVersion = TEXT_PAYLOAD_VERSION, payloadJson = TextCodec.encode(text),
                        x = 0f, y = 0f, width = page.widthDp, height = page.heightDp,
                        zIndex = 0, createdAt = now, updatedAt = now
                    )
                )
            }

            // Elements we could not decode are neither rewritten nor deleted.
            val existing = elementDao.getIdsByType(pageId, NoteElementType.INK).toSet() - protectedInkIds
            val currentIds = strokes.mapTo(HashSet()) { it.id }
            val stale = existing - currentIds
            stale.toList().chunked(400).forEach { elementDao.deleteByIds(it) }

            val fresh = strokes.filter { it.id !in existing }
            val pureAppend = stale.isEmpty() &&
                strokes.size - fresh.size == existing.size &&
                strokes.take(existing.size).all { it.id in existing }
            // Appending keeps old z-order valid; anything else rewrites the z-order of the page.
            val toWrite = if (pureAppend) fresh else strokes
            val offset = if (pureAppend) existing.size else 0
            elementDao.upsertAll(toWrite.mapIndexed { i, s -> strokeElement(pageId, s, offset + i, now) })

            pageDao.touch(pageId, now)
            refreshSearchBodyIfSafe(noteId, now, clearWhenEmpty = false)
        }
    }

    /**
     * Rebuilds the legacy note-body search mirror only from a complete, decodable TEXT snapshot.
     * Protected/newer payloads must never turn into empty text through the compatibility decoder.
     */
    private suspend fun refreshSearchBodyIfSafe(
        noteId: String,
        now: Long,
        clearWhenEmpty: Boolean
    ) {
        val payloads = elementDao.getTextPayloads(noteId)
        if (payloads.isEmpty()) {
            if (clearWhenEmpty) noteDao.updateContent(noteId, "", now)
            return
        }
        val decoded = payloads.map { TextCodec.decodeOrNull(it) }
        if (decoded.any { it == null }) return
        val body = decoded.filterNotNull().filter { it.isNotBlank() }.joinToString("\n")
        noteDao.updateContent(noteId, body, now)
    }

    private companion object {
        const val TEXT_PAYLOAD_VERSION = 1
        val MEDIA_ELEMENT_TYPES = setOf(
            NoteElementType.ATTACHMENT, NoteElementType.IMAGE, NoteElementType.VIDEO,
            NoteElementType.AUDIO, NoteElementType.PDF_CONTENT
        )
    }

    private fun strokeElement(pageId: String, s: Stroke, z: Int, now: Long): NoteElementEntity {
        val b = s.bounds
        return NoteElementEntity(
            id = s.id, pageId = pageId, elementType = NoteElementType.INK,
            payloadVersion = InkCodec.PAYLOAD_VERSION, payloadJson = InkCodec.encode(s),
            x = b[0], y = b[1], width = b[2] - b[0], height = b[3] - b[1],
            zIndex = z, createdAt = now, updatedAt = now
        )
    }

    suspend fun insertPage(page: NotePageEntity) = lock.withLock { pageDao.insert(page) }

    /** Inserts a page at the requested position and renumbers siblings atomically. */
    suspend fun insertPageAt(noteId: String, page: NotePageEntity, requestedIndex: Int) = lock.withLock {
        require(page.noteId == noteId) { "Page belongs to a different note" }
        db.withTransaction {
            val existing = pageDao.getPages(noteId)
            val ordered = PageOrderPolicy.insert(existing, page, requestedIndex)
            val inserted = ordered.first { it.id == page.id }
            pageDao.insert(inserted)
            pageDao.updateAll(ordered.filterNot { it.id == page.id })
        }
    }

    /**
     * Duplicates one page, including every element payload, without reusing database identities.
     * Attachment payloads are intentionally shared: blobs are content-addressed and remain alive
     * while any page element references them. Unknown/future element payloads are copied verbatim.
     */
    suspend fun duplicatePage(noteId: String, sourcePageId: String): String = lock.withLock {
        db.withTransaction {
            require(noteDao.getById(noteId) != null) { "Note no longer exists" }
            val existing = pageDao.getPages(noteId)
            val sourcePosition = existing.indexOfFirst { it.id == sourcePageId }
            val source = existing.getOrNull(sourcePosition)
                ?: throw IllegalArgumentException("Source page does not belong to this note")
            val insertionIndex = sourcePosition + 1
            val now = System.currentTimeMillis()
            val newPageId = UUID.randomUUID().toString()
            val clone = source.copy(
                id = newPageId,
                pageIndex = insertionIndex,
                createdAt = now,
                updatedAt = now
            )
            val ordered = PageOrderPolicy.insert(existing, clone, insertionIndex)
            pageDao.insert(ordered.first { it.id == newPageId })
            pageDao.updateAll(ordered.filterNot { it.id == newPageId })

            val sourceElements = elementDao.getElements(sourcePageId)
            require(sourceElements.count { it.elementType == NoteElementType.TEXT } <= 1) {
                "Page contains multiple text payload rows and cannot be duplicated safely"
            }
            if (sourceElements.isNotEmpty()) {
                elementDao.insertAllAbort(sourceElements.map { element ->
                    element.copy(
                        // The editor's single page-text element uses this stable ID on every save.
                        id = if (element.elementType == NoteElementType.TEXT) "text-$newPageId"
                            else UUID.randomUUID().toString(),
                        pageId = newPageId,
                        createdAt = now,
                        updatedAt = now
                    )
                })
            }

            // Keep the legacy/search mirror in sync without overwriting it from locked/corrupt text.
            refreshSearchBodyIfSafe(noteId, now, clearWhenEmpty = false)
            newPageId
        }
    }

    /** Reorders the complete page set in one transaction; partial or duplicate orders are rejected. */
    suspend fun reorderPages(noteId: String, orderedIds: List<String>) = lock.withLock {
        db.withTransaction {
            val existing = pageDao.getPages(noteId)
            val ordered = PageOrderPolicy.reorderByIds(existing, orderedIds)
            pageDao.updateAll(ordered)
        }
    }

    suspend fun updatePages(pages: List<NotePageEntity>) = lock.withLock {
        pageDao.updateAll(pages)
    }

    suspend fun deletePage(noteId: String, pageId: String, remaining: List<NotePageEntity>) = lock.withLock {
        db.withTransaction {
            pageDao.deleteById(pageId)
            pageDao.updateAll(remaining)
            refreshSearchBodyIfSafe(noteId, System.currentTimeMillis(), clearWhenEmpty = true)
        }
    }

    suspend fun setPageMode(noteId: String, mode: String) = lock.withLock { noteDao.setPageMode(noteId, mode) }

    suspend fun deleteFolder(folderId: String) = lock.withLock {
        db.withTransaction {
            folderDao.detachNotes(folderId)
            folderDao.deleteById(folderId)
        }
    }

    suspend fun purgeOldTrash(days: Int) = lock.withLock {
        noteDao.purgeTrashedBefore(System.currentTimeMillis() - days * 86_400_000L)
    }

    // ---- backup / restore ---------------------------------------------------------------

    /** Writes every folder, note (incl. archived and trashed), page and element. Does not close [out]. */
    suspend fun exportBackup(out: OutputStream): BackupStats = lock.withLock {
        val folders = folderDao.getAll()
        val notes = noteDao.getAll()
        val pages = pageDao.getAllPages()
        val containsMedia = elementDao.getAllElements().any { it.elementType in MEDIA_ELEMENT_TYPES }
        check(!containsMedia) {
            "This backup format does not yet package attachment bytes; export is blocked to prevent an incomplete backup."
        }
        val w = JsonWriter(OutputStreamWriter(out, Charsets.UTF_8))
        w.beginObject()
        BackupCodec.writeHeader(w, System.currentTimeMillis())
        w.name("folders").beginArray(); folders.forEach { BackupCodec.writeFolder(w, it) }; w.endArray()
        w.name("notes").beginArray(); notes.forEach { BackupCodec.writeNote(w, it) }; w.endArray()
        w.name("pages").beginArray(); pages.forEach { BackupCodec.writePage(w, it) }; w.endArray()
        w.name("elements").beginArray()
        for (p in pages) elementDao.getElements(p.id).forEach { BackupCodec.writeElement(w, it) }
        w.endArray()
        w.endObject()
        w.flush()
        BackupStats(notes.size, 0)
    }

    /**
     * Writes a complete binary archive (metadata + referenced attachment blobs).
     * Snapshot and blob verification happen while repository mutations are excluded by [lock].
     * The caller owns [out]; temporary metadata is always removed.
     */
    suspend fun exportBinaryBackup(out: OutputStream): BackupStats = lock.withLock {
        val folders = folderDao.getAll()
        val notes = noteDao.getAll()
        val pages = pageDao.getAllPages()
        val elements = elementDao.getAllElements()
        val refs = elements.filter { it.elementType in MEDIA_ELEMENT_TYPES }.map { element ->
            AttachmentRefCodec.decodeOrNull(element.payloadJson)
                ?: error("Invalid attachment reference in element ${element.id}")
        }
        val blobs = refs.distinctBy { "${it.sha256}.${it.extension}" }.map { ref ->
            check(attachmentStorage.verify(ref)) { "Missing or damaged attachment: ${ref.displayName}" }
            BackupArchiveCodec.Blob(ref.sha256, ref.extension, ref.byteCount)
        }
        val metadata = File.createTempFile("elios-backup-", ".json")
        try {
            FileOutputStream(metadata).use { fileOut ->
                val w = JsonWriter(OutputStreamWriter(fileOut, Charsets.UTF_8))
                w.beginObject()
                BackupCodec.writeHeader(w, System.currentTimeMillis())
                w.name("folders").beginArray(); folders.forEach { BackupCodec.writeFolder(w, it) }; w.endArray()
                w.name("notes").beginArray(); notes.forEach { BackupCodec.writeNote(w, it) }; w.endArray()
                w.name("pages").beginArray(); pages.forEach { BackupCodec.writePage(w, it) }; w.endArray()
                w.name("elements").beginArray(); elements.forEach { BackupCodec.writeElement(w, it) }; w.endArray()
                w.endObject(); w.flush()
            }
            FileInputStream(metadata).use { metadataIn ->
                BackupArchiveCodec.write(out, metadataIn, blobs) { blob ->
                    val ref = refs.first { it.sha256 == blob.sha256 && it.extension == blob.extension }
                    attachmentStorage.open(ref)
                }
            }
        } finally {
            metadata.delete()
        }
        BackupStats(notes.size, 0)
    }

    /**
     * Restores a verified binary archive as a non-destructive merge. Original note IDs are retained
     * when available so repeating the same restore skips those notes; colliding folder IDs are
     * remapped and page/element IDs are regenerated. Binary files are
     * installed before the Room transaction; newly-created, now-unreferenced files are removed if
     * the transaction fails. Existing blobs are never removed by rollback.
     */
    suspend fun restoreBinaryBackup(input: InputStream): BackupStats = lock.withLock {
        val staging = File.createTempFile("elios-restore-", ".dir").apply {
            check(delete() && mkdirs()) { "Cannot create restore staging directory" }
        }
        val newlyInstalled = LinkedHashMap<String, StoredAttachment>()
        try {
            val extracted = BackupArchiveCodec.extract(input, staging)
            val validated = validateBackupMetadata(extracted.metadataFile)
            val archiveBlobKeys = extracted.blobs.map { "${it.sha256}.${it.extension}" }.toSet()
            require(validated.mediaRefs.keys == archiveBlobKeys) {
                "Backup media references do not match packaged attachment files"
            }
            extracted.blobs.forEach { blob ->
                val key = "${blob.sha256}.${blob.extension}"
                val ref = validated.mediaRefs.getValue(key)
                require(ref.byteCount == blob.byteCount) { "Attachment metadata size mismatch" }
                val existingPath = attachmentStorage.resolve(ref)
                val existedBefore = existingPath.exists()
                val file = extracted.attachmentFiles.getValue("attachments/$key")
                val imported = FileInputStream(file).use {
                    attachmentStorage.import(it, ref.displayName, ref.mimeType, ref.extension)
                }
                if (!existedBefore) newlyInstalled[key] = imported
                require(imported.sha256 == ref.sha256 && imported.extension == ref.extension &&
                    imported.byteCount == ref.byteCount && attachmentStorage.verify(imported)) {
                    "Imported attachment verification failed"
                }
            }

            val existingNoteIds = noteDao.getAll().mapTo(HashSet()) { it.id }
            val existingFolderIds = folderDao.getAll().mapTo(HashSet()) { it.id }
            val noteIdMap = LinkedHashMap<String, String>()
            var skipped = 0
            validated.noteIds.forEach { oldId ->
                if (oldId in existingNoteIds) skipped++ else noteIdMap[oldId] = oldId
            }
            // Keep original folder IDs where possible. Only folders referenced by notes that will
            // actually be imported are installed, so repeating the same archive is idempotent.
            val neededFolderIds = validated.noteFolders
                .filterKeys { it in noteIdMap.keys }.values.filterNotNull().toSet()
            val folderIdMap = neededFolderIds.associateWith { oldId ->
                if (oldId in existingFolderIds) UUID.randomUUID().toString() else oldId
            }
            val pageIdMap = validated.pageIds.associateWith { UUID.randomUUID().toString() }
            val elementIdMap = validated.elementIds.associateWith { UUID.randomUUID().toString() }

            val inserted = db.withTransaction {
                var added = 0
                val insertedPageIds = HashSet<String>()
                FileInputStream(extracted.metadataFile).use { metadata ->
                    BackupCodec.read(metadata, object : BackupSink {
                        override suspend fun folder(r: BackupRow) {
                            val newFolderId = folderIdMap[r.str("id")] ?: return
                            folderDao.insert(
                                FolderEntity(
                                    id = newFolderId, name = r.str("name"),
                                    createdAt = r.long("createdAt"), updatedAt = r.long("updatedAt")
                                )
                            )
                        }

                        override suspend fun note(r: BackupRow) {
                            val oldId = r.str("id")
                            val newId = noteIdMap[oldId] ?: return
                            val oldFolder = r.strOrNull("folderId")
                            noteDao.insert(
                                NoteEntity(
                                    id = newId, title = r.str("title"), body = r.str("body"),
                                    createdAt = r.long("createdAt"), updatedAt = r.long("updatedAt"),
                                    isPinned = r.bool("isPinned"), isArchived = r.bool("isArchived"),
                                    isFavorite = r.bool("isFavorite"), pageMode = r.str("pageMode"),
                                    folderId = oldFolder?.let { folderIdMap.getValue(it) },
                                    deletedAt = r.longOrNull("deletedAt")
                                )
                            )
                            added++
                        }

                        override suspend fun page(r: BackupRow) {
                            val oldNoteId = r.str("noteId")
                            val newNoteId = noteIdMap[oldNoteId] ?: return
                            val oldPageId = r.str("id")
                            pageDao.insert(
                                NotePageEntity(
                                    id = pageIdMap.getValue(oldPageId), noteId = newNoteId,
                                    pageIndex = r.int("pageIndex"), widthDp = r.float("widthDp"),
                                    heightDp = r.float("heightDp"), orientation = r.str("orientation"),
                                    template = r.str("template"), backgroundColorArgb = r.long("backgroundColorArgb"),
                                    createdAt = r.long("createdAt"), updatedAt = r.long("updatedAt")
                                )
                            )
                            insertedPageIds.add(oldPageId)
                        }

                        override suspend fun element(r: BackupRow) {
                            val oldPageId = r.str("pageId")
                            if (oldPageId !in insertedPageIds) return
                            val newPageId = pageIdMap.getValue(oldPageId)
                            val type = r.str("elementType")
                            var payload = r.str("payloadJson")
                            if (type in MEDIA_ELEMENT_TYPES) {
                                val oldRef = AttachmentRefCodec.decodeOrNull(payload)
                                    ?: error("Invalid attachment reference during restore")
                                val key = "${oldRef.sha256}.${oldRef.extension}"
                                val installed = attachmentStorageRefFor(oldRef, newlyInstalled[key], key)
                                payload = AttachmentRefCodec.encode(installed)
                            }
                            elementDao.insertForRestore(
                                NoteElementEntity(
                                    id = elementIdMap.getValue(r.str("id")), pageId = newPageId,
                                    elementType = type, payloadVersion = r.int("payloadVersion"),
                                    payloadJson = payload, x = r.float("x"), y = r.float("y"),
                                    width = r.float("width"), height = r.float("height"),
                                    rotationDegrees = r.float("rotationDegrees"), zIndex = r.int("zIndex"),
                                    createdAt = r.long("createdAt"), updatedAt = r.long("updatedAt")
                                )
                            )
                        }
                    })
                }
                added
            }

            // A successful merge may skip notes already present. Remove only newly installed blobs
            // that ended up unused because every note referencing them was skipped.
            newlyInstalled.forEach { (_, ref) ->
                runCatching {
                    if (elementDao.countPayloadReferences(ref.sha256) == 0) attachmentStorage.delete(ref)
                }
            }
            BackupStats(inserted, skipped)
        } catch (failure: Throwable) {
            newlyInstalled.forEach { (_, ref) ->
                runCatching {
                    if (elementDao.countPayloadReferences(ref.sha256) == 0) attachmentStorage.delete(ref)
                }
            }
            throw failure
        } finally {
            staging.deleteRecursively()
        }
    }

    private fun attachmentStorageRefFor(
        original: StoredAttachment,
        imported: StoredAttachment?,
        key: String
    ): StoredAttachment {
        // The blob may already have existed before this restore, so its identity is still the
        // content address from the validated archive; retain per-element display name and MIME.
        return StoredAttachment(
            sha256 = original.sha256, extension = original.extension, byteCount = original.byteCount,
            mimeType = original.mimeType, displayName = original.displayName
        ).also {
            require(key == "${it.sha256}.${it.extension}")
            if (imported != null) require(imported.sha256 == it.sha256 && imported.byteCount == it.byteCount)
        }
    }

    private data class ValidatedBackup(
        val folderIds: Set<String>, val noteIds: Set<String>, val pageIds: Set<String>,
        val elementIds: Set<String>, val noteFolders: Map<String, String?>,
        val mediaRefs: Map<String, StoredAttachment>
    )

    /** First pass: validate all relationships and identifiers before touching app storage or Room. */
    private suspend fun validateBackupMetadata(file: File): ValidatedBackup {
        val folders = LinkedHashSet<String>()
        val notes = LinkedHashSet<String>()
        val pages = LinkedHashSet<String>()
        val elements = LinkedHashSet<String>()
        val noteFolders = LinkedHashMap<String, String?>()
        val pageNotes = LinkedHashMap<String, String>()
        val elementPages = LinkedHashMap<String, String>()
        val media = LinkedHashMap<String, StoredAttachment>()
        FileInputStream(file).use { metadata ->
            BackupCodec.read(metadata, object : BackupSink {
                override suspend fun folder(r: BackupRow) {
                    require(folders.add(r.str("id"))) { "Duplicate folder ID" }
                    require(r.str("name").length <= 200) { "Invalid folder name" }
                    r.long("createdAt"); r.long("updatedAt")
                }
                override suspend fun note(r: BackupRow) {
                    val id = r.str("id")
                    require(notes.add(id)) { "Duplicate note ID" }
                    require(r.str("title").length <= 120) { "Invalid note title" }
                    r.str("body"); r.long("createdAt"); r.long("updatedAt")
                    r.bool("isPinned"); r.bool("isArchived"); r.bool("isFavorite")
                    require(r.str("pageMode") in setOf("PAGED", "INFINITE")) { "Invalid page mode" }
                    noteFolders[id] = r.strOrNull("folderId")
                    r.longOrNull("deletedAt")
                }
                override suspend fun page(r: BackupRow) {
                    val id = r.str("id")
                    require(pages.add(id)) { "Duplicate page ID" }
                    pageNotes[id] = r.str("noteId")
                    require(r.int("pageIndex") >= 0) { "Invalid page index" }
                    val width = r.float("widthDp"); val height = r.float("heightDp")
                    require(width.isFinite() && height.isFinite() && width > 0f && height > 0f) { "Invalid page dimensions" }
                    require(r.str("orientation") in setOf("PORTRAIT", "LANDSCAPE")) { "Invalid page orientation" }
                    require(r.str("template") in setOf("BLANK", "RULED", "GRID", "DOTS")) { "Invalid page template" }
                    r.long("backgroundColorArgb"); r.long("createdAt"); r.long("updatedAt")
                }
                override suspend fun element(r: BackupRow) {
                    val id = r.str("id")
                    require(elements.add(id)) { "Duplicate element ID" }
                    elementPages[id] = r.str("pageId")
                    val type = r.str("elementType")
                    require(type in setOf("TEXT", "INK", "IMAGE", "VIDEO", "AUDIO", "PDF_CONTENT", "ATTACHMENT")) { "Unknown element type" }
                    require(r.int("payloadVersion") > 0) { "Invalid element payload version" }
                    val payload = r.str("payloadJson")
                    val values = listOf(r.float("x"), r.float("y"), r.float("width"), r.float("height"), r.float("rotationDegrees"))
                    require(values.all { it.isFinite() } && values[2] >= 0f && values[3] >= 0f) { "Invalid element geometry" }
                    r.int("zIndex"); r.long("createdAt"); r.long("updatedAt")
                    if (type in MEDIA_ELEMENT_TYPES) {
                        val ref = AttachmentRefCodec.decodeOrNull(payload) ?: error("Invalid media reference")
                        val key = "${ref.sha256}.${ref.extension}"
                        val old = media[key]
                        require(old == null || old.byteCount == ref.byteCount) { "Conflicting attachment metadata" }
                        if (old == null) media[key] = ref
                    }
                }
            })
        }
        require(noteFolders.values.filterNotNull().all { it in folders }) { "A note references a missing folder" }
        require(pageNotes.values.all { it in notes }) { "A page references a missing note" }
        require(elementPages.values.all { it in pages }) { "An element references a missing page" }
        return ValidatedBackup(folders, notes, pages, elements, noteFolders, media)
    }

    /** Fully verifies archive integrity, metadata relationships and all attachment references without mutation. */
    suspend fun verifyBinaryBackup(input: InputStream): Int {
        val staging = File.createTempFile("elios-verify-", ".dir").apply {
            check(delete() && mkdirs()) { "Cannot create backup verification staging directory" }
        }
        try {
            val extracted = BackupArchiveCodec.extract(input, staging)
            val validated = validateBackupMetadata(extracted.metadataFile)
            val actual = extracted.blobs.associateBy { "${it.sha256}.${it.extension}" }
            require(validated.mediaRefs.keys == actual.keys) {
                "Backup attachment references do not match packaged files"
            }
            validated.mediaRefs.forEach { (key, ref) ->
                val blob = actual.getValue(key)
                require(ref.byteCount == blob.byteCount) { "Attachment metadata size mismatch" }
                val file = extracted.attachmentFiles.getValue("attachments/$key")
                require(file.length() == ref.byteCount) { "Attachment metadata size mismatch" }
            }
            return validated.noteIds.size
        } finally {
            staging.deleteRecursively()
        }
    }

    /** Parses a written backup without touching the database; returns the number of notes it holds. */
    suspend fun verifyBackup(input: InputStream): Int {
        var notes = 0
        BackupCodec.read(input, object : BackupSink {
            override suspend fun folder(r: BackupRow) { r.str("id") }
            override suspend fun note(r: BackupRow) { r.str("id"); notes++ }
            override suspend fun page(r: BackupRow) { r.str("id") }
            override suspend fun element(r: BackupRow) {
                r.str("id")
                require(r.str("elementType") !in MEDIA_ELEMENT_TYPES) {
                    "This backup contains attachment references without packaged binary data."
                }
            }
        })
        return notes
    }

    /**
     * Merges a backup into the database inside ONE transaction: anything that fails (bad file,
     * wrong version, ...) rolls everything back. Existing notes and folders are never overwritten;
     * notes whose id already exists are skipped together with their pages and elements.
     */
    suspend fun restoreBackup(input: InputStream): BackupStats = lock.withLock {
        db.withTransaction {
            val folderIds = folderDao.getAll().mapTo(HashSet()) { it.id }
            val existingNotes = noteDao.getAll().mapTo(HashSet()) { it.id }
            val folderIdMap = HashMap<String, String>()
            val insertedNotes = HashSet<String>()
            val insertedPages = HashMap<String, String>()
            var skipped = 0

            BackupCodec.read(input, object : BackupSink {
                override suspend fun folder(r: BackupRow) {
                    val oldId = r.str("id")
                    if (oldId !in folderIds) {
                        folderDao.insert(FolderEntity(oldId, r.str("name"), r.long("createdAt"), r.long("updatedAt")))
                        folderIds.add(oldId)
                    }
                    folderIdMap[oldId] = oldId
                }

                override suspend fun note(r: BackupRow) {
                    val id = r.str("id")
                    if (id in existingNotes) { skipped++; return }
                    noteDao.insert(
                        NoteEntity(
                            id = id, title = r.str("title"), body = r.str("body"),
                            createdAt = r.long("createdAt"), updatedAt = r.long("updatedAt"),
                            isPinned = r.bool("isPinned"), isArchived = r.bool("isArchived"),
                            isFavorite = r.bool("isFavorite"), pageMode = r.str("pageMode"),
                            folderId = r.strOrNull("folderId")?.let { folderIdMap[it] },
                            deletedAt = r.longOrNull("deletedAt")
                        )
                    )
                    insertedNotes.add(id)
                }

                override suspend fun page(r: BackupRow) {
                    if (r.str("noteId") !in insertedNotes) return
                    val oldPageId = r.str("id")
                    val newPageId = UUID.randomUUID().toString()
                    pageDao.insert(
                        NotePageEntity(
                            id = newPageId, noteId = r.str("noteId"), pageIndex = r.int("pageIndex"),
                            widthDp = r.float("widthDp"), heightDp = r.float("heightDp"),
                            orientation = r.str("orientation"), template = r.str("template"),
                            backgroundColorArgb = r.long("backgroundColorArgb"),
                            createdAt = r.long("createdAt"), updatedAt = r.long("updatedAt")
                        )
                    )
                    insertedPages[oldPageId] = newPageId
                }

                override suspend fun element(r: BackupRow) {
                    require(r.str("elementType") !in MEDIA_ELEMENT_TYPES) {
                        "Cannot restore attachment references without their binary data."
                    }
                    val newPageId = insertedPages[r.str("pageId")] ?: return
                    elementDao.insertForRestore(
                        NoteElementEntity(
                            id = UUID.randomUUID().toString(), pageId = newPageId, elementType = r.str("elementType"),
                            payloadVersion = r.int("payloadVersion"), payloadJson = r.str("payloadJson"),
                            x = r.float("x"), y = r.float("y"), width = r.float("width"), height = r.float("height"),
                            rotationDegrees = r.float("rotationDegrees"), zIndex = r.int("zIndex"),
                            createdAt = r.long("createdAt"), updatedAt = r.long("updatedAt")
                        )
                    )
                }
            })
            BackupStats(insertedNotes.size, skipped)
        }
    }
}
