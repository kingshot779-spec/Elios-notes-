package com.eliosnotes.app.ink

import java.util.UUID
import kotlin.math.abs

/** In-memory clipboard for immutable ink strokes. Pasted strokes receive fresh identities. */
class StrokeClipboard(
    private val newId: () -> String = { UUID.randomUUID().toString() }
) {
    private var contents: List<Stroke> = emptyList()

    val isEmpty: Boolean get() = contents.isEmpty()

    /**
     * Capture a defensive snapshot. Stroke.points is exposed as a List but callers may have
     * supplied a mutable backing list; retaining it would let later edits mutate the clipboard.
     */
    fun copy(strokes: List<Stroke>, selectedIds: Set<String>) {
        contents = if (selectedIds.isEmpty()) emptyList()
        else strokes.asSequence()
            .filter { it.id in selectedIds }
            .map { stroke ->
                Stroke(
                    stroke.id, stroke.tool, stroke.colorArgb, stroke.width,
                    stroke.points.map { it.copy() }
                )
            }
            .toList()
    }

    /**
     * Paste independent copies. IDs must be unique and different from the copied source IDs;
     * coordinates are checked against the same safe range used by the versioned ink codec.
     */
    fun paste(offsetX: Float = 24f, offsetY: Float = 24f): List<Stroke> {
        require(offsetX.isFinite() && offsetY.isFinite()) { "Paste offset must be finite" }
        val sourceIds = contents.mapTo(HashSet()) { it.id }
        val generatedIds = HashSet<String>()
        return contents.map { stroke ->
            val id = newId()
            require(id.isNotBlank() && id !in sourceIds && generatedIds.add(id)) {
                "Clipboard ID generator must return fresh, unique IDs"
            }
            val points = stroke.points.map { point ->
                val x = point.x + offsetX
                val y = point.y + offsetY
                require(x.isFinite() && y.isFinite() && abs(x) <= MAX_ABS_COORDINATE && abs(y) <= MAX_ABS_COORDINATE) {
                    "Pasted stroke is outside the supported page coordinate range"
                }
                point.copy(x = x, y = y)
            }
            stroke.derive(id, points)
        }
    }

    private companion object {
        const val MAX_ABS_COORDINATE = 1_000_000f
    }
}
