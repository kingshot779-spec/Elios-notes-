package com.eliosnotes.app.ink

import kotlin.math.hypot

/** User-selectable strength for conservative, shape-preserving ink smoothing. */
enum class InkBeautificationLevel(val passes: Int, val blend: Float) {
    LIGHT(1, 0.14f),
    MEDIUM(2, 0.22f),
    STRONG(3, 0.28f)
}

/**
 * Deterministic, geometry-only handwriting smoothing. It never performs OCR, changes text,
 * reorders strokes, changes stroke IDs/styles, or mutates the input. Endpoints are preserved.
 * This is deliberately conservative: it reduces point jitter but does not normalize letter
 * shapes, spacing, slant, or baselines. The caller must retain the original for undo/restore.
 */
object InkBeautifier {
    fun beautify(
        strokes: List<Stroke>,
        level: InkBeautificationLevel
    ): List<Stroke> {
        if (strokes.isEmpty()) return strokes
        var changed = false
        val result = strokes.map { stroke ->
            val original = stroke.points
            if (original.size < 4 || original.any {
                    !it.x.isFinite() || !it.y.isFinite() || !it.pressure.isFinite()
                }) return@map stroke
            var current = original
            repeat(level.passes) {
                current = smoothPass(current, level.blend)
            }
            if (current == original) stroke else {
                changed = true
                Stroke(stroke.id, stroke.tool, stroke.colorArgb, stroke.width, current)
            }
        }
        return if (changed) result else strokes
    }

    private fun smoothPass(points: List<InkPoint>, blend: Float): List<InkPoint> {
        if (points.size < 4) return points
        val out = ArrayList<InkPoint>(points.size)
        out.add(points.first())
        for (i in 1 until points.lastIndex) {
            val previous = points[i - 1]
            val current = points[i]
            val next = points[i + 1]
            val targetX = (previous.x + next.x) * 0.5f
            val targetY = (previous.y + next.y) * 0.5f
            val dx = (targetX - current.x) * blend
            val dy = (targetY - current.y) * blend
            // Limit each correction to 12% of the shorter adjacent segment to protect corners.
            val local = minOf(
                hypot(current.x - previous.x, current.y - previous.y),
                hypot(next.x - current.x, next.y - current.y)
            )
            val correction = hypot(dx, dy)
            val limit = local * 0.12f
            val scale = if (correction > limit && correction > 0f) limit / correction else 1f
            val pressure = current.pressure + (((previous.pressure + next.pressure) * 0.5f) - current.pressure) * (blend * 0.35f)
            out.add(
                InkPoint(
                    current.x + dx * scale,
                    current.y + dy * scale,
                    pressure.coerceIn(0f, 1f)
                )
            )
        }
        out.add(points.last())
        return out
    }
}
