package com.eliosnotes.app.data.document

/** Pure, validated updates for one page's paper presentation. */
object PagePresentationPolicy {
    fun withTemplate(page: NotePageEntity, template: String, now: Long): NotePageEntity? {
        if (template !in PageTemplate.supported) return null
        return page.copy(template = template, updatedAt = now)
    }

    fun withBackground(page: NotePageEntity, argb: Long, now: Long): NotePageEntity =
        page.copy(backgroundColorArgb = argb, updatedAt = now)

    fun withOrientation(
        page: NotePageEntity,
        orientation: String,
        isEmpty: Boolean,
        now: Long
    ): NotePageEntity? {
        if (!isEmpty) return null
        val dimensions = when (orientation) {
            PageOrientation.PORTRAIT -> PageSize.A4_WIDTH to PageSize.A4_HEIGHT
            PageOrientation.LANDSCAPE -> PageSize.A4_HEIGHT to PageSize.A4_WIDTH
            else -> return null
        }
        return page.copy(
            orientation = orientation,
            widthDp = dimensions.first,
            heightDp = dimensions.second,
            updatedAt = now
        )
    }
}
