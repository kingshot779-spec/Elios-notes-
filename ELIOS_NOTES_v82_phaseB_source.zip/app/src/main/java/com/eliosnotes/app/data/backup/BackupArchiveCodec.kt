package com.eliosnotes.app.data.backup

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Binary, streaming ZIP container for a JSON document snapshot and content-addressed blobs. */
object BackupArchiveCodec {
    const val FORMAT = "ELIOS_NOTES_ARCHIVE"
    const val VERSION = 2
    const val METADATA_ENTRY = "database.json"
    const val MANIFEST_ENTRY = "manifest.txt"
    private const val MAX_METADATA_BYTES = 256L * 1024 * 1024
    private const val MAX_ATTACHMENT_BYTES = 100L * 1024 * 1024
    private const val MAX_TOTAL_BYTES = 1024L * 1024 * 1024
    private const val MAX_ENTRIES = 20_000

    data class Blob(val sha256: String, val extension: String, val byteCount: Long) {
        init {
            require(sha256.matches(Regex("[a-f0-9]{64}")))
            require(extension.matches(Regex("[a-z0-9]{1,10}")))
            require(byteCount in 0..MAX_ATTACHMENT_BYTES)
        }
        val entryName: String get() = "attachments/$sha256.$extension"
    }

    data class Extracted(val metadataFile: File, val attachmentFiles: Map<String, File>, val blobs: List<Blob>)
    private data class Manifest(val metadataSha256: String, val metadataBytes: Long, val blobs: List<Blob>)

    /** Writes metadata and blobs without buffering whole files. The caller retains stream ownership. */
    fun write(
        output: OutputStream,
        metadata: InputStream,
        blobs: List<Blob>,
        openBlob: (Blob) -> InputStream
    ) {
        require(blobs.size + 2 <= MAX_ENTRIES)
        require(blobs.map { it.entryName }.distinct().size == blobs.size) { "Duplicate attachment entry" }
        val zip = ZipOutputStream(BufferedOutputStream(output))
        var total = 0L
        zip.putNextEntry(ZipEntry(METADATA_ENTRY))
        val metadataResult = copyAndHash(metadata, zip, MAX_METADATA_BYTES)
        total += metadataResult.first
        require(total <= MAX_TOTAL_BYTES) { "Backup exceeds total size limit" }
        zip.closeEntry()

        for (blob in blobs) {
            zip.putNextEntry(ZipEntry(blob.entryName))
            val result = openBlob(blob).use { copyAndHash(it, zip, blob.byteCount) }
            require(result.first == blob.byteCount) { "Attachment length mismatch: ${blob.sha256}" }
            require(result.second == blob.sha256) { "Attachment checksum mismatch before export: ${blob.sha256}" }
            zip.closeEntry()
            total += result.first
            require(total <= MAX_TOTAL_BYTES) { "Backup exceeds total size limit" }
        }
        val manifest = buildString {
            append(FORMAT).append('\n')
            append(VERSION).append('\n')
            append(metadataResult.second).append('\t').append(metadataResult.first).append('\n')
            append(blobs.size).append('\n')
            blobs.sortedBy { it.sha256 }.forEach {
                append(it.sha256).append('\t').append(it.extension).append('\t').append(it.byteCount).append('\n')
            }
        }.toByteArray(Charsets.UTF_8)
        zip.putNextEntry(ZipEntry(MANIFEST_ENTRY))
        zip.write(manifest)
        zip.closeEntry()
        zip.finish()
        zip.flush()
    }

    /** Extracts into a new/empty staging directory and verifies every blob before returning. */
    fun extract(input: InputStream, stagingDirectory: File): Extracted {
        require(!stagingDirectory.exists() || stagingDirectory.listFiles().isNullOrEmpty()) {
            "Staging directory must be new or empty"
        }
        require(stagingDirectory.exists() || stagingDirectory.mkdirs()) { "Cannot create staging directory" }
        val zip = ZipInputStream(BufferedInputStream(input))
        val extracted = LinkedHashMap<String, File>()
        var metadataFile: File? = null
        var metadataHash: String? = null
        var metadataLength: Long? = null
        var manifestBytes: ByteArray? = null
        var total = 0L
        var count = 0
        try {
            while (true) {
                val entry = zip.nextEntry ?: break
                count++
                require(count <= MAX_ENTRIES) { "Too many archive entries" }
                require(!entry.isDirectory) { "Directory entries are not allowed" }
                val name = entry.name
                require(name == METADATA_ENTRY || name == MANIFEST_ENTRY ||
                    name.matches(Regex("attachments/[a-f0-9]{64}\\.[a-z0-9]{1,10}"))) {
                    "Unexpected archive entry"
                }
                require(name !in extracted && !(name == METADATA_ENTRY && metadataFile != null) &&
                    !(name == MANIFEST_ENTRY && manifestBytes != null)) { "Duplicate archive entry" }
                when (name) {
                    MANIFEST_ENTRY -> {
                        val bytes = zip.readBytesBounded(2L * 1024 * 1024)
                        manifestBytes = bytes
                    }
                    else -> {
                        val limit = if (name == METADATA_ENTRY) MAX_METADATA_BYTES else MAX_ATTACHMENT_BYTES
                        val target = File(stagingDirectory, if (name == METADATA_ENTRY) "database.json" else name.substringAfter('/'))
                        val copied = FileOutputStream(target).use { copyAndHash(zip, it, limit) }
                        total += copied.first
                        require(total <= MAX_TOTAL_BYTES) { "Archive exceeds total size limit" }
                        if (name == METADATA_ENTRY) {
                            metadataFile = target
                            metadataHash = copied.second
                            metadataLength = copied.first
                        } else extracted[name] = target
                    }
                }
                zip.closeEntry()
            }
            val manifest = parseManifest(manifestBytes ?: error("Missing manifest"))
            val metadata = metadataFile ?: error("Missing database snapshot")
            require(metadataHash == manifest.metadataSha256 && metadataLength == manifest.metadataBytes) {
                "Metadata checksum or size mismatch"
            }
            require(extracted.size == manifest.blobs.size) { "Archive attachment count mismatch" }
            val byName = manifest.blobs.associateBy { it.entryName }
            require(byName.size == manifest.blobs.size && extracted.keys == byName.keys) { "Archive contents do not match manifest" }
            for ((name, file) in extracted) {
                val blob = byName.getValue(name)
                require(file.length() == blob.byteCount) { "Attachment size mismatch" }
                require(sha256(file) == blob.sha256) { "Attachment checksum mismatch" }
            }
            return Extracted(metadata, extracted, manifest.blobs)
        } catch (failure: Throwable) {
            stagingDirectory.deleteRecursively()
            throw failure
        }
    }

    private fun parseManifest(bytes: ByteArray): Manifest {
        val lines = bytes.toString(Charsets.UTF_8).split('\n').filter { it.isNotEmpty() }
        require(lines.size >= 4 && lines[0] == FORMAT) { "Not an ELIOS archive" }
        require(lines[1].toIntOrNull() == VERSION) { "Unsupported archive version" }
        val metadata = lines[2].split('\t')
        require(metadata.size == 2 && metadata[0].matches(Regex("[a-f0-9]{64}"))) { "Invalid metadata checksum" }
        val metadataBytes = metadata[1].toLongOrNull() ?: error("Invalid metadata size")
        require(metadataBytes in 0..MAX_METADATA_BYTES) { "Invalid metadata size" }
        val count = lines[3].toIntOrNull() ?: error("Invalid manifest count")
        require(count in 0 until MAX_ENTRIES && lines.size == count + 4) { "Invalid manifest entries" }
        val blobs = lines.drop(4).map { line ->
            val parts = line.split('\t')
            require(parts.size == 3)
            Blob(parts[0], parts[1], parts[2].toLong())
        }
        require(blobs.map { it.entryName }.distinct().size == blobs.size)
        return Manifest(metadata[0], metadataBytes, blobs)
    }

    private fun copyBounded(input: InputStream, output: OutputStream, limit: Long): Long {
        val buffer = ByteArray(32 * 1024)
        var count = 0L
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            if (read == 0) continue
            count += read
            require(count <= limit) { "Entry exceeds size limit" }
            output.write(buffer, 0, read)
        }
        return count
    }

    /** Hashes the exact bytes while streaming them to ZIP; prevents exporting a corrupt source blob. */
    private fun copyAndHash(input: InputStream, output: OutputStream, limit: Long): Pair<Long, String> {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(32 * 1024)
        var count = 0L
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            if (read == 0) continue
            count += read
            require(count <= limit) { "Attachment exceeds declared size" }
            digest.update(buffer, 0, read)
            output.write(buffer, 0, read)
        }
        val hash = digest.digest().joinToString("") { "%02x".format(it) }
        return count to hash
    }

    private fun ZipInputStream.readBytesBounded(limit: Long): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        copyBounded(this, out, limit)
        return out.toByteArray()
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(32 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                if (read > 0) digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
