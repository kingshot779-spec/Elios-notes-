package com.eliosnotes.app.data.media

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.security.MessageDigest

/** Stable reference to a binary attachment stored inside the app's private files directory. */
data class StoredAttachment(
    val sha256: String,
    val extension: String,
    val byteCount: Long,
    val mimeType: String,
    val displayName: String
) {
    init {
        require(sha256.matches(Regex("[a-f0-9]{64}")))
        require(extension.matches(Regex("[a-z0-9]{1,10}")))
        require(byteCount >= 0)
    }
}

/**
 * Outcome of a conservative attachment-directory reconciliation.
 * Counts include only files actually removed or deliberately left untouched.
 */
data class AttachmentReconciliationResult(
    val cleanedFiles: Int,
    val skippedFiles: Int,
    val errors: List<String>,
    val unsafeReferences: Boolean = false
)

/**
 * Content-addressed, app-private binary storage. Imports are streamed to a temporary file,
 * bounded in size, hashed while copying, and only published after the complete write succeeds.
 * The caller owns and must close the supplied InputStream.
 */
class AttachmentStorage(private val root: File, private val maxBytes: Long = DEFAULT_MAX_BYTES) {
    init { require(maxBytes > 0) }

    @Synchronized
    fun import(
        input: InputStream,
        displayName: String,
        mimeType: String,
        extensionHint: String? = null
    ): StoredAttachment {
        val safeName = sanitizeDisplayName(displayName)
        val extension = sanitizeExtension(extensionHint ?: extensionFromName(displayName) ?: extensionForMime(mimeType))
        val base = File(root, "attachments")
        check(base.exists() || base.mkdirs()) { "Unable to create attachment directory" }
        val tempDir = File(base, ".tmp")
        check(tempDir.exists() || tempDir.mkdirs()) { "Unable to create temporary directory" }
        val temp = File.createTempFile("import-", ".part", tempDir)
        var count = 0L
        val digest = MessageDigest.getInstance("SHA-256")
        try {
            FileOutputStream(temp).use { output ->
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    if (read == 0) continue
                    count += read
                    require(count <= maxBytes) { "Attachment exceeds the $maxBytes byte limit" }
                    digest.update(buffer, 0, read)
                    output.write(buffer, 0, read)
                }
                output.fd.sync()
            }
            val hash = digest.digest().joinToString("") { "%02x".format(it) }
            val shard = File(base, hash.substring(0, 2))
            check(shard.exists() || shard.mkdirs()) { "Unable to create attachment shard" }
            val destination = File(shard, "$hash.$extension")
            if (destination.exists()) {
                // A matching length is not proof that a content-addressed blob is healthy.
                // Repair same-length corruption instead of returning a reference to bad bytes.
                val existingIsValid = destination.isFile && destination.length() == count &&
                    sha256(destination) == hash
                if (existingIsValid) {
                    check(temp.delete() || !temp.exists()) { "Unable to remove duplicate temporary attachment" }
                } else {
                    val quarantine = File.createTempFile("damaged-", ".bak", tempDir)
                    check(quarantine.delete()) { "Unable to prepare damaged-blob quarantine" }
                    check(destination.renameTo(quarantine)) { "Unable to quarantine damaged attachment" }
                    if (!temp.renameTo(destination)) {
                        // Restore the previous file if publishing the verified replacement fails.
                        quarantine.renameTo(destination)
                        error("Unable to replace damaged attachment")
                    }
                    quarantine.delete()
                }
            } else {
                check(temp.renameTo(destination)) { "Unable to finalize attachment" }
            }
            return StoredAttachment(hash, extension, count, mimeType.ifBlank { "application/octet-stream" }, safeName)
        } catch (failure: Throwable) {
            temp.delete()
            throw failure
        }
    }

    fun resolve(attachment: StoredAttachment): File {
        val base = File(File(root, "attachments"), attachment.sha256.substring(0, 2)).canonicalFile
        val file = File(base, "${attachment.sha256}.${attachment.extension}").canonicalFile
        require(file.parentFile == base) { "Invalid attachment reference" }
        return file
    }

    fun open(attachment: StoredAttachment): InputStream {
        val file = resolve(attachment)
        check(file.isFile && file.length() == attachment.byteCount) { "Attachment is missing or incomplete" }
        return FileInputStream(file)
    }


    /**
     * Removes only old, well-formed content-addressed files which are not referenced by Room.
     * A null reference set means at least one media row could not be decoded; in that case no
     * attachment blob is eligible for deletion. Application-owned import/quarantine temp files
     * are handled separately and only after the same grace period.
     *
     * The caller must serialize this operation with repository mutations and run it on IO.
     */
    @Synchronized
    fun reconcile(
        referencedKeys: Set<String>?,
        nowMillis: Long = System.currentTimeMillis(),
        gracePeriodMillis: Long = DEFAULT_RECONCILIATION_GRACE_MS
    ): AttachmentReconciliationResult {
        require(gracePeriodMillis >= 0)
        val base = File(root, "attachments")
        if (!base.exists()) return AttachmentReconciliationResult(0, 0, emptyList(), referencedKeys == null)
        val canonicalRoot = runCatching { root.canonicalFile }.getOrElse {
            return AttachmentReconciliationResult(0, 0, listOf("Cannot resolve app files directory: ${it.message}"), referencedKeys == null)
        }
        val canonicalBase = runCatching { base.canonicalFile }.getOrElse {
            return AttachmentReconciliationResult(0, 0, listOf("Cannot resolve attachment directory: ${it.message}"), referencedKeys == null)
        }
        if (canonicalBase.parentFile != canonicalRoot || canonicalBase.name != "attachments") {
            return AttachmentReconciliationResult(
                0, 1, listOf("Attachment directory is not a direct child of the app files directory"),
                referencedKeys == null
            )
        }
        val errors = mutableListOf<String>()
        var cleaned = 0
        var skipped = 0

        fun oldEnough(file: File): Boolean =
            runCatching {
                val modified = file.lastModified()
                modified > 0L && nowMillis >= modified && nowMillis - modified >= gracePeriodMillis
            }.getOrDefault(false)

        val tempDir = File(canonicalBase, ".tmp")
        val canonicalTempDir = runCatching { tempDir.canonicalFile }.getOrNull()
        val tempDirIsSafe = canonicalTempDir != null &&
            canonicalTempDir.parentFile == canonicalBase && canonicalTempDir.name == ".tmp"

        fun deleteOwnedTemp(file: File) {
            val ownedName = file.name.matches(Regex("(import-[A-Za-z0-9_-]+\\.part|damaged-[A-Za-z0-9_-]+\\.bak)"))
            val canonical = runCatching { file.canonicalFile }.getOrNull()
            if (!file.isFile) return
            if (!ownedName || !tempDirIsSafe || canonical?.parentFile != canonicalTempDir ||
                canonical?.name != file.name || !oldEnough(file)) {
                skipped++
                return
            }
            try {
                if (file.delete()) cleaned++ else if (file.exists()) {
                    skipped++
                    errors += "Could not delete temporary file: ${file.name}"
                }
            } catch (failure: Exception) {
                skipped++
                errors += "Temporary cleanup failed for ${file.name}: ${failure.message}"
            }
        }

        if (tempDir.exists()) {
            if (tempDirIsSafe && tempDir.isDirectory) {
                val tempEntries = tempDir.listFiles()
                if (tempEntries == null) {
                    skipped++
                    errors += "Cannot list attachment temporary directory"
                } else {
                    tempEntries.forEach(::deleteOwnedTemp)
                }
            } else if (tempDir.isFile) {
                skipped++
            }
        }

        val baseEntries = canonicalBase.listFiles()
        if (baseEntries == null) {
            errors += "Cannot list attachment directory"
            return AttachmentReconciliationResult(cleaned, skipped, errors, unsafeReferences = referencedKeys == null)
        }

        // Corrupt/unreadable media metadata makes the live reference set incomplete. Do not
        // infer that any content-addressed attachment is orphaned in that situation.
        if (referencedKeys == null) {
            for (entry in baseEntries) {
                if (entry.name == ".tmp") continue
                if (entry.isFile) {
                    skipped++
                } else if (entry.isDirectory && entry.name.matches(Regex("[a-f0-9]{2}"))) {
                    val files = entry.listFiles()
                    if (files == null) errors += "Cannot list attachment shard: ${entry.name}"
                    else skipped += files.count { it.isFile }
                }
            }
            return AttachmentReconciliationResult(cleaned, skipped, errors, unsafeReferences = true)
        }

        for (shard in baseEntries) {
            if (shard.name == ".tmp") continue
            if (!shard.isDirectory || !shard.name.matches(Regex("[a-f0-9]{2}"))) {
                if (shard.isFile) skipped++
                continue
            }
            val canonicalShard = runCatching { shard.canonicalFile }.getOrNull()
            if (canonicalShard == null || canonicalShard.parentFile != canonicalBase) {
                skipped++
                continue
            }
            val shardFiles = shard.listFiles()
            if (shardFiles == null) {
                skipped++
                errors += "Cannot list attachment shard: ${shard.name}"
                continue
            }
            for (file in shardFiles) {
                if (!file.isFile) continue
                val match = Regex("([a-f0-9]{64})\\.([a-z0-9]{1,10})").matchEntire(file.name)
                if (match == null || match.groupValues[1].take(2) != shard.name) {
                    skipped++
                    continue
                }
                val key = "${match.groupValues[1]}.${match.groupValues[2]}"
                if (key in referencedKeys || !oldEnough(file)) {
                    skipped++
                    continue
                }
                val canonicalFile = runCatching { file.canonicalFile }.getOrNull()
                if (canonicalFile == null || canonicalFile.parentFile != canonicalShard ||
                    canonicalFile.name != file.name) {
                    skipped++
                    continue
                }
                // Filename identity alone is not enough: preserve malformed or tampered blobs.
                val actualHash = try {
                    sha256(file)
                } catch (failure: Exception) {
                    skipped++
                    errors += "Could not verify ${file.name}: ${failure.message}"
                    continue
                }
                if (actualHash != match.groupValues[1]) {
                    skipped++
                    continue
                }
                try {
                    if (file.delete()) cleaned++ else if (file.exists()) {
                        skipped++
                        errors += "Could not delete attachment: ${file.name}"
                    }
                } catch (failure: Exception) {
                    skipped++
                    errors += "Attachment cleanup failed for ${file.name}: ${failure.message}"
                }
            }
        }
        return AttachmentReconciliationResult(cleaned, skipped, errors, unsafeReferences = false)
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                if (read > 0) digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    /** Verifies the stored bytes against the content address, not only their length. */
    fun verify(attachment: StoredAttachment): Boolean = runCatching {
        val digest = MessageDigest.getInstance("SHA-256")
        open(attachment).use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) { val read = input.read(buffer); if (read < 0) break; if (read > 0) digest.update(buffer, 0, read) }
        }
        digest.digest().joinToString("") { "%02x".format(it) } == attachment.sha256
    }.getOrDefault(false)

    fun exists(attachment: StoredAttachment): Boolean = runCatching {
        val file = resolve(attachment)
        file.isFile && file.length() == attachment.byteCount
    }.getOrDefault(false)

    /** Deletes only the addressed blob; callers must ensure no other element references it. */
    @Synchronized
    fun delete(attachment: StoredAttachment): Boolean {
        val file = resolve(attachment)
        return !file.exists() || file.delete()
    }

    companion object {
        const val DEFAULT_MAX_BYTES = 100L * 1024L * 1024L
        const val DEFAULT_RECONCILIATION_GRACE_MS = 24L * 60L * 60L * 1000L

        fun sanitizeDisplayName(name: String): String {
            val leaf = name.substringAfterLast('/').substringAfterLast('\\')
                .filter { it >= ' ' && it != '\u007f' }
                .trim().take(120)
            return leaf.ifBlank { "attachment" }
        }

        private fun extensionFromName(name: String): String? =
            name.substringAfterLast('.', "").takeIf { it.isNotBlank() }

        private fun sanitizeExtension(value: String): String {
            val cleaned = value.lowercase().filter { it in 'a'..'z' || it in '0'..'9' }.take(10)
            return cleaned.ifBlank { "bin" }
        }

        private fun extensionForMime(mime: String): String = when (mime.lowercase()) {
            "image/jpeg" -> "jpg"
            "image/png" -> "png"
            "image/webp" -> "webp"
            "image/gif" -> "gif"
            "application/pdf" -> "pdf"
            "audio/mpeg" -> "mp3"
            "audio/mp4" -> "m4a"
            "audio/wav", "audio/x-wav" -> "wav"
            "video/mp4" -> "mp4"
            else -> "bin"
        }
    }
}
