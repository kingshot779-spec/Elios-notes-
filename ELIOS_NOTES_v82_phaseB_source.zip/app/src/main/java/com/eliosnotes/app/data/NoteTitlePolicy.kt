package com.eliosnotes.app.data

/** Normalizes titles entered through explicit rename controls. */
object NoteTitlePolicy {
    const val MAX_LENGTH = 120

    /** Sanitizes a live editor draft while allowing an empty title (shown as Untitled in the library). */
    fun sanitizeDraft(raw: String): String = raw.filterNot { it.isISOControl() }.take(MAX_LENGTH)

    fun normalize(raw: String): String? {
        val title = sanitizeDraft(raw).trim()
        return title.takeIf { it.isNotEmpty() }
    }
}
