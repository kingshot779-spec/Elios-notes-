package com.eliosnotes.app.recognition

/**
 * Merges reviewed recognition output into the existing page text without touching source ink.
 * Kept pure so newline and preservation behaviour can be covered by JVM tests.
 */
internal object RecognitionTextMerge {
    fun append(existingText: String, recognizedText: String): String {
        val addition = recognizedText.trim()
        if (addition.isEmpty()) return existingText

        val existing = existingText.trimEnd()
        if (existing.isEmpty()) return addition
        return "$existing\n$addition"
    }
}
