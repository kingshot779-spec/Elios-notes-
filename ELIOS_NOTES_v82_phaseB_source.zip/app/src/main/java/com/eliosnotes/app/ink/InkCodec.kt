package com.eliosnotes.app.ink

import org.json.JSONObject
import kotlin.math.roundToInt

/**
 * Versioned, editable stroke payload stored in note_elements.payloadJson.
 * Points are quantised (0.1 page unit, 0.001 pressure) and delta-encoded as integers.
 * Defensive limits keep a damaged/imported payload from exhausting memory or overflowing
 * the coordinate accumulator. Invalid data is rejected (and remains protected by the repository).
 */
object InkCodec {
    const val PAYLOAD_VERSION = 1
    private const val POS_SCALE = 10f
    private const val PRESSURE_SCALE = 1000f
    private const val MAX_POINTS = 250_000
    private const val MAX_PAYLOAD_CHARS = 16 * 1024 * 1024
    private const val MAX_ABS_COORDINATE = 1_000_000f
    private const val MAX_WIDTH = 10_000f

    fun encode(stroke: Stroke): String {
        require(stroke.width.isFinite() && stroke.width > 0f && stroke.width <= MAX_WIDTH) {
            "Stroke width is outside the supported range"
        }
        require(stroke.points.size <= MAX_POINTS) { "Stroke contains too many points" }
        require(stroke.points.all(::isValidPoint)) { "Stroke contains an invalid point" }

        val sb = StringBuilder(stroke.points.size * 8)
        var px = 0
        var py = 0
        var pp = 0
        stroke.points.forEachIndexed { i, p ->
            val x = (p.x * POS_SCALE).roundToInt()
            val y = (p.y * POS_SCALE).roundToInt()
            val pr = (p.pressure.coerceIn(0f, 1f) * PRESSURE_SCALE).roundToInt()
            if (i > 0) sb.append(' ')
            sb.append(x - px).append(' ').append(y - py).append(' ').append(pr - pp)
            px = x; py = y; pp = pr
        }
        val encoded = JSONObject()
            .put("tool", stroke.tool.name)
            .put("color", stroke.colorArgb)
            .put("width", stroke.width.toDouble())
            .put("pts", sb.toString())
            .toString()
        require(encoded.length <= MAX_PAYLOAD_CHARS) { "Stroke payload is too large" }
        return encoded
    }

    /** Returns null for corrupt, unreasonable, or unknown payloads instead of crashing a page. */
    fun decode(id: String, json: String): Stroke? {
        return try {
            if (json.length > MAX_PAYLOAD_CHARS) return null
        val o = JSONObject(json)
        val tool = runCatching { InkTool.valueOf(o.getString("tool")) }.getOrNull() ?: return null
        val width = o.getDouble("width").toFloat()
        if (!width.isFinite() || width <= 0f || width > MAX_WIDTH) return null
        val raw = o.getString("pts")
        if (raw.length > MAX_POINTS * 36) return null
        val tokens = if (raw.isEmpty()) emptyList() else raw.split(' ')
        if (tokens.size % 3 != 0 || tokens.size / 3 > MAX_POINTS) return null

        val pts = ArrayList<InkPoint>(tokens.size / 3)
        var x = 0L
        var y = 0L
        var pr = 0L
        var i = 0
        while (i < tokens.size) {
            x += tokens[i].toLong()
            y += tokens[i + 1].toLong()
            pr += tokens[i + 2].toLong()
            if (x !in -10_000_000L..10_000_000L || y !in -10_000_000L..10_000_000L || pr !in 0L..1000L) {
                return null
            }
            pts.add(InkPoint(x / POS_SCALE, y / POS_SCALE, pr / PRESSURE_SCALE))
            i += 3
        }
        Stroke(id, tool, o.getInt("color"), width, pts)
        } catch (e: Exception) {
            null
        }
    }

    private fun isValidPoint(point: InkPoint): Boolean =
        point.x.isFinite() && point.y.isFinite() &&
            kotlin.math.abs(point.x) <= MAX_ABS_COORDINATE &&
            kotlin.math.abs(point.y) <= MAX_ABS_COORDINATE &&
            point.pressure.isFinite() && point.pressure in 0f..1f
}
