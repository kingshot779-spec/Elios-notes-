package com.eliosnotes.app.data

import java.text.Normalizer
import java.util.Locale

/**
 * Comparison-only normalization for note and folder search.
 *
 * The stored title/body are never modified. Arabic diacritics and tatweel are ignored, common
 * alef variants are folded, and repeated whitespace is collapsed so students can find text
 * regardless of keyboard/input variation.
 */
object NoteSearchNormalizer {
    fun normalize(value: String): String {
        val decomposed = Normalizer.normalize(value, Normalizer.Form.NFD)
        val result = StringBuilder(decomposed.length)
        var pendingSpace = false

        decomposed.codePoints().forEach { codePoint ->
            when {
                codePoint == 0x0640 -> Unit // Arabic tatweel
                Character.getType(codePoint) == Character.NON_SPACING_MARK.toInt() ||
                    Character.getType(codePoint) == Character.COMBINING_SPACING_MARK.toInt() ||
                    Character.getType(codePoint) == Character.ENCLOSING_MARK.toInt() -> Unit
                Character.isWhitespace(codePoint) -> pendingSpace = result.isNotEmpty()
                else -> {
                    if (pendingSpace) result.append(' ')
                    pendingSpace = false
                    val folded = when (codePoint) {
                        0x0622, 0x0623, 0x0625, 0x0671 -> 0x0627 // آ أ إ ٱ -> ا
                        0x0649 -> 0x064A // ى -> ي
                        else -> codePoint
                    }
                    result.appendCodePoint(folded)
                }
            }
        }
        return result.toString().lowercase(Locale.ROOT).trim()
    }

    fun matches(value: String, normalizedQuery: String): Boolean =
        normalizedQuery.isEmpty() || normalize(value).contains(normalizedQuery)
}
