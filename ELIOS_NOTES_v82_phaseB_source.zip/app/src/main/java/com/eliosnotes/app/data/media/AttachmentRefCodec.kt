package com.eliosnotes.app.data.media

import org.json.JSONObject

/** Versioned, renderer-independent metadata stored in a NOTE_ELEMENTS payload. */
object AttachmentRefCodec {
    const val VERSION = 1

    fun encode(ref: StoredAttachment): String = JSONObject()
        .put("version", VERSION)
        .put("sha256", ref.sha256)
        .put("extension", ref.extension)
        .put("byteCount", ref.byteCount)
        .put("mimeType", ref.mimeType)
        .put("displayName", ref.displayName)
        .toString()

    fun decodeOrNull(payload: String): StoredAttachment? {
        return try {
            val json = JSONObject(payload)
            if (json.optInt("version", -1) != VERSION) return null
            StoredAttachment(
                sha256 = json.getString("sha256"),
                extension = json.getString("extension"),
                byteCount = json.getLong("byteCount"),
                mimeType = json.getString("mimeType"),
                displayName = AttachmentStorage.sanitizeDisplayName(json.getString("displayName"))
            )
        } catch (_: Exception) { null }
    }

    /**
     * Returns the complete content-addressed reference set, or null when any media row is
     * undecodable. Null is intentionally distinct from an empty set: callers must never treat
     * incomplete metadata as proof that every stored blob is orphaned.
     */
    fun collectReferencedKeys(
        elements: Iterable<Pair<String, String>>,
        mediaElementTypes: Set<String>
    ): Set<String>? {
        val keys = LinkedHashSet<String>()
        val knownElementTypes = mediaElementTypes + setOf("TEXT", "INK")
        for ((type, payload) in elements) {
            if (type !in mediaElementTypes) {
                // A future/unknown element type may carry a media reference. Treat it as an
                // incomplete snapshot rather than risking deletion during an app downgrade.
                if (type !in knownElementTypes) return null
                continue
            }
            val ref = decodeOrNull(payload) ?: return null
            keys += "${ref.sha256}.${ref.extension}"
        }
        return keys
    }
}
