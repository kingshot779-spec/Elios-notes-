package com.eliosnotes.app.ui.editor

internal enum class InkPointerDevice { STYLUS, ERASER, MOUSE, TOUCH, OTHER }

/** Input arbitration for drawing: active stylus contacts take priority over concurrent touch. */
internal object InkPointerPolicy {
    fun canStartInk(device: InkPointerDevice, fingerDraws: Boolean): Boolean = when (device) {
        InkPointerDevice.STYLUS, InkPointerDevice.ERASER, InkPointerDevice.MOUSE -> true
        InkPointerDevice.TOUCH -> fingerDraws
        InkPointerDevice.OTHER -> false
    }

    /** Lasso is a selection/manipulation gesture, so finger use stays available even in pen-only ink mode. */
    fun canStartLasso(device: InkPointerDevice): Boolean = device != InkPointerDevice.OTHER

    fun shouldSuppressConcurrentPointer(active: InkPointerDevice, other: InkPointerDevice): Boolean =
        (active == InkPointerDevice.STYLUS || active == InkPointerDevice.ERASER) &&
            other == InkPointerDevice.TOUCH
}
