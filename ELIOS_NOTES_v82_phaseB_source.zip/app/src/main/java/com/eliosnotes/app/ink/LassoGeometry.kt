package com.eliosnotes.app.ink

import kotlin.math.abs

/** Freehand selection geometry in page coordinates. */
object LassoGeometry {
    fun contains(polygon: List<InkPoint>, x: Float, y: Float): Boolean {
        if (polygon.size < 3) return false
        var inside = false
        var j = polygon.lastIndex
        for (i in polygon.indices) {
            val a = polygon[i]
            val b = polygon[j]
            if (onSegment(x, y, a.x, a.y, b.x, b.y)) return true
            val crosses = (a.y > y) != (b.y > y) &&
                x < (b.x - a.x) * (y - a.y) / (b.y - a.y) + a.x
            if (crosses) inside = !inside
            j = i
        }
        return inside
    }

    fun intersects(stroke: Stroke, polygon: List<InkPoint>): Boolean {
        if (polygon.size < 3 || stroke.points.isEmpty()) return false
        val b = stroke.bounds
        val minX = polygon.minOf { it.x }; val maxX = polygon.maxOf { it.x }
        val minY = polygon.minOf { it.y }; val maxY = polygon.maxOf { it.y }
        val pad = stroke.width * 0.75f
        if (b[2] + pad < minX || b[0] - pad > maxX || b[3] + pad < minY || b[1] - pad > maxY) return false
        val radiusSquared = pad * pad
        if (stroke.points.any { contains(polygon, it.x, it.y) }) return true
        if (stroke.points.size == 1) {
            val point = stroke.points[0]
            return polygon.indices.any { i ->
                val a = polygon[i]; val b = polygon[(i + 1) % polygon.size]
                pointSegmentDistanceSquared(point.x, point.y, a.x, a.y, b.x, b.y) <= radiusSquared
            }
        }
        for (i in 0 until stroke.points.lastIndex) {
            val a = stroke.points[i]; val c = stroke.points[i + 1]
            for (j in polygon.indices) {
                val p = polygon[j]; val q = polygon[(j + 1) % polygon.size]
                if (segmentsIntersect(a.x, a.y, c.x, c.y, p.x, p.y, q.x, q.y)) return true
                if (minOf(
                        pointSegmentDistanceSquared(a.x, a.y, p.x, p.y, q.x, q.y),
                        pointSegmentDistanceSquared(c.x, c.y, p.x, p.y, q.x, q.y),
                        pointSegmentDistanceSquared(p.x, p.y, a.x, a.y, c.x, c.y),
                        pointSegmentDistanceSquared(q.x, q.y, a.x, a.y, c.x, c.y)
                    ) <= radiusSquared
                ) return true
            }
        }
        return false
    }

    fun select(strokes: List<Stroke>, polygon: List<InkPoint>): Set<String> =
        strokes.filter { intersects(it, polygon) }.mapTo(LinkedHashSet()) { it.id }

    fun translate(strokes: List<Stroke>, ids: Set<String>, dx: Float, dy: Float): List<Stroke> {
        if (ids.isEmpty() || (dx == 0f && dy == 0f)) return strokes
        return strokes.map { s ->
            if (s.id !in ids) s else Stroke(
                s.id, s.tool, s.colorArgb, s.width,
                s.points.map { InkPoint(it.x + dx, it.y + dy, it.pressure) }
            )
        }
    }

    private fun pointSegmentDistanceSquared(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = bx - ax
        val dy = by - ay
        val lengthSquared = dx * dx + dy * dy
        if (lengthSquared <= 0.000001f) {
            val ox = px - ax
            val oy = py - ay
            return ox * ox + oy * oy
        }
        val t = (((px - ax) * dx + (py - ay) * dy) / lengthSquared).coerceIn(0f, 1f)
        val ox = px - (ax + t * dx)
        val oy = py - (ay + t * dy)
        return ox * ox + oy * oy
    }

    private fun onSegment(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Boolean {
        val cross = (px - ax) * (by - ay) - (py - ay) * (bx - ax)
        if (abs(cross) > 0.001f) return false
        return px >= minOf(ax, bx) - 0.001f && px <= maxOf(ax, bx) + 0.001f &&
            py >= minOf(ay, by) - 0.001f && py <= maxOf(ay, by) + 0.001f
    }

    private fun segmentsIntersect(ax: Float, ay: Float, bx: Float, by: Float,
                                  cx: Float, cy: Float, dx: Float, dy: Float): Boolean {
        fun orient(px: Float, py: Float, qx: Float, qy: Float, rx: Float, ry: Float) =
            (qx - px) * (ry - py) - (qy - py) * (rx - px)
        val o1 = orient(ax, ay, bx, by, cx, cy)
        val o2 = orient(ax, ay, bx, by, dx, dy)
        val o3 = orient(cx, cy, dx, dy, ax, ay)
        val o4 = orient(cx, cy, dx, dy, bx, by)
        return ((o1 > 0f && o2 < 0f) || (o1 < 0f && o2 > 0f)) &&
            ((o3 > 0f && o4 < 0f) || (o3 < 0f && o4 > 0f)) ||
            (abs(o1) <= 0.001f && onSegment(cx, cy, ax, ay, bx, by)) ||
            (abs(o2) <= 0.001f && onSegment(dx, dy, ax, ay, bx, by)) ||
            (abs(o3) <= 0.001f && onSegment(ax, ay, cx, cy, dx, dy)) ||
            (abs(o4) <= 0.001f && onSegment(bx, by, cx, cy, dx, dy))
    }
}
