package com.eliosnotes.app.ui.editor

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.provider.OpenableColumns
import android.graphics.BitmapFactory
import android.content.Intent
import androidx.core.content.FileProvider
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.produceState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.eliosnotes.app.R
import com.eliosnotes.app.data.document.PageMode
import com.eliosnotes.app.data.document.PageOrientation
import com.eliosnotes.app.data.document.PageTemplate
import com.eliosnotes.app.pdf.PdfExporter
import com.eliosnotes.app.ink.InkBeautifier
import com.eliosnotes.app.ink.InkBeautificationLevel
import com.eliosnotes.app.ink.Stroke as InkStroke
import com.eliosnotes.app.recognition.HandwritingRecognition
import com.eliosnotes.app.recognition.RecognitionTextMerge
import com.eliosnotes.app.recognition.RecognitionLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val INK_PALETTE = listOf(0xFF1B1F23, 0xFF1E4FA3, 0xFFD32F2F, 0xFF2E7D32, 0xFFEF6C00, 0xFF7B1FA2, 0xFF607D8B).map { Color(it) }
private val HIGHLIGHT_PALETTE = listOf(0xFFFFEB3B, 0xFF76FF03, 0xFFFF80AB, 0xFF18FFFF, 0xFFFFAB40).map { Color(it) }
private val PAGE_COLORS = listOf(0xFFFFFFFFL, 0xFFFFF8E1L, 0xFFF2F2F2L, 0xFFE8F1FBL, 0xFFFCE4ECL, 0xFFE8F5E9L, 0xFFFFF3E0L, 0xFFEDE7F6L, 0xFF1F2328L)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(session: EditorSession, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val listState = rememberLazyListState()
    var zoomScale by remember { mutableFloatStateOf(1f) }
    var panOffset by remember { mutableStateOf(Offset.Zero) }
    val transformState = rememberTransformableState { zoomChange, panChange, _ ->
        val nextScale = (zoomScale * zoomChange).coerceIn(0.75f, 2.5f)
        zoomScale = nextScale
        panOffset = if (nextScale <= 1f) Offset.Zero else Offset(
            (panOffset.x + panChange.x).coerceIn(-1200f, 1200f),
            (panOffset.y + panChange.y).coerceIn(-1200f, 1200f)
        )
    }
    var menuOpen by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showPageOverview by remember { mutableStateOf(false) }
    var pageOperationBusy by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var confirmMoveToTrash by remember { mutableStateOf(false) }
    var leavingEditor by remember { mutableStateOf(false) }
    var showRecognitionNotice by remember { mutableStateOf(false) }
    var showBeautificationDialog by remember { mutableStateOf(false) }
    var beautificationTargetPage by remember { mutableStateOf<EditorPage?>(null) }
    var beautificationLevel by remember { mutableStateOf(InkBeautificationLevel.MEDIUM) }
    var recognitionBusy by remember { mutableStateOf(false) }
    var showRecognitionResult by remember { mutableStateOf(false) }
    var recognitionText by remember { mutableStateOf("") }
    var recognitionLanguage by remember { mutableStateOf(RecognitionLanguage.AUTO) }
    var recognitionTargetPage by remember { mutableStateOf<EditorPage?>(null) }
    val currentPage by remember { derivedStateOf { listState.firstVisibleItemIndex } }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) {
            val pages = session.snapshot()
            scope.launch {
                val result = withContext(Dispatchers.IO) { PdfExporter.export(context, uri, pages) }
                snackbar.showSnackbar(
                    if (result.ok) context.getString(R.string.export_done, result.pageCount)
                    else context.getString(R.string.export_failed)
                )
            }
        }
    }

    val attachmentLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val target = session.pages.getOrNull(currentPage)
            if (target != null) scope.launch {
                runCatching {
                    val name = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                        ?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
                        ?: uri.lastPathSegment?.substringAfterLast('/') ?: "attachment"
                    val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"
                    val input = context.contentResolver.openInputStream(uri) ?: error("Cannot open selected file")
                    input.use { session.addAttachment(target.id, it, name, mime) }
                }.onSuccess {
                    snackbar.showSnackbar(context.getString(R.string.attachment_added))
                }.onFailure {
                    snackbar.showSnackbar(context.getString(R.string.attachment_failed))
                }
            }
        }
    }

    BackHandler(enabled = !leavingEditor) {
        leavingEditor = true
        scope.launch {
            if (session.flushAndAwait()) onBack()
            else {
                leavingEditor = false
                snackbar.showSnackbar(context.getString(R.string.save_before_exit_failed))
            }
        }
    }
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { session.flush() }

    val paged = session.pageMode == PageMode.INDIVIDUAL_PAGES
    val untitled = stringResource(R.string.untitled_note)

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(enabled = !leavingEditor, onClick = {
                        leavingEditor = true
                        scope.launch {
                            if (session.flushAndAwait()) onBack()
                            else {
                                leavingEditor = false
                                snackbar.showSnackbar(context.getString(R.string.save_before_exit_failed))
                            }
                        }
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
                title = {
                    BasicTextField(
                        value = session.title,
                        onValueChange = { session.onTitleChange(com.eliosnotes.app.data.NoteTitlePolicy.sanitizeDraft(it)) },
                        singleLine = true,
                        textStyle = MaterialTheme.typography.titleLarge.copy(color = MaterialTheme.colorScheme.onSurface),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                        decorationBox = { inner ->
                            Box {
                                if (session.title.isEmpty()) {
                                    Text(
                                        stringResource(R.string.title_hint),
                                        style = MaterialTheme.typography.titleLarge,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                                inner()
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                actions = {
                    IconButton(onClick = session::undo, enabled = session.canUndo) {
                        Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = stringResource(R.string.undo))
                    }
                    IconButton(onClick = session::redo, enabled = session.canRedo) {
                        Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = stringResource(R.string.redo))
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = null)
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text(stringResource(if (session.isFavorite) R.string.remove_favorite else R.string.add_favorite)) },
                                onClick = { menuOpen = false; session.toggleFavorite() }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.add_attachment)) },
                                onClick = { menuOpen = false; attachmentLauncher.launch("*/*") }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.page_overview)) },
                                onClick = { menuOpen = false; showPageOverview = true }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.add_page)) },
                                onClick = {
                                    menuOpen = false
                                    session.addPage()
                                    scope.launch {
                                        delay(60)
                                        listState.animateScrollToItem(session.pages.lastIndex)
                                    }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.insert_page_before)) },
                                onClick = {
                                    menuOpen = false
                                    session.insertPageAt(currentPage)
                                    scope.launch { listState.animateScrollToItem(currentPage) }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.insert_page_after)) },
                                onClick = {
                                    menuOpen = false
                                    session.insertPageAt(currentPage + 1)
                                    scope.launch { listState.animateScrollToItem(currentPage + 1) }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.move_page_up)) },
                                enabled = currentPage > 0,
                                onClick = {
                                    menuOpen = false
                                    session.pages.getOrNull(currentPage)?.let { page ->
                                        if (!pageOperationBusy) scope.launch {
                                            pageOperationBusy = true
                                            try {
                                                val moved = session.movePage(page, -1)
                                                if (!moved) snackbar.showSnackbar(context.getString(R.string.page_reorder_failed))
                                                else listState.animateScrollToItem((currentPage - 1).coerceAtLeast(0))
                                            } finally {
                                                pageOperationBusy = false
                                            }
                                        }
                                    }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.move_page_down)) },
                                enabled = currentPage < session.pages.lastIndex,
                                onClick = {
                                    menuOpen = false
                                    session.pages.getOrNull(currentPage)?.let { page ->
                                        if (!pageOperationBusy) scope.launch {
                                            pageOperationBusy = true
                                            try {
                                                val moved = session.movePage(page, 1)
                                                if (!moved) snackbar.showSnackbar(context.getString(R.string.page_reorder_failed))
                                                else listState.animateScrollToItem((currentPage + 1).coerceAtMost(session.pages.lastIndex))
                                            } finally {
                                                pageOperationBusy = false
                                            }
                                        }
                                    }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.duplicate_page)) },
                                enabled = !pageOperationBusy && session.pages.getOrNull(currentPage) != null,
                                onClick = {
                                    menuOpen = false
                                    val sourceId = session.pages.getOrNull(currentPage)?.id
                                    if (sourceId != null) scope.launch {
                                        pageOperationBusy = true
                                        val newId = session.duplicatePage(sourceId)
                                        pageOperationBusy = false
                                        if (newId == null) {
                                            snackbar.showSnackbar(context.getString(R.string.duplicate_page_failed))
                                        } else {
                                            val newIndex = session.pages.indexOfFirst { it.id == newId }
                                            if (newIndex >= 0) listState.animateScrollToItem(newIndex)
                                            snackbar.showSnackbar(context.getString(R.string.duplicate_page_done))
                                        }
                                    }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.delete_page)) },
                                onClick = { menuOpen = false; confirmDelete = true }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.zoom_in)) },
                                onClick = { menuOpen = false; zoomScale = (zoomScale * 1.2f).coerceAtMost(2.5f) }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.zoom_out)) },
                                onClick = {
                                    menuOpen = false
                                    zoomScale = (zoomScale / 1.2f).coerceAtLeast(0.75f)
                                    if (zoomScale <= 1f) panOffset = Offset.Zero
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.reset_zoom)) },
                                onClick = { menuOpen = false; zoomScale = 1f; panOffset = Offset.Zero }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.page_settings)) },
                                onClick = { menuOpen = false; showSettings = true }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.recognize_handwriting)) },
                                onClick = {
                                    menuOpen = false
                                    recognitionTargetPage = session.pages.getOrNull(currentPage)
                                    showRecognitionNotice = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.beautify_handwriting)) },
                                onClick = {
                                    menuOpen = false
                                    beautificationTargetPage = session.pages.getOrNull(currentPage)
                                    beautificationLevel = InkBeautificationLevel.MEDIUM
                                    showBeautificationDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.export_pdf)) },
                                onClick = {
                                    menuOpen = false
                                    val safe = session.title.ifBlank { untitled }.replace(Regex("[\\\\/:*?\"<>|]"), "_")
                                    exportLauncher.launch("$safe.pdf")
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.move_to_trash)) },
                                onClick = { menuOpen = false; confirmMoveToTrash = true }
                            )
                        }
                    }
                }
            )
        },
        bottomBar = { EditorToolbar(session) }
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .background(if (paged) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = zoomScale
                        scaleY = zoomScale
                        translationX = panOffset.x
                        translationY = panOffset.y
                    }
                    .transformable(state = transformState, canPan = { zoomScale > 1f }),
                horizontalAlignment = Alignment.CenterHorizontally,
                contentPadding = PaddingValues(if (paged) 12.dp else 0.dp),
                verticalArrangement = Arrangement.spacedBy(if (paged) 14.dp else 0.dp)
            ) {
                itemsIndexed(session.pages, key = { _, p -> p.id }) { index, page ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        PageView(
                            page = page,
                            session = session,
                            modifier = Modifier
                                .widthIn(max = 900.dp)
                                .then(if (paged) Modifier.shadow(3.dp) else Modifier)
                        )
                        page.attachments.forEach { attachment ->
                            Surface(
                                modifier = Modifier.fillMaxWidth().widthIn(max = 900.dp).padding(top = 6.dp),
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceContainerHigh
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().clickable {
                                        scope.launch {
                                            val opened = withContext(Dispatchers.IO) { session.verifyAttachment(attachment.ref) }
                                            if (!opened) {
                                                snackbar.showSnackbar(context.getString(R.string.attachment_corrupt))
                                            } else runCatching {
                                                val file = session.attachmentFile(attachment.ref)
                                                val contentUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                                val intent = Intent(Intent.ACTION_VIEW).setDataAndType(contentUri, attachment.ref.mimeType)
                                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                context.startActivity(intent)
                                            }.onFailure { snackbar.showSnackbar(context.getString(R.string.attachment_open_failed)) }
                                        }
                                    }.padding(horizontal = 14.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (attachment.ref.mimeType.startsWith("image/")) {
                                        val imageFile = remember(attachment.ref.sha256, attachment.ref.extension) {
                                            session.attachmentFile(attachment.ref)
                                        }
                                        AttachmentImageThumbnail(
                                            file = imageFile,
                                            description = attachment.ref.displayName
                                        )
                                    }
                                    Column(Modifier.weight(1f).padding(start = 10.dp)) {
                                        Text(attachment.ref.displayName, style = MaterialTheme.typography.bodyMedium)
                                        Text(
                                            "${attachment.ref.mimeType} · ${android.text.format.Formatter.formatShortFileSize(context, attachment.ref.byteCount)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    TextButton(onClick = {
                                        scope.launch {
                                            val removed = session.removeAttachment(page.id, attachment.elementId)
                                            snackbar.showSnackbar(context.getString(if (removed) R.string.attachment_removed else R.string.attachment_remove_failed))
                                        }
                                    }) { Text(stringResource(R.string.remove)) }
                                }
                            }
                        }
                        if (paged) {
                            Text(
                                stringResource(R.string.page_counter, index + 1, session.pages.size),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 6.dp)
                            )
                        }
                    }
                }
            }
            if (session.saveFailed) {
                Surface(
                    modifier = Modifier.align(Alignment.TopCenter).padding(8.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.errorContainer
                ) {
                    Row(
                        modifier = Modifier.padding(start = 14.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            stringResource(R.string.save_failed),
                            modifier = Modifier.weight(1f),
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.labelLarge
                        )
                        TextButton(enabled = !leavingEditor, onClick = session::retrySave) {
                            Text(stringResource(R.string.retry_save), color = MaterialTheme.colorScheme.onErrorContainer)
                        }
                    }
                }
            }
        }
    }

    if (leavingEditor) {
        Dialog(onDismissRequest = {}) {
            Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface) {
                Row(
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                    Text(stringResource(R.string.saving_changes))
                }
            }
        }
    }

    if (confirmMoveToTrash) {
        AlertDialog(
            onDismissRequest = { confirmMoveToTrash = false },
            title = { Text(stringResource(R.string.move_to_trash)) },
            text = { Text(stringResource(R.string.move_note_to_trash_confirm)) },
            confirmButton = {
                TextButton(enabled = !leavingEditor, onClick = {
                    confirmMoveToTrash = false
                    leavingEditor = true
                    scope.launch {
                        if (session.moveToTrash()) onBack()
                        else {
                            leavingEditor = false
                            snackbar.showSnackbar(context.getString(R.string.trash_action_failed))
                        }
                    }
                }) { Text(stringResource(R.string.move_to_trash)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmMoveToTrash = false }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(R.string.delete_page)) },
            text = { Text(stringResource(R.string.delete_page_confirm_n, currentPage + 1, session.pages.size)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    session.pages.getOrNull(currentPage)?.let { session.deletePage(it) }
                }) { Text(stringResource(R.string.delete_page)) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
    if (showRecognitionNotice) {
        AlertDialog(
            onDismissRequest = { showRecognitionNotice = false },
            title = { Text(stringResource(R.string.recognize_handwriting)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(stringResource(R.string.recognition_notice))
                    Text(stringResource(R.string.recognition_language_label), style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = recognitionLanguage == RecognitionLanguage.AUTO,
                            onClick = { recognitionLanguage = RecognitionLanguage.AUTO },
                            label = { Text(stringResource(R.string.recognition_language_auto)) }
                        )
                        FilterChip(
                            selected = recognitionLanguage == RecognitionLanguage.ARABIC,
                            onClick = { recognitionLanguage = RecognitionLanguage.ARABIC },
                            label = { Text(stringResource(R.string.recognition_language_arabic)) }
                        )
                        FilterChip(
                            selected = recognitionLanguage == RecognitionLanguage.ENGLISH,
                            onClick = { recognitionLanguage = RecognitionLanguage.ENGLISH },
                            label = { Text(stringResource(R.string.recognition_language_english)) }
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showRecognitionNotice = false
                    val target = recognitionTargetPage
                    if (target == null || target.strokes.isEmpty()) {
                        scope.launch { snackbar.showSnackbar(context.getString(R.string.recognition_no_ink)) }
                    } else {
                        scope.launch {
                            recognitionBusy = true
                            try {
                                recognitionText = HandwritingRecognition.recognizeArabicAndEnglish(target.strokes, recognitionLanguage)
                                if (recognitionText.isBlank()) {
                                    snackbar.showSnackbar(context.getString(R.string.recognition_empty))
                                } else {
                                    showRecognitionResult = true
                                }
                            } catch (e: Exception) {
                                snackbar.showSnackbar(context.getString(R.string.recognition_failed))
                            } finally {
                                recognitionBusy = false
                            }
                        }
                    }
                }) { Text(stringResource(R.string.continue_action)) }
            },
            dismissButton = {
                TextButton(onClick = { showRecognitionNotice = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
    if (recognitionBusy) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text(stringResource(R.string.recognition_downloading)) },
            text = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    CircularProgressIndicator()
                    Text(stringResource(R.string.recognition_wait))
                }
            },
            confirmButton = {}
        )
    }
    if (showRecognitionResult) {
        AlertDialog(
            onDismissRequest = { showRecognitionResult = false },
            title = { Text(stringResource(R.string.recognition_result)) },
            text = {
                OutlinedTextField(
                    value = recognitionText,
                    onValueChange = { recognitionText = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    maxLines = 10
                )
            },
            confirmButton = {
                TextButton(
                    enabled = recognitionTargetPage != null && recognitionTargetPage?.textLocked == false &&
                        recognitionText.isNotBlank(),
                    onClick = {
                        val target = recognitionTargetPage
                        if (target != null && !target.textLocked) {
                            val merged = RecognitionTextMerge.append(target.text, recognitionText)
                            session.onTextChange(target, merged)
                        }
                        showRecognitionResult = false
                    }
                ) { Text(stringResource(R.string.recognition_insert)) }
            },
            dismissButton = {
                TextButton(onClick = { showRecognitionResult = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
    if (showPageOverview) {
        PageOverviewDialog(
            pages = session.pages,
            activeIndex = currentPage,
            busy = pageOperationBusy,
            onDismiss = { showPageOverview = false },
            onSelect = { index ->
                showPageOverview = false
                scope.launch { listState.animateScrollToItem(index) }
            },
            onMove = { index, direction ->
                session.pages.getOrNull(index)?.let { page ->
                    val activePageId = session.pages.getOrNull(currentPage)?.id
                    if (!pageOperationBusy) scope.launch {
                        pageOperationBusy = true
                        try {
                            val moved = session.movePage(page, direction)
                            if (!moved) snackbar.showSnackbar(context.getString(R.string.page_reorder_failed))
                            else activePageId?.let { id ->
                                val activeIndex = session.pages.indexOfFirst { it.id == id }
                                if (activeIndex >= 0) listState.animateScrollToItem(activeIndex)
                            }
                        } finally {
                            pageOperationBusy = false
                        }
                    }
                }
            },
            onReorder = { orderedIds ->
                val activePageId = session.pages.getOrNull(currentPage)?.id
                if (!pageOperationBusy) scope.launch {
                    pageOperationBusy = true
                    try {
                        val reordered = session.reorderPages(orderedIds)
                        if (!reordered) {
                            showPageOverview = false
                            snackbar.showSnackbar(context.getString(R.string.page_reorder_failed))
                        } else {
                            activePageId?.let { id ->
                                val activeIndex = session.pages.indexOfFirst { it.id == id }
                                if (activeIndex >= 0) listState.animateScrollToItem(activeIndex)
                            }
                        }
                    } finally {
                        pageOperationBusy = false
                    }
                }
            },
            onDuplicate = { pageId ->
                if (!pageOperationBusy) scope.launch {
                    pageOperationBusy = true
                    try {
                        val newId = session.duplicatePage(pageId)
                        if (newId == null) {
                            snackbar.showSnackbar(context.getString(R.string.duplicate_page_failed))
                        } else {
                            showPageOverview = false
                            val newIndex = session.pages.indexOfFirst { it.id == newId }
                            if (newIndex >= 0) listState.animateScrollToItem(newIndex)
                            snackbar.showSnackbar(context.getString(R.string.duplicate_page_done))
                        }
                    } finally {
                        pageOperationBusy = false
                    }
                }
            }
        )
    }

    if (showSettings) PageSettingsDialog(session, session.pages.getOrNull(currentPage)?.id) { showSettings = false }

    if (showBeautificationDialog) {
        val target = beautificationTargetPage
        val original = target?.strokes.orEmpty()
        val preview = remember(target?.id, original, beautificationLevel) {
            InkBeautifier.beautify(original, beautificationLevel)
        }
        AlertDialog(
            onDismissRequest = { showBeautificationDialog = false },
            title = { Text(stringResource(R.string.beautify_handwriting)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(stringResource(R.string.beautify_notice))
                    Text(stringResource(R.string.beautify_before), style = MaterialTheme.typography.labelMedium)
                    InkStrokePreview(original)
                    Text(stringResource(R.string.beautify_after), style = MaterialTheme.typography.labelMedium)
                    InkStrokePreview(preview)
                    Text(stringResource(R.string.beautify_strength), style = MaterialTheme.typography.labelMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = beautificationLevel == InkBeautificationLevel.LIGHT,
                            onClick = { beautificationLevel = InkBeautificationLevel.LIGHT },
                            label = { Text(stringResource(R.string.beautify_light)) }
                        )
                        FilterChip(
                            selected = beautificationLevel == InkBeautificationLevel.MEDIUM,
                            onClick = { beautificationLevel = InkBeautificationLevel.MEDIUM },
                            label = { Text(stringResource(R.string.beautify_medium)) }
                        )
                        FilterChip(
                            selected = beautificationLevel == InkBeautificationLevel.STRONG,
                            onClick = { beautificationLevel = InkBeautificationLevel.STRONG },
                            label = { Text(stringResource(R.string.beautify_strong)) }
                        )
                    }
                    if (original.isEmpty()) Text(stringResource(R.string.recognition_no_ink), color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = {
                TextButton(
                    enabled = target != null && preview !== original && preview != original,
                    onClick = {
                        val changed = target?.let { session.applyBeautification(it, beautificationLevel) } == true
                        showBeautificationDialog = false
                        scope.launch {
                            snackbar.showSnackbar(context.getString(if (changed) R.string.beautify_applied else R.string.beautify_no_change))
                        }
                    }
                ) { Text(stringResource(R.string.beautify_apply)) }
            },
            dismissButton = {
                TextButton(onClick = { showBeautificationDialog = false }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }
}

@Composable
private fun InkStrokePreview(strokes: List<InkStroke>) {
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
    ) {
        val points = strokes.flatMap { it.points }.filter { it.x.isFinite() && it.y.isFinite() }
        if (points.isEmpty()) return@Canvas
        val minX = points.minOf { it.x }
        val maxX = points.maxOf { it.x }
        val minY = points.minOf { it.y }
        val maxY = points.maxOf { it.y }
        val sourceW = (maxX - minX).coerceAtLeast(1f)
        val sourceH = (maxY - minY).coerceAtLeast(1f)
        val scale = minOf((size.width - 20f) / sourceW, (size.height - 16f) / sourceH).coerceAtLeast(0.01f)
        val offsetX = (size.width - sourceW * scale) / 2f
        val offsetY = (size.height - sourceH * scale) / 2f
        strokes.forEach { stroke ->
            stroke.points.zipWithNext().forEach { (a, b) ->
                if (a.x.isFinite() && a.y.isFinite() && b.x.isFinite() && b.y.isFinite()) {
                    drawLine(
                        color = Color(stroke.colorArgb),
                        start = Offset(offsetX + (a.x - minX) * scale, offsetY + (a.y - minY) * scale),
                        end = Offset(offsetX + (b.x - minX) * scale, offsetY + (b.y - minY) * scale),
                        strokeWidth = (stroke.width * scale).coerceIn(1f, 5f)
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------
// Toolbar
// ---------------------------------------------------------------------------------------

private fun toolIcon(t: EditorTool): ImageVector = when (t) {
    EditorTool.PEN -> Icons.Default.Edit
    EditorTool.PENCIL -> Icons.Default.Create
    EditorTool.MARKER -> Icons.Default.Brush
    EditorTool.HIGHLIGHTER -> Icons.Default.Highlight
    EditorTool.ERASER -> Icons.AutoMirrored.Filled.Backspace
    EditorTool.TEXT -> Icons.Default.TextFields
    EditorTool.LASSO -> Icons.Default.SelectAll
}

private fun toolLabel(t: EditorTool): Int = when (t) {
    EditorTool.PEN -> R.string.tool_pen
    EditorTool.PENCIL -> R.string.tool_pencil
    EditorTool.MARKER -> R.string.tool_marker
    EditorTool.HIGHLIGHTER -> R.string.tool_highlighter
    EditorTool.ERASER -> R.string.tool_eraser
    EditorTool.TEXT -> R.string.tool_text
    EditorTool.LASSO -> R.string.tool_lasso
}

@Composable
private fun EditorToolbar(session: EditorSession) {
    Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.navigationBarsPadding().imePadding()) {
            val selectedPage = session.pages.firstOrNull { it.id == session.selectedPageId }
            if (selectedPage != null && session.selectedStrokeIds.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        stringResource(R.string.selected_strokes, session.selectedStrokeIds.size),
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { session.copySelection(selectedPage) }) {
                        Icon(Icons.Default.ContentCopy, contentDescription = stringResource(R.string.copy_selection))
                    }
                    IconButton(onClick = { session.pasteSelection(selectedPage) }) {
                        Icon(Icons.Default.ContentPaste, contentDescription = stringResource(R.string.paste_selection))
                    }
                    IconButton(onClick = { session.deleteSelection(selectedPage) }) {
                        Icon(Icons.Default.Delete, contentDescription = stringResource(R.string.delete_selection))
                    }
                }
            }
            if (session.tool != EditorTool.TEXT && session.tool != EditorTool.LASSO) ToolOptions(session)
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp)) {
                EditorTool.values().forEach { t ->
                    val selected = session.tool == t
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { session.clearSelection(); session.tool = t }
                            .padding(vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier
                                .clip(CircleShape)
                                .background(if (selected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent)
                                .padding(horizontal = 14.dp, vertical = 4.dp)
                        ) { Icon(toolIcon(t), contentDescription = null) }
                        Text(
                            stringResource(toolLabel(t)),
                            style = MaterialTheme.typography.labelSmall,
                            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolOptions(session: EditorSession) {
    val tool = session.tool
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (tool == EditorTool.ERASER) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = !session.eraseWholeStrokes,
                    onClick = { session.eraseWholeStrokes = false },
                    label = { Text(stringResource(R.string.erase_partial)) }
                )
                FilterChip(
                    selected = session.eraseWholeStrokes,
                    onClick = { session.eraseWholeStrokes = true },
                    label = { Text(stringResource(R.string.erase_stroke)) }
                )
            }
        } else {
            val palette = if (tool == EditorTool.HIGHLIGHTER) HIGHLIGHT_PALETTE else INK_PALETTE
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                palette.forEach { c ->
                    val selected = session.colorOf(tool) == c.toArgb()
                    Box(
                        Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(c)
                            .border(
                                BorderStroke(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
                                CircleShape
                            )
                            .clickable { session.setColor(tool, c.toArgb()) }
                    )
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.thickness), style = MaterialTheme.typography.labelMedium)
            Slider(
                value = session.widthOf(tool),
                onValueChange = { session.setWidth(tool, it) },
                valueRange = when (tool) {
                    EditorTool.PEN -> 1f..12f
                    EditorTool.PENCIL -> 1f..10f
                    EditorTool.MARKER -> 3f..30f
                    EditorTool.HIGHLIGHTER -> 8f..40f
                    else -> 6f..40f
                },
                modifier = Modifier.weight(1f).padding(horizontal = 12.dp)
            )
            Text(stringResource(R.string.finger_draws), style = MaterialTheme.typography.labelMedium)
            Switch(
                checked = session.fingerDraws,
                onCheckedChange = { session.fingerDraws = it },
                modifier = Modifier.padding(start = 8.dp)
            )
        }
    }
}

// ---------------------------------------------------------------------------------------
// Page settings
// ---------------------------------------------------------------------------------------

@Composable
private fun PageSettingsDialog(session: EditorSession, pageId: String?, onDismiss: () -> Unit) {
    val first = session.pages.firstOrNull { it.id == pageId }?.entity
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.page_settings)) },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.done)) } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(
                    stringResource(R.string.page_style_scope),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                SettingsSection(R.string.template) {
                    listOf(
                        PageTemplate.BLANK to R.string.tpl_blank,
                        PageTemplate.RULED to R.string.tpl_ruled,
                        PageTemplate.GRID to R.string.tpl_grid,
                        PageTemplate.DOTS to R.string.tpl_dots,
                        PageTemplate.MUSIC to R.string.tpl_music,
                        PageTemplate.CORNELL to R.string.tpl_cornell,
                        PageTemplate.ISOMETRIC to R.string.tpl_isometric,
                        PageTemplate.PLANNER to R.string.tpl_planner
                    ).forEach { (key, label) ->
                        FilterChip(
                            selected = first?.template == key,
                            onClick = { pageId?.let { session.setTemplate(it, key) } },
                            label = { Text(stringResource(label)) }
                        )
                    }
                }
                SettingsSection(R.string.page_color) {
                    PAGE_COLORS.forEach { argb ->
                        val selected = first?.backgroundColorArgb == argb
                        Box(
                            Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(argb.toInt()))
                                .border(
                                    BorderStroke(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
                                    CircleShape
                                )
                                .clickable { pageId?.let { session.setBackground(it, argb) } }
                        )
                    }
                }
                SettingsSection(R.string.orientation) {
                    FilterChip(
                        selected = first?.orientation == PageOrientation.PORTRAIT,
                        onClick = { pageId?.let { session.setOrientation(it, PageOrientation.PORTRAIT) } },
                        label = { Text(stringResource(R.string.portrait)) }
                    )
                    FilterChip(
                        selected = first?.orientation == PageOrientation.LANDSCAPE,
                        onClick = { pageId?.let { session.setOrientation(it, PageOrientation.LANDSCAPE) } },
                        label = { Text(stringResource(R.string.landscape)) }
                    )
                }
                Text(
                    stringResource(R.string.orientation_note),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                SettingsSection(R.string.page_mode) {
                    FilterChip(
                        selected = session.pageMode == PageMode.INDIVIDUAL_PAGES,
                        onClick = { session.updatePageMode(PageMode.INDIVIDUAL_PAGES) },
                        label = { Text(stringResource(R.string.mode_pages)) }
                    )
                    FilterChip(
                        selected = session.pageMode == PageMode.INFINITE_SCROLLING,
                        onClick = { session.updatePageMode(PageMode.INFINITE_SCROLLING) },
                        label = { Text(stringResource(R.string.mode_infinite)) }
                    )
                }
            }
        }
    )
}

@Composable
private fun SettingsSection(titleRes: Int, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(stringResource(titleRes), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            content()
        }
    }
}


/**
 * Small, bounded-memory preview for image attachments. Decoding happens off the main
 * thread and uses a sampled bitmap so a multi-megapixel camera photo cannot exhaust
 * the editor's memory just to show a thumbnail.
 */
@Composable
private fun AttachmentImageThumbnail(file: java.io.File, description: String) {
    var showPreview by remember(file.absolutePath) { mutableStateOf(false) }
    val bitmap by produceState<androidx.compose.ui.graphics.ImageBitmap?>(
        initialValue = null,
        key1 = file.absolutePath,
        key2 = file.lastModified()
    ) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.absolutePath, bounds)
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@runCatching null

                var sample = 1
                val maxDimension = maxOf(bounds.outWidth, bounds.outHeight)
                while (maxDimension / sample > 512) sample *= 2

                val options = BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
                }
                BitmapFactory.decodeFile(file.absolutePath, options)?.asImageBitmap()
            }.getOrNull()
        }
    }

    if (bitmap != null) {
        androidx.compose.foundation.Image(
            bitmap = bitmap!!,
            contentDescription = description,
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(8.dp))
                .clickable { showPreview = true },
            contentScale = ContentScale.Crop
        )
    } else {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "▧",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.titleLarge
            )
        }
    }

    if (showPreview && bitmap != null) {
        Dialog(onDismissRequest = { showPreview = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    androidx.compose.foundation.Image(
                        bitmap = bitmap!!,
                        contentDescription = description,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(420.dp),
                        contentScale = ContentScale.Fit
                    )
                    Text(
                        description,
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    TextButton(onClick = { showPreview = false }) {
                        Text(stringResource(R.string.close))
                    }
                }
            }
        }
    }
}
