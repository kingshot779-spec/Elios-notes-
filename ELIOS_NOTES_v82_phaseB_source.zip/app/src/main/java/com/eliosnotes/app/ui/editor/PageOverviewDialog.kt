package com.eliosnotes.app.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import kotlinx.coroutines.launch
import com.eliosnotes.app.R
import com.eliosnotes.app.ink.InkPainter
import com.eliosnotes.app.ink.PageBackgrounds

/** Compact page navigator with explicit controls and long-press drag reordering. */
@Composable
fun PageOverviewDialog(
    pages: List<EditorPage>,
    activeIndex: Int,
    busy: Boolean,
    onDismiss: () -> Unit,
    onSelect: (Int) -> Unit,
    onMove: (Int, Int) -> Unit,
    onReorder: (List<String>) -> Unit,
    onDuplicate: (String) -> Unit
) {
    val sourceIds = pages.map { it.id }
    var orderedIds by remember(sourceIds) { mutableStateOf(sourceIds) }
    var draggingId by remember { mutableStateOf<String?>(null) }
    var dragCenterY by remember { mutableFloatStateOf(0f) }
    var orderChanged by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val pageById = pages.associateBy { it.id }
    val orderedPages = orderedIds.mapNotNull(pageById::get)
    val latestOrderedIds by rememberUpdatedState(orderedIds)

    AlertDialog(
        onDismissRequest = { if (!busy && draggingId == null) onDismiss() },
        title = { Text(stringResource(R.string.page_overview)) },
        text = {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxWidth().heightIn(max = 540.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(orderedPages, key = { _, page -> page.id }) { index, page ->
                    val originalIndex = pages.indexOfFirst { it.id == page.id }
                    Surface(
                        modifier = Modifier.fillMaxWidth().clickable(enabled = !busy && draggingId == null) {
                            onSelect(originalIndex)
                        },
                        shape = RoundedCornerShape(12.dp),
                        color = if (originalIndex == activeIndex) MaterialTheme.colorScheme.secondaryContainer
                            else MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            PageThumbnail(page, Modifier.width(62.dp).height(88.dp))
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(stringResource(R.string.page_number_label, index + 1), style = MaterialTheme.typography.titleSmall)
                                Text(
                                    stringResource(R.string.page_content_summary, page.strokes.size + page.lockedInkIds.size, page.attachments.size),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (page.text.isNotBlank()) {
                                    Text(
                                        page.text.replace('\n', ' ').take(48),
                                        style = MaterialTheme.typography.bodySmall,
                                        maxLines = 2
                                    )
                                } else if (page.strokes.isEmpty() && page.attachments.isEmpty()) {
                                    Text(stringResource(R.string.empty_page_label), style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.DragHandle,
                                    contentDescription = stringResource(R.string.drag_reorder_page),
                                    modifier = Modifier.size(36.dp).pointerInput(page.id, busy) {
                                        if (busy) return@pointerInput
                                        detectDragGesturesAfterLongPress(
                                            onDragStart = {
                                                val item = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.key == page.id }
                                                if (item != null) {
                                                    draggingId = page.id
                                                    dragCenterY = item.offset + item.size / 2f
                                                    orderChanged = false
                                                }
                                            },
                                            onDrag = { change, amount ->
                                                change.consume()
                                                if (draggingId != page.id) return@detectDragGesturesAfterLongPress
                                                dragCenterY += amount.y
                                                val info = listState.layoutInfo
                                                val target = info.visibleItemsInfo.firstOrNull { item ->
                                                    dragCenterY >= item.offset && dragCenterY < item.offset + item.size
                                                }
                                                val currentIds = latestOrderedIds
                                                val from = currentIds.indexOf(page.id)
                                                val to = target?.let { currentIds.indexOf(it.key as? String ?: "") } ?: -1
                                                if (from >= 0 && to >= 0 && from != to) {
                                                    val mutable = currentIds.toMutableList()
                                                    val moved = mutable.removeAt(from)
                                                    mutable.add(to, moved)
                                                    orderedIds = mutable
                                                    orderChanged = true
                                                }
                                                val edge = with(density) { 44.dp.toPx() }
                                                if (dragCenterY < info.viewportStartOffset + edge) {
                                                    scope.launch { listState.scrollBy(-edge / 3f) }
                                                } else if (dragCenterY > info.viewportEndOffset - edge) {
                                                    scope.launch { listState.scrollBy(edge / 3f) }
                                                }
                                            },
                                            onDragEnd = {
                                                draggingId = null
                                                if (orderChanged) onReorder(latestOrderedIds)
                                            },
                                            onDragCancel = { draggingId = null; orderedIds = sourceIds; orderChanged = false }
                                        )
                                    }
                                )
                                IconButton(enabled = !busy && draggingId == null && index > 0, onClick = { onMove(originalIndex, -1) }, modifier = Modifier.size(36.dp)) {
                                    Icon(Icons.Default.ArrowUpward, contentDescription = stringResource(R.string.move_page_up))
                                }
                                IconButton(enabled = !busy && draggingId == null && index < orderedPages.lastIndex, onClick = { onMove(originalIndex, 1) }, modifier = Modifier.size(36.dp)) {
                                    Icon(Icons.Default.ArrowDownward, contentDescription = stringResource(R.string.move_page_down))
                                }
                                IconButton(enabled = !busy && draggingId == null, onClick = { onDuplicate(page.id) }, modifier = Modifier.size(36.dp)) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = stringResource(R.string.duplicate_page))
                                }
                            }
                        }
                    }
                }
                if (busy) {
                    item(key = "page-operation-progress") {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy && draggingId == null, onClick = onDismiss) { Text(stringResource(R.string.done)) }
        }
    )
}

@Composable
private fun PageThumbnail(page: EditorPage, modifier: Modifier = Modifier) {
    val painter = androidx.compose.runtime.remember { InkPainter() }
    Box(modifier.clip(RoundedCornerShape(4.dp)).background(MaterialTheme.colorScheme.surface)) {
        Canvas(Modifier.fillMaxWidth().height(88.dp)) {
            val pageWidth = page.entity.widthDp.coerceAtLeast(1f)
            val pageHeight = page.entity.heightDp.coerceAtLeast(1f)
            val scale = minOf(size.width / pageWidth, size.height / pageHeight)
            drawIntoCanvas { canvas ->
                val native = canvas.nativeCanvas
                native.save()
                native.scale(scale, scale)
                PageBackgrounds.draw(
                    native,
                    page.entity.template,
                    page.entity.backgroundColorArgb.toInt(),
                    pageWidth,
                    pageHeight
                )
                page.strokes.forEach { stroke -> painter.draw(native, stroke) }
                native.restore()
            }
        }
    }
}
