package com.eliosnotes.app.recognition

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognition
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognitionModel
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognitionModelIdentifier
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognizerOptions
import com.google.mlkit.vision.digitalink.recognition.Ink as MlInk
import com.google.mlkit.vision.digitalink.recognition.RecognitionContext
import com.google.mlkit.vision.digitalink.recognition.WritingArea
import com.google.android.gms.tasks.Task
import com.eliosnotes.app.data.document.PageSize
import com.eliosnotes.app.ink.Stroke
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs
import kotlin.math.max

/**
 * On-device recognition for strokes already stored by ELIOS NOTES.
 *
 * Arabic and English model packs are fetched over Wi-Fi only on first use. After the packs
 * are present, recognition itself runs locally. The source strokes are never modified.
 */
object HandwritingRecognition {

    suspend fun recognizeArabicAndEnglish(
        strokes: List<Stroke>,
        language: RecognitionLanguage = RecognitionLanguage.AUTO
    ): String = withContext(Dispatchers.IO) {
        require(strokes.isNotEmpty()) { "No handwriting on this page" }

        val manager = RemoteModelManager.getInstance()
        var arabicRecognizer: com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognizer? = null
        var englishRecognizer: com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognizer? = null
        try {
            if (language != RecognitionLanguage.ENGLISH) {
                val model = buildModel("ar")
                ensureModel(manager, model)
                arabicRecognizer = DigitalInkRecognition.getClient(DigitalInkRecognizerOptions.builder(model).build())
            }
            if (language != RecognitionLanguage.ARABIC) {
                val model = buildModel("en-US")
                ensureModel(manager, model)
                englishRecognizer = DigitalInkRecognition.getClient(DigitalInkRecognizerOptions.builder(model).build())
            }
            groupIntoLines(strokes).mapNotNull { line ->
                val inkAndContext = buildInk(line) ?: return@mapNotNull null
                val (ink, recognitionContext) = inkAndContext
                val ar = arabicRecognizer?.recognize(ink, recognitionContext)
                    ?.awaitTask()?.candidates?.firstOrNull()?.text.orEmpty()
                val en = englishRecognizer?.recognize(ink, recognitionContext)
                    ?.awaitTask()?.candidates?.firstOrNull()?.text.orEmpty()
                val selected = RecognitionHeuristics.selectCandidate(ar, en, language)
                selected.trim().takeIf { it.isNotEmpty() }
            }.joinToString("\n")
        } finally {
            arabicRecognizer?.close()
            englishRecognizer?.close()
        }
    }

    private fun buildModel(languageTag: String): DigitalInkRecognitionModel {
        val identifier = DigitalInkRecognitionModelIdentifier.fromLanguageTag(languageTag)
            ?: throw IllegalArgumentException("Unsupported handwriting language: $languageTag")
        return DigitalInkRecognitionModel.builder(identifier).build()
    }

    private suspend fun ensureModel(
        manager: RemoteModelManager,
        model: DigitalInkRecognitionModel
    ) {
        if (manager.isModelDownloaded(model).awaitTask()) return
        manager.download(model, DownloadConditions.Builder().requireWifi().build()).awaitTask()
    }

    /**
     * Cluster strokes by their vertical centre, preserving original stroke order within each
     * line. The page's 32-unit ruled baseline is used as a conservative clustering scale.
     */
    private fun groupIntoLines(strokes: List<Stroke>): List<List<Stroke>> {
        data class Entry(val index: Int, val stroke: Stroke, val centerY: Float)
        data class Cluster(val entries: MutableList<Entry>, var centerY: Float)

        val entries = strokes.mapIndexedNotNull { index, stroke ->
            if (stroke.points.isEmpty()) null
            else {
                val b = stroke.bounds
                Entry(index, stroke, (b[1] + b[3]) / 2f)
            }
        }.sortedBy { it.centerY }

        val clusters = mutableListOf<Cluster>()
        val threshold = max(18f, PageSize.LINE_HEIGHT * 0.68f)
        for (entry in entries) {
            val nearest = clusters.minByOrNull { abs(it.centerY - entry.centerY) }
            if (nearest != null && abs(nearest.centerY - entry.centerY) <= threshold) {
                nearest.entries.add(entry)
                nearest.centerY = nearest.entries.map { it.centerY }.average().toFloat()
            } else {
                clusters.add(Cluster(mutableListOf(entry), entry.centerY))
            }
        }
        return clusters.sortedBy { it.centerY }
            .map { cluster -> cluster.entries.sortedBy { it.index }.map { it.stroke } }
    }

    private fun buildInk(line: List<Stroke>): Pair<MlInk, RecognitionContext>? {
        val points = line.flatMap { it.points }
        if (points.isEmpty()) return null
        val minX = points.minOf { it.x }
        val minY = points.minOf { it.y }
        val maxX = points.maxOf { it.x }
        val maxY = points.maxOf { it.y }

        val inkBuilder = MlInk.builder()
        line.forEach { sourceStroke ->
            if (sourceStroke.points.isNotEmpty()) {
                val strokeBuilder = MlInk.Stroke.builder()
                sourceStroke.points.forEach { p ->
                    // ELIOS v1 strokes did not persist timestamps; ML Kit supports untimed points.
                    strokeBuilder.addPoint(MlInk.Point.create(p.x - minX, p.y - minY))
                }
                inkBuilder.addStroke(strokeBuilder.build())
            }
        }
        val ink = inkBuilder.build()
        val writingWidth = max(64f, maxX - minX + 32f)
        val writingHeight = max(24f, maxY - minY + 16f)
        val context = RecognitionContext.builder()
            .setWritingArea(WritingArea(writingWidth, writingHeight))
            .build()
        return ink to context
    }

    internal fun chooseScriptCandidate(arabic: String, english: String): String =
        RecognitionHeuristics.chooseScriptCandidate(arabic, english)

    private suspend fun <T> Task<T>.awaitTask(): T =
        suspendCancellableCoroutine { continuation ->
            addOnSuccessListener { result ->
                if (continuation.isActive) continuation.resume(result)
            }
            addOnFailureListener { error ->
                if (continuation.isActive) continuation.resumeWithException(error)
            }
            addOnCanceledListener {
                if (continuation.isActive) continuation.cancel()
            }
        }
}
