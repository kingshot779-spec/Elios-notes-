package com.eliosnotes.app.data.document

/**
 * Pure ordering rules for a note's pages. Page identity and all page content fields are preserved;
 * only pageIndex is normalized when the order changes.
 */
object PageOrderPolicy {
    fun normalize(pages: List<NotePageEntity>): List<NotePageEntity> =
        pages.mapIndexed { index, page ->
            if (page.pageIndex == index) page else page.copy(pageIndex = index)
        }

    fun insert(
        pages: List<NotePageEntity>,
        page: NotePageEntity,
        requestedIndex: Int
    ): List<NotePageEntity> {
        require(pages.none { it.id == page.id }) { "Page id already exists in this note" }
        val result = pages.toMutableList()
        result.add(requestedIndex.coerceIn(0, result.size), page)
        return normalize(result)
    }

    fun move(pages: List<NotePageEntity>, fromIndex: Int, toIndex: Int): List<NotePageEntity> {
        if (fromIndex !in pages.indices || toIndex !in pages.indices || fromIndex == toIndex) {
            return normalize(pages)
        }
        val result = pages.toMutableList()
        val page = result.removeAt(fromIndex)
        result.add(toIndex, page)
        return normalize(result)
    }

    fun reorderByIds(pages: List<NotePageEntity>, orderedIds: List<String>): List<NotePageEntity> {
        require(orderedIds.size == pages.size) { "Page order must contain every page exactly once" }
        require(orderedIds.toSet().size == orderedIds.size) { "Page order contains duplicate ids" }
        val byId = pages.associateBy { it.id }
        require(orderedIds.all { it in byId }) { "Page order contains an unknown id" }
        return normalize(orderedIds.map { byId.getValue(it) })
    }
}
