package com.eliosnotes.app.recognition

enum class RecognitionLanguage { AUTO, ARABIC, ENGLISH }

/** Pure, deterministic helpers kept separate so language selection can be regression-tested. */
internal object RecognitionHeuristics {
    private data class ScriptScore(
        val targetLetters: Int,
        val otherLetters: Int
    ) {
        val totalLetters: Int get() = targetLetters + otherLetters
        val targetRatio: Double get() =
            if (totalLetters == 0) 0.0 else targetLetters.toDouble() / totalLetters
    }

    /**
     * Compare scripts using Unicode script properties rather than narrow block ranges.
     * This includes Arabic Supplement/Extended and Latin Extended letters, and correctly
     * handles supplementary code points. Combining marks and punctuation do not skew the score.
     *
     * Cross-model confidence is intentionally not compared: ML Kit scores are optional and are
     * intended for candidate filtering, not documented as calibrated across language models.
     */
    fun selectCandidate(
        arabic: String,
        english: String,
        language: RecognitionLanguage
    ): String = when (language) {
        RecognitionLanguage.ARABIC -> arabic
        RecognitionLanguage.ENGLISH -> english
        RecognitionLanguage.AUTO -> chooseScriptCandidate(arabic, english)
    }

    fun chooseScriptCandidate(arabic: String, english: String): String {
        if (arabic.isBlank()) return english
        if (english.isBlank()) return arabic

        val arScore = score(arabic, Character.UnicodeScript.ARABIC)
        val enScore = score(english, Character.UnicodeScript.LATIN)

        return when {
            arScore.targetLetters == 0 && enScore.targetLetters > 0 -> english
            enScore.targetLetters == 0 && arScore.targetLetters > 0 -> arabic
            arScore.targetRatio > enScore.targetRatio -> arabic
            enScore.targetRatio > arScore.targetRatio -> english
            // No comparable confidence score is exposed by every language model. Do not let a
            // longer candidate win solely because it contains more characters.
            else -> arabic
        }
    }

    private fun score(text: String, targetScript: Character.UnicodeScript): ScriptScore {
        var target = 0
        var other = 0
        var index = 0
        while (index < text.length) {
            val codePoint = text.codePointAt(index)
            if (Character.isLetter(codePoint)) {
                if (Character.UnicodeScript.of(codePoint) == targetScript) target++ else other++
            }
            index += Character.charCount(codePoint)
        }
        return ScriptScore(target, other)
    }
}
