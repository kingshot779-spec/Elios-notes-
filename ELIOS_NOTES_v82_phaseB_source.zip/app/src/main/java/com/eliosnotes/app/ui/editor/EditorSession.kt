package com.eliosnotes.app.ui.editor

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.eliosnotes.app.data.AppScope
import com.eliosnotes.app.data.NotesRepository
import com.eliosnotes.app.data.SaveQueue
import com.eliosnotes.app.data.document.PageOrderPolicy
import com.eliosnotes.app.data.document.PagePresentationPolicy
import com.eliosnotes.app.data.document.NotePageEntity
import com.eliosnotes.app.data.document.PageContent
import com.eliosnotes.app.data.document.PageAttachment
import java.io.InputStream
import com.eliosnotes.app.data.document.PageMode
import com.eliosnotes.app.data.document.PageOrientation
import com.eliosnotes.app.ink.InkPoint
import com.eliosnotes.app.ink.InkBeautifier
import com.eliosnotes.app.ink.InkBeautificationLevel
import com.eliosnotes.app.ink.LassoGeometry
import com.eliosnotes.app.ink.InkTool
import com.eliosnotes.app.ink.Stroke
import com.eliosnotes.app.ink.StrokeClipboard
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

enum class EditorTool {
    PEN, PENCIL, MARKER, HIGHLIGHTER, ERASER, TEXT, LASSO;

    val inkTool: InkTool?
        get() = when (this) {
            PEN -> InkTool.PEN
            PENCIL -> InkTool.PENCIL
            MARKER -> InkTool.MARKER
            HIGHLIGHTER -> InkTool.HIGHLIGHTER
            else -> null
        }
}

enum class LoadStatus { LOADING, READY, MISSING }

/** Live, observable state of one page. [strokes] is replaced (never mutated) on every edit. */
class EditorPage(
    initial: NotePageEntity,
    initialText: String,
    initialStrokes: List<Stroke>,
    /** Stored text is unreadable: show the page but never overwrite that text. */
    val textLocked: Boolean = false,
    /** Ink elements that could not be decoded; autosave leaves them untouched. */
    val lockedInkIds: Set<String> = emptySet(),
    initialAttachments: List<PageAttachment> = emptyList()
) {
    val id: String = initial.id
    var entity by mutableStateOf(initial)
    var text by mutableStateOf(initialText)
    var strokes by mutableStateOf(initialStrokes)
    var attachments by mutableStateOf(initialAttachments)
    val isEmpty: Boolean get() = strokes.isEmpty() && text.isBlank() && attachments.isEmpty()
}

/**
 * Holds the open note: pages, tool state, undo/redo and debounced autosave.
 * All persistence goes through [SaveQueue], so closing the editor never loses pending edits.
 */
class EditorSession(
    private val repo: NotesRepository,
    val noteId: String,
    private val scope: CoroutineScope
) {
    var status by mutableStateOf(LoadStatus.LOADING)
        private set
    var title by mutableStateOf("")
        private set
    var isFavorite by mutableStateOf(false)
        private set
    var pageMode by mutableStateOf(PageMode.INDIVIDUAL_PAGES)
        private set
    val pages = mutableStateListOf<EditorPage>()

    // ---- tool state -------------------------------------------------------------------
    var tool by mutableStateOf(EditorTool.PEN)
    var fingerDraws by mutableStateOf(true)
    var eraseWholeStrokes by mutableStateOf(false)
    private val toolColors = mutableStateMapOf(
        EditorTool.PEN to INK_BLACK,
        EditorTool.PENCIL to Color(0xFF455A64).toArgb(),
        EditorTool.MARKER to Color(0xFF1E4FA3).toArgb(),
        EditorTool.HIGHLIGHTER to Color(0xFFFFEB3B).toArgb()
    )
    private val toolWidths = mutableStateMapOf(
        EditorTool.PEN to 3f,
        EditorTool.PENCIL to 2.5f,
        EditorTool.MARKER to 8f,
        EditorTool.HIGHLIGHTER to 18f,
        EditorTool.ERASER to 14f
    )

    fun colorOf(t: EditorTool): Int = toolColors[t] ?: INK_BLACK
    fun setColor(t: EditorTool, argb: Int) { toolColors[t] = argb }
    fun widthOf(t: EditorTool): Float = toolWidths[t] ?: 3f
    fun setWidth(t: EditorTool, w: Float) { toolWidths[t] = w }

    // ---- lasso selection ----------------------------------------------------------------
    var selectedStrokeIds by mutableStateOf<Set<String>>(emptySet())
        private set
    var selectedPageId by mutableStateOf<String?>(null)
        private set
    private val strokeClipboard = StrokeClipboard()

    /** Copy the current lasso selection into an in-memory clipboard. */
    fun copySelection(page: EditorPage) {
        if (selectedPageId != page.id || selectedStrokeIds.isEmpty()) return
        strokeClipboard.copy(page.strokes, selectedStrokeIds)
    }

    /** Delete the current lasso selection as one undoable edit. */
    fun deleteSelection(page: EditorPage) {
        if (selectedPageId != page.id || selectedStrokeIds.isEmpty()) return
        val before = page.strokes
        val after = before.filterNot { it.id in selectedStrokeIds }
        if (after.size != before.size) {
            page.strokes = after
            pushEdit(Edit(page.id, before, after))
        }
        clearSelection()
    }

    /** Paste a fresh, independently editable copy slightly offset from the source. */
    fun pasteSelection(page: EditorPage) {
        if (strokeClipboard.isEmpty) return
        val before = page.strokes
        val pasted = strokeClipboard.paste()
        val after = before + pasted
        page.strokes = after
        pushEdit(Edit(page.id, before, after))
        selectedPageId = page.id
        selectedStrokeIds = pasted.map { it.id }.toSet()
    }

    fun selectWithLasso(page: EditorPage, polygon: List<InkPoint>) {
        selectedStrokeIds = LassoGeometry.select(page.strokes, polygon)
        selectedPageId = if (selectedStrokeIds.isEmpty()) null else page.id
    }

    fun clearSelection() {
        selectedStrokeIds = emptySet()
        selectedPageId = null
    }

    fun moveSelection(page: EditorPage, dx: Float, dy: Float) {
        val ids = selectedStrokeIds
        if (selectedPageId != page.id || ids.isEmpty() || (dx == 0f && dy == 0f)) return
        val before = page.strokes
        val after = LassoGeometry.translate(before, ids, dx, dy)
        if (after !== before) {
            page.strokes = after
            pushEdit(Edit(page.id, before, after))
        }
    }

    // ---- undo / redo ------------------------------------------------------------------
    private class Edit(val pageId: String, val before: List<Stroke>, val after: List<Stroke>)

    private val undoStack = ArrayDeque<Edit>()
    private val redoStack = ArrayDeque<Edit>()
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set

    private fun refreshUndoFlags() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }

    private fun pushEdit(edit: Edit) {
        undoStack.addLast(edit)
        if (undoStack.size > MAX_UNDO) undoStack.removeFirst()
        redoStack.clear()
        refreshUndoFlags()
        markDirty(edit.pageId)
    }

    fun undo() {
        clearSelection()
        while (undoStack.isNotEmpty()) {
            val edit = undoStack.removeLast()
            val page = pages.firstOrNull { it.id == edit.pageId } ?: continue
            page.strokes = edit.before
            redoStack.addLast(edit)
            markDirty(page.id)
            break
        }
        refreshUndoFlags()
    }

    fun redo() {
        clearSelection()
        while (redoStack.isNotEmpty()) {
            val edit = redoStack.removeLast()
            val page = pages.firstOrNull { it.id == edit.pageId } ?: continue
            page.strokes = edit.after
            undoStack.addLast(edit)
            markDirty(page.id)
            break
        }
        refreshUndoFlags()
    }

    // ---- ink edits (called by the page canvas) ----------------------------------------
    fun createStroke(points: List<InkPoint>): Stroke? {
        val ink = tool.inkTool ?: return null
        return Stroke(UUID.randomUUID().toString(), ink, colorOf(tool), widthOf(tool), points)
    }

    fun addStroke(page: EditorPage, stroke: Stroke) {
        val before = page.strokes
        val after = before + stroke
        page.strokes = after
        pushEdit(Edit(page.id, before, after))
    }

    /** Applies a reviewed beautification result as one normal, undoable ink edit. */
    fun applyBeautification(page: EditorPage, level: InkBeautificationLevel): Boolean {
        val before = page.strokes
        val after = InkBeautifier.beautify(before, level)
        if (after === before || after == before) return false
        page.strokes = after
        clearSelection()
        pushEdit(Edit(page.id, before, after))
        return true
    }

    /** The canvas edits [EditorPage.strokes] live while erasing; this records the whole gesture as one undo step. */
    fun finishErase(page: EditorPage, before: List<Stroke>) {
        val after = page.strokes
        if (after !== before) pushEdit(Edit(page.id, before, after))
    }

    fun onTextChange(page: EditorPage, text: String) {
        if (page.textLocked) return
        page.text = text
        markDirty(page.id)
    }

    suspend fun addAttachment(pageId: String, input: InputStream, displayName: String, mimeType: String) {
        val page = pages.firstOrNull { it.id == pageId } ?: return
        withContext(Dispatchers.IO) {
            repo.addAttachment(pageId, input, displayName, mimeType)
        }
        val refreshed = repo.loadDocument(noteId)?.pages?.firstOrNull { it.page.id == pageId }
        if (refreshed != null) page.attachments = refreshed.attachments
    }

    fun attachmentFile(ref: com.eliosnotes.app.data.media.StoredAttachment): java.io.File = repo.attachmentFile(ref)

    suspend fun verifyAttachment(ref: com.eliosnotes.app.data.media.StoredAttachment): Boolean =
        withContext(Dispatchers.IO) { repo.verifyAttachment(ref) }

    suspend fun removeAttachment(pageId: String, elementId: String): Boolean {
        val removed = repo.removeAttachment(elementId)
        if (removed) pages.firstOrNull { it.id == pageId }?.let { page ->
            // Reload the page's persisted references so only the selected item disappears.
            val refreshed = repo.loadDocument(noteId)?.pages?.firstOrNull { it.page.id == pageId }
            if (refreshed != null) page.attachments = refreshed.attachments
        }
        return removed
    }

    fun onTitleChange(value: String) {
        title = value
        titleDirty = true
        scheduleSave()
    }

    // ---- loading ----------------------------------------------------------------------
    suspend fun load() {
        val doc = SaveQueue.run { repo.loadDocument(noteId) }
        if (doc == null) {
            status = LoadStatus.MISSING
            return
        }
        title = doc.note.title
        isFavorite = doc.note.isFavorite
        pageMode = doc.note.pageMode
        pages.clear()
        doc.pages.forEach { pages.add(EditorPage(it.page, it.text, it.strokes, it.textLocked, it.lockedInkIds, it.attachments)) }
        status = LoadStatus.READY
    }

    // ---- autosave ---------------------------------------------------------------------
    private val dirtyPages = LinkedHashSet<String>()
    private var titleDirty = false
    private var saveJob: Job? = null

    private fun markDirty(pageId: String) {
        dirtyPages.add(pageId)
        scheduleSave()
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = scope.launch {
            delay(SAVE_DEBOUNCE_MS)
            flush()
        }
    }

    /** True when the latest edits could not be written even after retrying. */
    var saveFailed by mutableStateOf(false)
        private set

    private class PageSnapshot(
        val id: String,
        val seq: Long,
        val text: String,
        val strokes: List<Stroke>,
        val writeText: Boolean,
        val protectedInk: Set<String>
    )

    private val seqCounter = AtomicLong(0)
    private val latestPageSeq = ConcurrentHashMap<String, Long>()
    private val latestTitleSeq = AtomicLong(0)

    private data class PendingSave(
        val pages: List<PageSnapshot>,
        val title: String?,
        val titleSeq: Long
    )

    private fun takePendingSave(): PendingSave {
        val snapshots = dirtyPages.mapNotNull { id ->
            pages.firstOrNull { it.id == id }?.let { p ->
                val seq = seqCounter.incrementAndGet()
                latestPageSeq[p.id] = seq
                PageSnapshot(p.id, seq, p.text, p.strokes, !p.textLocked, p.lockedInkIds)
            }
        }
        dirtyPages.clear()
        var titleSeq = 0L
        val pendingTitle = if (titleDirty) title else null
        if (pendingTitle != null) {
            titleSeq = seqCounter.incrementAndGet()
            latestTitleSeq.set(titleSeq)
        }
        titleDirty = false
        return PendingSave(snapshots, pendingTitle, titleSeq)
    }

    /** Snapshots everything unsaved and queues it. Safe to call at any time and from onStop. */
    fun flush() {
        val pending = takePendingSave()
        if (pending.pages.isEmpty() && pending.title == null) return
        enqueueSave(pending.pages, pending.title, pending.titleSeq, 0)
    }

    /**
     * Persists pending edits and waits for the database queue to finish. Use before leaving the
     * editor or performing destructive note actions; a failed write keeps the editor open.
     */
    suspend fun flushAndAwait(): Boolean {
        saveJob?.cancel()
        saveJob = null
        // A prior debounce may already have moved dirty flags into the asynchronous queue.
        // Re-snapshot the complete current document so this awaited write supersedes any stale
        // queued snapshots and forms a real persistence barrier before navigation.
        pages.forEach { dirtyPages.add(it.id) }
        titleDirty = true
        val pending = takePendingSave()
        return try {
            SaveQueue.run {
                if (pending.title != null && latestTitleSeq.get() == pending.titleSeq) {
                    repo.saveTitle(noteId, pending.title)
                }
                for (snapshot in pending.pages) {
                    if (latestPageSeq[snapshot.id] == snapshot.seq) {
                        repo.savePage(
                            noteId, snapshot.id, snapshot.text, snapshot.strokes,
                            snapshot.writeText, snapshot.protectedInk
                        )
                    }
                }
            }
            saveFailed = false
            true
        } catch (failure: Throwable) {
            // Keep the pending work recoverable even if the UI coroutine is cancelled while
            // waiting (for example, during a configuration change).
            pending.pages.forEach { dirtyPages.add(it.id) }
            if (pending.title != null) titleDirty = true
            if (failure is CancellationException) throw failure
            saveFailed = true
            false
        }
    }

    /**
     * Writes the snapshots in order. On failure it retries a few times; a retried snapshot is
     * skipped if a newer one for the same page was queued meanwhile, so old data can never
     * overwrite newer data.
     */
    private fun enqueueSave(snaps: List<PageSnapshot>, title: String?, titleSeq: Long, attempt: Int) {
        SaveQueue.submit(onError = {
            if (attempt < MAX_SAVE_ATTEMPTS) {
                AppScope.launch {
                    delay(1500L * (attempt + 1))
                    enqueueSave(snaps, title, titleSeq, attempt + 1)
                }
            } else {
                saveFailed = true
            }
        }) {
            if (title != null && latestTitleSeq.get() == titleSeq) repo.saveTitle(noteId, title)
            for (s in snaps) {
                if (latestPageSeq[s.id] == s.seq) {
                    repo.savePage(noteId, s.id, s.text, s.strokes, s.writeText, s.protectedInk)
                }
            }
            saveFailed = false
        }
    }

    /** Re-queue a complete safe snapshot after a visible save failure. */
    fun retrySave() {
        if (!saveFailed) return
        pages.forEach { dirtyPages.add(it.id) }
        titleDirty = true
        saveFailed = false
        scheduleSave()
    }

    fun close() {
        saveJob?.cancel()
        flush()
    }

    // ---- page / note operations -------------------------------------------------------
    fun toggleFavorite() {
        isFavorite = !isFavorite
        val value = isFavorite
        SaveQueue.submit { repo.noteDao.setFavorite(noteId, value) }
    }

    suspend fun moveToTrash(): Boolean {
        if (!flushAndAwait()) return false
        return runCatching {
            SaveQueue.run { repo.noteDao.moveToTrash(noteId, System.currentTimeMillis()) }
            true
        }.getOrDefault(false)
    }

    fun addPage() = insertPageAt(pages.size)

    /** Inserts a blank page at a stable position while preserving every existing page identity. */
    fun insertPageAt(requestedIndex: Int) {
        val reference = pages.getOrNull(requestedIndex) ?: pages.lastOrNull() ?: return
        val now = System.currentTimeMillis()
        val page = reference.entity.copy(
            id = UUID.randomUUID().toString(),
            pageIndex = requestedIndex.coerceIn(0, pages.size),
            createdAt = now,
            updatedAt = now
        )
        val insertionIndex = page.pageIndex
        pages.add(insertionIndex, EditorPage(page, "", emptyList()))
        pages.forEachIndexed { index, item ->
            if (item.entity.pageIndex != index) item.entity = item.entity.copy(pageIndex = index, updatedAt = now)
        }
        SaveQueue.submit { repo.insertPageAt(noteId, page, insertionIndex) }
    }

    /**
     * Persists all current edits before cloning, then reloads the document snapshot so the new page
     * includes text, decoded and protected ink, attachments, and future element payloads.
     */
    suspend fun duplicatePage(pageId: String): String? {
        if (!flushAndAwait()) return null
        return try {
            val result = SaveQueue.run {
                val duplicatedId = repo.duplicatePage(noteId, pageId)
                val document = repo.loadDocument(noteId)
                    ?: throw IllegalStateException("Note disappeared after page duplication")
                duplicatedId to document
            }
            val (duplicatedId, document) = result
            pages.clear()
            document.pages.forEach { content ->
                pages.add(EditorPage(
                    content.page, content.text, content.strokes,
                    content.textLocked, content.lockedInkIds, content.attachments
                ))
            }
            // Existing undo/redo entries remain valid because original page IDs are unchanged.
            clearSelection()
            duplicatedId
        } catch (failure: Exception) {
            if (failure is CancellationException) throw failure
            null
        }
    }

    /**
     * Persists a complete page order before updating observable editor state. Invalid orders and
     * failed writes leave the in-memory order unchanged; pending page edits are flushed first.
     */
    suspend fun reorderPages(orderedIds: List<String>): Boolean {
        if (orderedIds.size != pages.size || orderedIds.toSet().size != orderedIds.size) return false
        val reordered = runCatching {
            PageOrderPolicy.reorderByIds(pages.map { it.entity }, orderedIds)
        }.getOrNull() ?: return false
        if (!flushAndAwait()) return false
        try {
            SaveQueue.run { repo.reorderPages(noteId, orderedIds) }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            return false
        }
        val byId = pages.associateBy { it.id }
        val orderedPages = orderedIds.map { byId[it] ?: return false }
        orderedPages.forEachIndexed { index, page ->
            // Match the exact normalized Room row; reordering does not fabricate edit timestamps.
            page.entity = reordered[index]
        }
        pages.clear()
        pages.addAll(orderedPages)
        return true
    }

    /** Moves a page by one position using the same save barrier and atomic persistence path. */
    suspend fun movePage(page: EditorPage, direction: Int): Boolean {
        if (direction == 0) return false
        val from = pages.indexOfFirst { it.id == page.id }
        val to = from + direction.coerceIn(-1, 1)
        if (from !in pages.indices || to !in pages.indices) return false
        val ids = pages.map { it.id }.toMutableList()
        val moved = ids.removeAt(from)
        ids.add(to, moved)
        return reorderPages(ids)
    }

    fun deletePage(page: EditorPage) {
        undoStack.removeAll { it.pageId == page.id }
        redoStack.removeAll { it.pageId == page.id }
        refreshUndoFlags()
        dirtyPages.remove(page.id)
        if (pages.size == 1) {
            // A note always keeps one page: deleting the only page clears it instead.
            page.text = ""
            page.strokes = emptyList()
            markDirty(page.id)
            return
        }
        pages.remove(page)
        pages.forEachIndexed { i, p -> if (p.entity.pageIndex != i) p.entity = p.entity.copy(pageIndex = i) }
        val remaining = pages.map { it.entity }
        SaveQueue.submit { repo.deletePage(noteId, page.id, remaining) }
    }

    /** Page presentation is scoped to the selected page; sibling pages keep their own paper. */
    fun setTemplate(pageId: String, template: String): Boolean {
        val page = pages.firstOrNull { it.id == pageId } ?: return false
        val updated = PagePresentationPolicy.withTemplate(page.entity, template, System.currentTimeMillis()) ?: return false
        page.entity = updated
        persistPages()
        return true
    }

    fun setBackground(pageId: String, argb: Long): Boolean {
        val page = pages.firstOrNull { it.id == pageId } ?: return false
        page.entity = PagePresentationPolicy.withBackground(page.entity, argb, System.currentTimeMillis())
        persistPages()
        return true
    }

    /** Orientation applies to the selected empty page only, so existing content is never clipped. */
    fun setOrientation(pageId: String, orientation: String): Boolean {
        val page = pages.firstOrNull { it.id == pageId } ?: return false
        val updated = PagePresentationPolicy.withOrientation(
            page.entity, orientation, page.isEmpty, System.currentTimeMillis()
        ) ?: return false
        page.entity = updated
        persistPages()
        return true
    }

    fun updatePageMode(mode: String) {
        pageMode = mode
        SaveQueue.submit { repo.setPageMode(noteId, mode) }
    }

    private fun persistPages() {
        val entities = pages.map { it.entity }
        SaveQueue.submit { repo.updatePages(entities) }
    }

    fun snapshot(): List<PageContent> = pages.map { PageContent(it.entity, it.text, it.strokes, it.textLocked, it.lockedInkIds, it.attachments) }

    companion object {
        const val SAVE_DEBOUNCE_MS = 700L
        const val MAX_UNDO = 200
        const val MAX_SAVE_ATTEMPTS = 3
        val INK_BLACK: Int = Color(0xFF1B1F23).toArgb()
    }
}
