package com.eliosnotes.app.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.eliosnotes.app.data.media.AttachmentStorage
import java.io.File
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Migrates databases that were created by older schema versions through the exact
 * [NotesDatabase.ALL_MIGRATIONS] that ship in the app.
 *
 * Historical databases are rebuilt here from raw DDL (no Room-exported schema JSON exists for
 * versions 1-3, so `MigrationTestHelper` cannot be used for them). The DDL is reconstructed from
 * the entity history and the migration code. Room itself validates the migrated schema against
 * the current entities the first time the database is opened, so a mismatch fails the test.
 *
 * Every assertion is about user data surviving: nothing may be dropped, rewritten or reset.
 */
@RunWith(AndroidJUnit4::class)
class NotesDatabaseMigrationTest {
    private lateinit var context: Context
    private val dbName = "migration-test.db"

    @Before
    fun setUp() {
        context = InstrumentationRegistry.getInstrumentation().targetContext
        context.deleteDatabase(dbName)
    }

    @After
    fun tearDown() {
        context.deleteDatabase(dbName)
        context.deleteDatabase("fresh-$dbName")
    }

    // ---- historical schemas ---------------------------------------------------------------

    private val v1Notes = """CREATE TABLE IF NOT EXISTS `notes` (
        `id` TEXT NOT NULL, `title` TEXT NOT NULL, `body` TEXT NOT NULL,
        `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`id`))"""

    private val v2Columns = listOf(
        "isPinned INTEGER NOT NULL DEFAULT 0",
        "isArchived INTEGER NOT NULL DEFAULT 0",
        "isFavorite INTEGER NOT NULL DEFAULT 0",
        "pageMode TEXT NOT NULL DEFAULT 'PAGED'"
    )

    private val pagesDdl = """CREATE TABLE IF NOT EXISTS `note_pages` (
        `id` TEXT NOT NULL, `noteId` TEXT NOT NULL, `pageIndex` INTEGER NOT NULL,
        `widthDp` REAL NOT NULL, `heightDp` REAL NOT NULL, `orientation` TEXT NOT NULL,
        `template` TEXT NOT NULL, `backgroundColorArgb` INTEGER NOT NULL,
        `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`id`),
        FOREIGN KEY(`noteId`) REFERENCES `notes`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE)"""

    private val elementsDdl = """CREATE TABLE IF NOT EXISTS `note_elements` (
        `id` TEXT NOT NULL, `pageId` TEXT NOT NULL, `elementType` TEXT NOT NULL,
        `payloadVersion` INTEGER NOT NULL, `payloadJson` TEXT NOT NULL,
        `x` REAL NOT NULL, `y` REAL NOT NULL, `width` REAL NOT NULL, `height` REAL NOT NULL,
        `rotationDegrees` REAL NOT NULL, `zIndex` INTEGER NOT NULL,
        `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`id`),
        FOREIGN KEY(`pageId`) REFERENCES `note_pages`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE)"""

    /** Creates a database file exactly as an install of schema [version] would have left it. */
    private fun createLegacyDatabase(version: Int, extraSetup: (SQLiteDatabase) -> Unit = {}) {
        val file = context.getDatabasePath(dbName)
        file.parentFile?.mkdirs()
        val db = SQLiteDatabase.openOrCreateDatabase(file, null)
        try {
            db.execSQL(v1Notes)
            if (version >= 2) {
                v2Columns.forEach { db.execSQL("ALTER TABLE notes ADD COLUMN $it") }
                db.execSQL(pagesDdl)
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_note_pages_noteId` ON `note_pages` (`noteId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_note_pages_noteId_pageIndex` ON `note_pages` (`noteId`, `pageIndex`)")
                db.execSQL(elementsDdl)
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_note_elements_pageId` ON `note_elements` (`pageId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_note_elements_pageId_zIndex` ON `note_elements` (`pageId`, `zIndex`)")
            }
            if (version >= 3) {
                db.execSQL("ALTER TABLE notes ADD COLUMN folderId TEXT")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_notes_folderId` ON `notes` (`folderId`)")
                db.execSQL(
                    """CREATE TABLE IF NOT EXISTS `folders` (`id` TEXT NOT NULL, `name` TEXT NOT NULL,
                       `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`id`))"""
                )
            }
            if (version >= 4) {
                db.execSQL("ALTER TABLE notes ADD COLUMN deletedAt INTEGER")
            }
            extraSetup(db)
            db.version = version
        } finally {
            db.close()
        }
    }

    private fun openCurrent(name: String = dbName): NotesDatabase =
        Room.databaseBuilder(context, NotesDatabase::class.java, name)
            .addMigrations(*NotesDatabase.ALL_MIGRATIONS)
            .allowMainThreadQueries()
            .build()

    private fun SupportSQLiteDatabase.strings(sql: String): List<List<String?>> =
        query(sql).use { c ->
            val rows = ArrayList<List<String?>>()
            while (c.moveToNext()) {
                rows.add((0 until c.columnCount).map { i -> if (c.isNull(i)) null else c.getString(i) })
            }
            rows
        }

    // ---- tests ---------------------------------------------------------------------------

    @Test
    fun v1ToV4KeepsLegacyNoteAndGivesNewColumnsSafeDefaults() = runBlocking {
        createLegacyDatabase(1) { db ->
            db.execSQL(
                "INSERT INTO notes (id,title,body,createdAt,updatedAt) " +
                    "VALUES ('n1','عنوان قديم','نص قديم\nsecond line',111,222)"
            )
        }
        val database = openCurrent()
        try {
            val note = database.noteDao().getById("n1")!!
            assertEquals("عنوان قديم", note.title)
            assertEquals("نص قديم\nsecond line", note.body)
            assertEquals(111L, note.createdAt)
            assertEquals(222L, note.updatedAt)
            assertEquals(false, note.isPinned)
            assertEquals(false, note.isArchived)
            assertEquals(false, note.isFavorite)
            assertEquals("PAGED", note.pageMode)
            assertEquals(null, note.folderId)
            assertEquals(null, note.deletedAt)

            // The legacy body must reach the page text instead of being replaced by an empty page.
            val repository = NotesRepository(
                database,
                AttachmentStorage(File(context.cacheDir, "mig-att-${System.nanoTime()}"))
            )
            val document = repository.loadDocument("n1")!!
            assertEquals("نص قديم\nsecond line", document.pages.single().text)
            assertEquals("نص قديم\nsecond line", database.noteDao().getById("n1")!!.body)
        } finally {
            database.close()
        }
    }

    @Test
    fun v2ToV4KeepsFlagsPagesAndInkPayloadsByteForByte() {
        val inkPayload = """{"v":1,"opaque":"ضغط-لا-يتغير-١٢٣","points":[[1.5,2.5,0.5],[3,4,0.9]]}"""
        createLegacyDatabase(2) { db ->
            db.execSQL(
                "INSERT INTO notes (id,title,body,createdAt,updatedAt,isPinned,isArchived,isFavorite,pageMode) " +
                    "VALUES ('n2','t','b',1,2,1,1,1,'INFINITE')"
            )
            db.execSQL(
                "INSERT INTO note_pages VALUES ('p2','n2',0,794.0,1123.0,'LANDSCAPE','GRID',4294967295,5,6)"
            )
            db.execSQL(
                "INSERT INTO note_elements VALUES ('e2','p2','INK',1,'${inkPayload.replace("'", "''")}',1.0,2.0,3.0,4.0,5.0,7,8,9)"
            )
        }
        val database = openCurrent()
        try {
            val sql = database.openHelper.writableDatabase
            val note = sql.strings("SELECT isPinned,isArchived,isFavorite,pageMode,folderId,deletedAt FROM notes WHERE id='n2'").single()
            assertEquals(listOf("1", "1", "1", "INFINITE", null, null), note)
            val page = sql.strings("SELECT pageIndex,widthDp,heightDp,orientation,template,backgroundColorArgb FROM note_pages WHERE id='p2'").single()
            assertEquals(listOf("0", "794.0", "1123.0", "LANDSCAPE", "GRID", "4294967295"), page)
            val element = sql.strings("SELECT elementType,payloadVersion,payloadJson,zIndex FROM note_elements WHERE id='e2'").single()
            assertEquals("INK", element[0])
            assertEquals("1", element[1])
            assertEquals(inkPayload, element[2])
            assertEquals("7", element[3])
        } finally {
            database.close()
        }
    }

    @Test
    fun v3ToV4KeepsFoldersAndAssignments() = runBlocking {
        createLegacyDatabase(3) { db ->
            db.execSQL("INSERT INTO folders VALUES ('f1','مجلد',10,20)")
            db.execSQL(
                "INSERT INTO notes (id,title,body,createdAt,updatedAt,folderId) VALUES ('n3','t','b',1,2,'f1')"
            )
        }
        val database = openCurrent()
        try {
            assertEquals("f1", database.noteDao().getById("n3")!!.folderId)
            assertEquals(null, database.noteDao().getById("n3")!!.deletedAt)
            val folders = database.openHelper.writableDatabase.strings("SELECT id,name,createdAt,updatedAt FROM folders")
            assertEquals(listOf(listOf<String?>("f1", "مجلد", "10", "20")), folders)
        } finally {
            database.close()
        }
    }

    @Test
    fun migratedSchemaMatchesFreshlyCreatedSchema() {
        createLegacyDatabase(1) { db ->
            db.execSQL("INSERT INTO notes (id,title,body,createdAt,updatedAt) VALUES ('n','t','b',1,2)")
        }
        val migrated = openCurrent()
        val fresh = openCurrent("fresh-$dbName")
        try {
            val a = migrated.openHelper.writableDatabase
            val b = fresh.openHelper.writableDatabase
            for (table in listOf("notes", "note_pages", "note_elements", "folders")) {
                assertEquals("columns of $table", describe(b, table), describe(a, table))
                assertEquals("indices of $table", indices(b, table), indices(a, table))
                assertEquals("foreign keys of $table", foreignKeys(b, table), foreignKeys(a, table))
            }
        } finally {
            migrated.close()
            fresh.close()
        }
    }

    @Test
    fun migrationToleratesColumnsThatAlreadyExist() = runBlocking {
        // A partially upgraded install: columns exist but the version number was not advanced.
        createLegacyDatabase(1) { db ->
            db.execSQL("ALTER TABLE notes ADD COLUMN isPinned INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE notes ADD COLUMN folderId TEXT")
            db.execSQL("ALTER TABLE notes ADD COLUMN deletedAt INTEGER")
            db.execSQL(
                "INSERT INTO notes (id,title,body,createdAt,updatedAt,isPinned) VALUES ('n','t','b',1,2,1)"
            )
        }
        val database = openCurrent()
        try {
            assertEquals(true, database.noteDao().getById("n")!!.isPinned)
        } finally {
            database.close()
        }
    }

    @Test
    fun cascadeDeleteStillRemovesOnlyThatNotesPagesAndElementsAfterMigration() {
        createLegacyDatabase(2) { db ->
            for (n in listOf("a", "b")) {
                db.execSQL("INSERT INTO notes (id,title,body,createdAt,updatedAt) VALUES ('$n','t','b',1,2)")
                db.execSQL("INSERT INTO note_pages VALUES ('p$n','$n',0,794.0,1123.0,'PORTRAIT','BLANK',4294967295,1,1)")
                db.execSQL("INSERT INTO note_elements VALUES ('e$n','p$n','TEXT',1,'{\"text\":\"x\"}',0,0,1,1,0,0,1,1)")
            }
        }
        val database = openCurrent()
        try {
            val sql = database.openHelper.writableDatabase
            sql.execSQL("DELETE FROM notes WHERE id='a'")
            assertEquals(listOf("pb"), sql.strings("SELECT id FROM note_pages").map { it[0] })
            assertEquals(listOf("eb"), sql.strings("SELECT id FROM note_elements").map { it[0] })
        } finally {
            database.close()
        }
    }

    @Test
    fun databaseFromNewerAppVersionIsRefusedAndLeftUntouched() {
        createLegacyDatabase(4) { db ->
            db.execSQL("INSERT INTO notes (id,title,body,createdAt,updatedAt) VALUES ('keep','t','b',1,2)")
        }
        // Simulate a file written by a future app version.
        val file = context.getDatabasePath(dbName)
        SQLiteDatabase.openDatabase(file.path, null, SQLiteDatabase.OPEN_READWRITE).use { it.version = 99 }

        val database = openCurrent()
        try {
            try {
                database.openHelper.writableDatabase
                fail("A downgrade must be refused, never silently reset")
            } catch (expected: Exception) {
                // Any exception is acceptable here; wiping the file is not (checked below).
            }
        } finally {
            database.close()
        }
        SQLiteDatabase.openDatabase(file.path, null, SQLiteDatabase.OPEN_READONLY).use { raw ->
            assertEquals(99, raw.version)
            raw.rawQuery("SELECT id FROM notes", null).use { c ->
                assertTrue(c.moveToFirst())
                assertEquals("keep", c.getString(0))
            }
        }
    }

    @Test
    fun reopeningAMigratedDatabaseIsStable() = runBlocking {
        createLegacyDatabase(1) { db ->
            db.execSQL("INSERT INTO notes (id,title,body,createdAt,updatedAt) VALUES ('n','t','b',1,2)")
        }
        openCurrent().also { it.openHelper.writableDatabase; it.close() }
        val second = openCurrent()
        try {
            assertEquals("t", second.noteDao().getById("n")!!.title)
            assertEquals(4, second.openHelper.writableDatabase.version)
        } finally {
            second.close()
        }
    }

    // ---- schema introspection helpers -------------------------------------------------------

    /** name,type,notnull,pk per column; order-independent (ALTER TABLE appends columns). */
    private fun describe(db: SupportSQLiteDatabase, table: String): Set<List<String?>> =
        db.strings("PRAGMA table_info(`$table`)").map { listOf(it[1], it[2], it[3], it[5]) }.toSet()

    private fun indices(db: SupportSQLiteDatabase, table: String): Set<String?> =
        db.strings("PRAGMA index_list(`$table`)").map { it[1] }.filter { it?.startsWith("sqlite_autoindex") == false }.toSet()

    /** from,table,to,on_update,on_delete */
    private fun foreignKeys(db: SupportSQLiteDatabase, table: String): Set<List<String?>> =
        db.strings("PRAGMA foreign_key_list(`$table`)").map { listOf(it[3], it[2], it[4], it[5], it[6]) }.toSet()
}
