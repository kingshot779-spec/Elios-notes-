package com.eliosnotes.app.data

import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import androidx.room.Room
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.eliosnotes.app.data.document.NoteElementEntity
import com.eliosnotes.app.data.document.NoteElementType
import com.eliosnotes.app.data.document.NotePageEntity
import com.eliosnotes.app.data.media.AttachmentStorage
import java.io.File
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Data-safety rules from the product contract, checked against real SQLite/Room behavior. */
@RunWith(AndroidJUnit4::class)
class NotesDatabaseIntegrityTest {
    private lateinit var context: Context
    private lateinit var database: NotesDatabase
    private lateinit var repository: NotesRepository

    @Before
    fun setUp() {
        context = InstrumentationRegistry.getInstrumentation().targetContext
        database = Room.inMemoryDatabaseBuilder(context, NotesDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = NotesRepository(
            database,
            AttachmentStorage(File(context.cacheDir, "integrity-${System.nanoTime()}"))
        )
    }

    @After
    fun tearDown() {
        database.close()
    }

    private fun note(id: String) = NoteEntity(id = id, title = "t-$id", body = "b-$id", createdAt = 1, updatedAt = 2)

    private fun page(id: String, noteId: String, index: Int = 0) = NotePageEntity(
        id = id, noteId = noteId, pageIndex = index, widthDp = 794f, heightDp = 1123f,
        createdAt = 1, updatedAt = 2
    )

    private fun element(id: String, pageId: String, type: String, version: Int, payload: String, z: Int = 0) =
        NoteElementEntity(
            id = id, pageId = pageId, elementType = type, payloadVersion = version,
            payloadJson = payload, zIndex = z, createdAt = 1, updatedAt = 2
        )

    @Test
    fun insertingADuplicateNoteAbortsAndKeepsTheOriginal() = runBlocking {
        database.noteDao().insert(note("n"))
        database.notePageDao().insert(page("p", "n"))
        try {
            database.noteDao().insert(note("n").copy(title = "overwrite attempt"))
            fail("Duplicate id must abort, not replace")
        } catch (expected: SQLiteConstraintException) {
        }
        assertEquals("t-n", database.noteDao().getById("n")!!.title)
        // A REPLACE would have cascade-deleted this page.
        assertNotNull(database.notePageDao().getById("p"))
    }

    @Test
    fun upsertingAnElementNeverCascadeDeletesItsPageOrSiblings() = runBlocking {
        database.noteDao().insert(note("n"))
        database.notePageDao().insert(page("p", "n"))
        database.noteElementDao().upsert(element("e1", "p", "INK", 1, "{}"))
        database.noteElementDao().upsert(element("e2", "p", "INK", 1, "{}", 1))
        database.noteElementDao().upsert(element("e1", "p", "INK", 1, "{\"changed\":true}"))
        assertNotNull(database.notePageDao().getById("p"))
        assertEquals(setOf("e1", "e2"), database.noteElementDao().getElements("p").map { it.id }.toSet())
        assertEquals("{\"changed\":true}", database.noteElementDao().getById("e1")!!.payloadJson)
    }

    @Test
    fun foreignKeysAreEnforcedForOrphanPagesAndElements() = runBlocking {
        try {
            database.notePageDao().insert(page("orphan", "no-such-note"))
            fail("A page without a note must be rejected")
        } catch (expected: SQLiteConstraintException) {
        }
        database.noteDao().insert(note("n"))
        database.notePageDao().insert(page("p", "n"))
        try {
            database.noteElementDao().insertAllAbort(listOf(element("bad", "no-such-page", "INK", 1, "{}")))
            fail("An element without a page must be rejected")
        } catch (expected: SQLiteConstraintException) {
        }
    }

    @Test
    fun failedBatchInsertRollsBackEveryElementInIt() = runBlocking {
        database.noteDao().insert(note("n"))
        database.notePageDao().insert(page("p", "n"))
        database.noteElementDao().upsert(element("existing", "p", "INK", 1, "{}"))
        try {
            database.noteElementDao().insertAllAbort(
                listOf(
                    element("new-1", "p", "INK", 1, "{}"),
                    element("existing", "p", "INK", 1, "{\"overwrite\":true}")
                )
            )
            fail("Collision must abort the whole batch")
        } catch (expected: SQLiteConstraintException) {
        }
        assertNull(database.noteElementDao().getById("new-1"))
        assertEquals("{}", database.noteElementDao().getById("existing")!!.payloadJson)
    }

    @Test
    fun savePageNeverDeletesUndecodableInkOrUnknownElementTypes() = runBlocking {
        val created = repository.createNote(null)
        val pageId = database.notePageDao().getPages(created.id).single().id
        database.noteElementDao().upsert(element("future-ink", pageId, "INK", 99, "{\"from\":\"newer app\"}", 1))
        database.noteElementDao().upsert(element("future-type", pageId, "HOLOGRAM", 5, "{\"x\":1}", 2))

        repository.savePage(
            noteId = created.id, pageId = pageId, text = "hello",
            strokes = emptyList(), writeText = true, protectedInkIds = setOf("future-ink")
        )

        assertEquals("{\"from\":\"newer app\"}", database.noteElementDao().getById("future-ink")!!.payloadJson)
        assertEquals("{\"x\":1}", database.noteElementDao().getById("future-type")!!.payloadJson)
        val reloaded = repository.loadDocument(created.id)!!.pages.single()
        assertEquals("hello", reloaded.text)
        assertTrue("future-ink" in reloaded.lockedInkIds)
    }

    @Test
    fun savePageDoesNotOverwriteUnreadableTextWhenWriteTextIsFalse() = runBlocking {
        val created = repository.createNote(null)
        val pageId = database.notePageDao().getPages(created.id).single().id
        val unreadable = "{\"text\":\"from newer app\",\"spans\":[1,2,3]}"
        database.noteElementDao().upsert(element("text-$pageId", pageId, NoteElementType.TEXT, 7, unreadable))

        val page = repository.loadDocument(created.id)!!.pages.single()
        assertTrue("text must be reported as locked", page.textLocked)

        repository.savePage(created.id, pageId, "", emptyList(), writeText = false)
        assertEquals(unreadable, database.noteElementDao().getById("text-$pageId")!!.payloadJson)
    }

    @Test
    fun deletingOneNoteLeavesOtherNotesUntouched() = runBlocking {
        for (id in listOf("a", "b")) {
            database.noteDao().insert(note(id))
            database.notePageDao().insert(page("p$id", id))
            database.noteElementDao().upsert(element("e$id", "p$id", "INK", 1, "{}"))
        }
        database.noteDao().deleteForever("a")
        assertNull(database.notePageDao().getById("pa"))
        assertNull(database.noteElementDao().getById("ea"))
        assertNotNull(database.notePageDao().getById("pb"))
        assertNotNull(database.noteElementDao().getById("eb"))
    }

    @Test
    fun trashAndRestoreKeepPagesAndElements() = runBlocking {
        database.noteDao().insert(note("n"))
        database.notePageDao().insert(page("p", "n"))
        database.noteElementDao().upsert(element("e", "p", "INK", 1, "{}"))
        database.noteDao().moveToTrash("n", 123L)
        assertEquals(123L, database.noteDao().getById("n")!!.deletedAt)
        assertNotNull(database.notePageDao().getById("p"))
        database.noteDao().restoreFromTrash("n")
        assertNull(database.noteDao().getById("n")!!.deletedAt)
        assertNotNull(database.noteElementDao().getById("e"))
    }
}
