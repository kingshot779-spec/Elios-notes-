package com.eliosnotes.app.data

import android.content.Context
import androidx.room.Room
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.eliosnotes.app.data.document.NoteElementEntity
import com.eliosnotes.app.data.document.NoteElementType
import com.eliosnotes.app.data.document.TextCodec
import com.eliosnotes.app.data.media.AttachmentStorage
import com.eliosnotes.app.data.media.AttachmentRefCodec
import com.eliosnotes.app.data.media.StoredAttachment
import java.io.File
import java.io.ByteArrayInputStream
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Exercises the real SQLite/Room transaction paths used by page insertion, ordering and duplication. */
@RunWith(AndroidJUnit4::class)
class NotesRepositoryPageTransactionTest {
    private lateinit var context: Context
    private lateinit var database: NotesDatabase
    private lateinit var repository: NotesRepository

    @Before
    fun setUp() {
        context = InstrumentationRegistry.getInstrumentation().targetContext
        database = Room.inMemoryDatabaseBuilder(context, NotesDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = NotesRepository(
            database,
            AttachmentStorage(File(context.cacheDir, "repository-page-test-${System.nanoTime()}"))
        )
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun insertAndReorderKeepStablePageAndElementIdentity() = runBlocking {
        val note = repository.createNote(null)
        val original = database.notePageDao().getPages(note.id).single()
        val inserted = repository.newPage(note.id, 1, 2L).copy(
            template = "GRID",
            backgroundColorArgb = 0xFFFFF8E1L
        )
        repository.insertPageAt(note.id, inserted, 0)

        val opaqueElement = NoteElementEntity(
            id = "future-element-${System.nanoTime()}",
            pageId = original.id,
            elementType = "FUTURE_ELEMENT_TYPE",
            payloadVersion = 99,
            payloadJson = "{\"future\":true}",
            createdAt = 3L,
            updatedAt = 3L
        )
        database.noteElementDao().upsert(opaqueElement)

        repository.reorderPages(note.id, listOf(original.id, inserted.id))

        val ordered = database.notePageDao().getPages(note.id)
        assertEquals(listOf(original.id, inserted.id), ordered.map { it.id })
        assertEquals(listOf(0, 1), ordered.map { it.pageIndex })
        assertEquals("GRID", ordered[1].template)
        assertEquals(0xFFFFF8E1L, ordered[1].backgroundColorArgb)
        assertEquals(opaqueElement, database.noteElementDao().getById(opaqueElement.id))
    }


    @Test
    fun duplicatePageCopiesAllPayloadsWithFreshIdentitiesAndSharedMediaReference() = runBlocking {
        val note = repository.createNote(null)
        val source = database.notePageDao().getPages(note.id).single().copy(
            template = "DOTS",
            backgroundColorArgb = 0xFFE8F1FBL,
            widthDp = 900f,
            heightDp = 1200f
        )
        database.notePageDao().updateAll(listOf(source))
        val text = NoteElementEntity(
            id = "text-${source.id}", pageId = source.id, elementType = NoteElementType.TEXT,
            payloadVersion = 1, payloadJson = TextCodec.encode("Original page text"),
            x = 0f, y = 0f, width = source.widthDp, height = source.heightDp,
            zIndex = 0, createdAt = 10L, updatedAt = 10L
        )
        val mediaRef = StoredAttachment(
            sha256 = "a".repeat(64), extension = "png", byteCount = 123L,
            mimeType = "image/png", displayName = "page-image.png"
        )
        val image = NoteElementEntity(
            id = "image-${source.id}", pageId = source.id, elementType = NoteElementType.IMAGE,
            payloadVersion = AttachmentRefCodec.VERSION, payloadJson = AttachmentRefCodec.encode(mediaRef),
            x = 20f, y = 30f, width = 120f, height = 90f,
            zIndex = 2, createdAt = 10L, updatedAt = 10L
        )
        val opaque = NoteElementEntity(
            id = "future-${source.id}", pageId = source.id, elementType = "FUTURE_WIDGET",
            payloadVersion = 77, payloadJson = "{\"preserve\":true}",
            x = 12f, y = 34f, width = 56f, height = 78f, rotationDegrees = 9f,
            zIndex = 3, createdAt = 11L, updatedAt = 11L
        )
        database.noteElementDao().upsertAll(listOf(text, image, opaque))

        val duplicateId = repository.duplicatePage(note.id, source.id)
        val pages = database.notePageDao().getPages(note.id)
        val duplicate = pages.single { it.id == duplicateId }
        val sourceElements = database.noteElementDao().getElements(source.id)
        val duplicateElements = database.noteElementDao().getElements(duplicateId)

        assertEquals(listOf(source.id, duplicateId), pages.map { it.id })
        assertEquals(1, duplicate.pageIndex)
        assertEquals(source.widthDp, duplicate.widthDp)
        assertEquals(source.heightDp, duplicate.heightDp)
        assertEquals(source.template, duplicate.template)
        assertEquals(source.backgroundColorArgb, duplicate.backgroundColorArgb)
        assertEquals(sourceElements.size, duplicateElements.size)
        sourceElements.zip(duplicateElements).forEach { (original, copied) ->
            assertNotEquals(original.id, copied.id)
            if (original.elementType == NoteElementType.TEXT) assertEquals("text-$duplicateId", copied.id)
            assertNotEquals(original.pageId, copied.pageId)
            assertEquals(original.elementType, copied.elementType)
            assertEquals(original.payloadVersion, copied.payloadVersion)
            assertEquals(original.payloadJson, copied.payloadJson)
            assertEquals(original.x, copied.x)
            assertEquals(original.y, copied.y)
            assertEquals(original.width, copied.width)
            assertEquals(original.height, copied.height)
            assertEquals(original.rotationDegrees, copied.rotationDegrees)
            assertEquals(original.zIndex, copied.zIndex)
        }
        assertEquals("Original page text\nOriginal page text", database.noteDao().getById(note.id)?.body)
        val copiedMedia = duplicateElements.single { it.elementType == NoteElementType.IMAGE }
        assertEquals(mediaRef, AttachmentRefCodec.decodeOrNull(copiedMedia.payloadJson))
    }



    @Test
    fun duplicatePageKeepsSharedAttachmentBlobUntilLastReferenceIsRemoved() = runBlocking {
        val note = repository.createNote(null)
        val sourcePage = database.notePageDao().getPages(note.id).single()
        val stored = repository.addAttachment(
            sourcePage.id,
            ByteArrayInputStream(byteArrayOf(1, 2, 3, 4, 5)),
            "shared-image.png",
            "image/png"
        )
        val sourceElement = database.noteElementDao().getElements(sourcePage.id).single()
        val duplicateId = repository.duplicatePage(note.id, sourcePage.id)
        val copiedElement = database.noteElementDao().getElements(duplicateId).single()
        val blob = repository.attachmentFile(stored)

        assertTrue(blob.isFile)
        assertNotEquals(sourceElement.id, copiedElement.id)
        assertEquals(sourceElement.payloadJson, copiedElement.payloadJson)
        assertTrue(repository.removeAttachment(sourceElement.id))
        assertTrue("Shared blob must survive while duplicate still references it", blob.isFile)
        assertTrue(repository.removeAttachment(copiedElement.id))
        assertTrue("Blob is deleted after the last reference is removed", !blob.exists())
    }

    @Test
    fun duplicatePagePreservesSearchMirrorWhenTextPayloadIsUnknown() = runBlocking {
        val note = repository.createNote(null)
        database.noteDao().updateContent(note.id, "Existing searchable mirror", 20L)
        val source = database.notePageDao().getPages(note.id).single()
        database.noteElementDao().upsert(
            NoteElementEntity(
                id = "future-text-${source.id}", pageId = source.id, elementType = NoteElementType.TEXT,
                payloadVersion = 99, payloadJson = "{\"futureText\":true}",
                createdAt = 21L, updatedAt = 21L
            )
        )

        repository.duplicatePage(note.id, source.id)
        repository.savePage(note.id, source.id, "", emptyList(), writeText = false)

        assertEquals("Existing searchable mirror", database.noteDao().getById(note.id)?.body)
        assertEquals(2, database.notePageDao().getPages(note.id).size)
    }


    @Test
    fun duplicatePagePreservesLegacyBodyWhenNoTextElementsExistYet() = runBlocking {
        val note = repository.createNote(null)
        database.noteDao().updateContent(note.id, "Legacy note body", 30L)
        val source = database.notePageDao().getPages(note.id).single()

        repository.duplicatePage(note.id, source.id)

        assertEquals("Legacy note body", database.noteDao().getById(note.id)?.body)
        assertTrue(database.noteElementDao().getElements(source.id).isEmpty())
    }


    @Test
    fun duplicatePageRejectsAmbiguousMultipleTextRowsAtomically() = runBlocking {
        val note = repository.createNote(null)
        val source = database.notePageDao().getPages(note.id).single()
        database.noteElementDao().upsertAll(listOf(
            NoteElementEntity(
                id = "text-a-${source.id}", pageId = source.id, elementType = NoteElementType.TEXT,
                payloadJson = TextCodec.encode("First"), createdAt = 1L, updatedAt = 1L
            ),
            NoteElementEntity(
                id = "text-b-${source.id}", pageId = source.id, elementType = NoteElementType.TEXT,
                payloadJson = TextCodec.encode("Second"), createdAt = 2L, updatedAt = 2L
            )
        ))
        val before = database.notePageDao().getPages(note.id)
        var rejected = false

        try {
            repository.duplicatePage(note.id, source.id)
        } catch (_: IllegalArgumentException) {
            rejected = true
        }

        assertTrue("Ambiguous text payloads must fail closed", rejected)
        assertEquals(before, database.notePageDao().getPages(note.id))
        assertEquals(2, database.noteElementDao().getElements(source.id).size)
    }

    @Test
    fun duplicatePageRejectsPageFromAnotherNoteWithoutChangingEitherDocument() = runBlocking {
        val firstNote = repository.createNote(null)
        val secondNote = repository.createNote(null)
        val foreignPage = database.notePageDao().getPages(secondNote.id).single()
        val firstBefore = database.notePageDao().getPages(firstNote.id)
        var rejected = false

        try {
            repository.duplicatePage(firstNote.id, foreignPage.id)
        } catch (_: IllegalArgumentException) {
            rejected = true
        }

        assertTrue("A page belonging to another note must be rejected", rejected)
        assertEquals(firstBefore, database.notePageDao().getPages(firstNote.id))
        assertEquals(1, database.notePageDao().getPages(secondNote.id).size)
    }

    @Test
    fun invalidReorderDoesNotChangePersistedOrder() = runBlocking {
        val note = repository.createNote(null)
        val first = database.notePageDao().getPages(note.id).single()
        val second = repository.newPage(note.id, 1, 2L)
        repository.insertPageAt(note.id, second, 1)
        val before = database.notePageDao().getPages(note.id)

        var rejected = false
        try {
            repository.reorderPages(note.id, listOf(first.id, "unknown-page"))
        } catch (_: IllegalArgumentException) {
            rejected = true
        }
        assertTrue("Invalid page order must be rejected", rejected)

        assertEquals(before, database.notePageDao().getPages(note.id))
        assertNotNull(database.notePageDao().getById(first.id))
    }
}
