# Room schema exports

Room writes `com.eliosnotes.app.data.NotesDatabase/<version>.json` here during `kspDebugKotlin`
(`room.schemaLocation` in `app/build.gradle.kts`).

**Status: not generated yet.** No Room compiler has run on this source tree, so no schema JSON exists
and none was written by hand (the identity hash inside is computed by Room; a hand-written value would
be fabricated). After the first successful CI build:

1. Download the `ELIOS_NOTES-v82-room-schemas` artifact.
2. Commit `NotesDatabase/4.json` to this folder.
3. From then on `scripts/ci-build-apk.sh` fails the build if the generated schema differs from the
   committed one, so a schema change without a version bump and migration cannot slip through.

Schemas for versions 1-3 were never exported by earlier builds. Their migrations are covered by
`NotesDatabaseMigrationTest`, which rebuilds those databases from DDL instead.
