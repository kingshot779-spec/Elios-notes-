# Next development agent instructions — ELIOS NOTES from v78

The only source baseline for this task is `ELIOS_NOTES_v78_source.zip`. Open and validate the archive itself before changing anything. Do not substitute summaries or filenames for source inspection.

## Product contract

- Practical functional/workflow parity with Samsung Notes, using original ELIOS identity and assets. Do not copy Samsung marks, logos, or protected assets or claim literal identity.
- Keep handwriting ink-to-text and reversible handwriting beautification as two distinct, undoable paths. Neither may silently destroy original ink.
- Local-only storage, no mandatory account or cloud sync. Reliable export/import is the device-transfer mechanism.
- Phones and tablets are targets. Stylus capabilities must be detected at runtime.
- Never lose or rewrite existing note/page/element IDs, text, ink, attachments, folders, backup data, or unknown/future payloads. Never clear the database as a fallback.
- A class or button is not proof of a completed feature; require appropriate tests, build evidence and device validation.

## P0 gates from v78

1. Read `V78_PHASE3_REPORT.md`, README, AUDIT_REPORT, SPEC_TRACEABILITY, and the previous agent prompt.
2. Inspect `.github/workflows/build-apk.yml`; configuration is not proof that CI passed.
3. If GitHub Actions is accessible, inspect a run for this exact source. Otherwise record CI as BLOCKED/NOT OBSERVED.
4. Review the KSP-generated Room schema artifact. Never hand-author schema JSON. Verify v4 against the actual entities, then add the generated schema under `app/schemas` if possible.
5. Add Room migration tests for supported versions 1→2→3→4 using real fixtures. Do not add migrations unless schema changes. Never use destructive migration.
6. Run lint, JVM tests, assembleDebug and connectedDebugAndroidTest when available; report PASSED/FAILED/BLOCKED/NOT RUN accurately.

## Next feature phase after P0

Implement a page overview/sorter:
- Thumbnail/preview list that works on phone and tablet.
- Tap a thumbnail to navigate to that page.
- Drag-and-drop reorder with clear insertion indicator and safe cancellation.
- Reuse `PageOrderPolicy` and `NotesRepository.reorderPages`; do not create a second persistence path.
- Reorder by page IDs and reject incomplete, duplicate or unknown ID sets.
- Never regenerate page IDs or rewrite page text, ink or elements during reorder.
- Test rapid reorder, cancellation, SaveQueue ordering, process restart and invalid requests.

## Safe page duplication is a separate gated feature

Do not add Duplicate Page until a single atomic operation is designed to:
- Generate a new page ID and new element IDs for every duplicated element.
- Preserve payloadVersion, payloadJson, geometry, zIndex, timestamp semantics and unknown/future fields.
- Never reuse old element IDs.
- Reuse content-addressed attachment references where appropriate; do not copy blobs unnecessarily or delete shared blobs.
- Roll back completely on any collision/failure; never leave a partial page.
- Test text, ink, attachments, future element types, backup and restore.

If byte-for-byte preservation of unknown payloads cannot be guaranteed, do not implement duplication.

## Working and review rules

- Validate ZIP CRC, unsafe paths and duplicate entries. Work in a fresh directory; never modify the input archive.
- Inventory Kotlin/XML/Gradle/Room schemas/migrations/tests/resources/CI and inspect every caller before changing an API.
- Parallelize independent inspections, but serialize edits to shared files.
- Do not change Room schema without real schema export, explicit migration and migration tests.
- Use existing Room transactions, repository mutex and SaveQueue.
- Do not swallow exceptions or replace undecodable payloads with empty data.
- Add unit, Room/repository and regression tests.
- Parse XML and check Arabic/English resource-key parity.
- Review the complete diff for deletions, TODO placeholders, unnecessary `!!`, and file I/O on the main thread.
- Update README, audit, traceability, release report and next-agent instructions.
- Increment versionCode sequentially.
- Build a clean ZIP, re-extract and compare contents, calculate SHA-256.
- Never claim APK build, green CI or device testing without direct evidence.

## v78 facts to preserve

- App 0.5.6 / versionCode 29; Room schema v4.
- CI is configured for lintDebug, testDebugUnitTest, assembleDebug, generated Room schema assertion and connectedDebugAndroidTest on API 36. No successful run has yet been established.
- `NotesRepositoryPageTransactionTest` covers real in-memory Room insert/reorder, stable IDs, preservation of an opaque future element, and invalid reorder leaving stored order unchanged. Added but not run locally.
- `PageOrderPolicyTest` covers page presentation settings.
- No manually fabricated schema JSON was added; obtain and review KSP output.
- Page thumbnails, drag/drop and page duplication are not implemented.
- Previous environment lacks Gradle executable, wrapper JAR, Android SDK and ADB.

## Delivery requirements

Provide source ZIP and SHA-256, change summary, diff/no-deletion report, test status table, APK/CI status, known limitations, engineering report and next-agent prompt. Do not call the app release-ready or fully equivalent without evidence.
