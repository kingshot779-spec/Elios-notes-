# ELIOS NOTES — Original Specification Traceability

Reference: `مشروع ايلي(1).txt`, approved engineering specification v1.1 and its accompanying product decisions.
Historical baseline review: source archive `ELIOS_NOTES_v55_source.zip` (app 0.3.7, versionCode 10), with follow-up implementation recorded in v56. Current traceability is updated through `ELIOS_NOTES_v79_source.zip` (app 0.5.7 / versionCode 30; Room schema v4) in the v79 section at the end of this document.

This is a source-code audit, not a claim of runtime or device verification. A database method, enum value, placeholder, or toolbar label does not count as a completed user feature unless the full user flow is connected, persisted, restored, rendered, exported where relevant, and tested.

## Product decisions that remain binding

- Android phones and tablets; Kotlin + Jetpack Compose, Android Views where useful.
- Minimum SDK 23; target SDK 36, subject to current Play requirements at release time.
- Arabic and English, correct RTL/LTR and mixed-direction content.
- Local-first, usable offline, no mandatory account, cloud sync, ads, subscriptions, or external upload of note content.
- Free functionality; no AI branding or AI-assistant UI in the product.
- Familiar Samsung Notes workflows and visual hierarchy, implemented independently with original assets and no copied Samsung code, icons, or protected resources.
- Preserve editability and original source data; never silently discard strokes, media, PDF source content, or unreadable payloads.

## Requirements matrix

| Area | Original requirement | v54 source status | Completion evidence still required |
|---|---|---|---|
| App identity | ELIOS NOTES, independent branding | Partial | Final icon, splash, typography, theme, adaptive layouts and brand QA |
| Home/library | Notes list, folders, search, familiar Samsung Notes organization | Partial | Full interaction parity, empty/loading/error states, multi-select and device QA |
| Note title | Rename note from expected note controls; persist and update list/search | Implemented in v56 source: rename dialog from active library and archive cards; editor title remains directly editable; normalized non-empty title capped at 120 characters; DAO Flow refreshes list/search | Four JVM policy smoke checks passed; Gradle/JUnit and Android UI/database runtime tests still required |
| Folders | Create, rename, delete, folder navigation | Partial | Validate move/delete semantics, nested folders if required, counts and recovery |
| Organization | Favorites, pinning, archive, trash/restore, sort by name/date/modified, tags | Partial | Verify every UI flow and persistence; tags are not implemented |
| Page modes | Individual pages and continuous scrolling | Partial | Verify stable layout, page navigation, zoom, text flow, and export behavior |
| Templates | Blank, ruled, grid, dotted, study templates; default/per-note choice; colors; portrait/landscape; custom templates from images | Partial | Verify template gallery, custom template import, page backgrounds, orientation and persistence |
| Rich text | Headings, sizes, bold/italic/underline, colors/highlight, alignment, lists, tables, links, mixed Arabic/English, RTL/LTR | Not implemented | Structured rich-text model, editor, persistence, search, backup/restore and PDF export with round-trip tests |
| Handwriting/ink | Pen types, brushes, colors, widths, pressure/tilt when supported, finger input, palm rejection where possible, erasers, lasso, transform, rotate, copy/cut/paste, grouping, z-order, undo/redo | Partial | Full stylus/device capability tests; tilt and S Pen buttons not implemented; zoom and grouping/z-order need verification |
| Ink persistence | Editable vector strokes; retain pressure/tilt samples and fidelity | Partial | Confirm complete sample metadata, migration, backup/restore, transformations and large-document performance |
| Handwriting-to-text (priority differentiator) | Natural finger/stylus handwriting to editable Arabic/English text; review before insertion; preserve original ink; multiple selectable fonts/styles | First-pass recognition only | No proven professional accuracy; mixed-language segmentation, line/paragraph order, confidence/alternatives, timestamps and font/style conversion UI need implementation and real-device benchmark. Current recognition language modes are source-level only and unverified on device |
| Images/media | Insert images, files, links, tables, audio, video; move/resize/layer/delete; correct export representation | Not implemented end-to-end | Private attachment storage, picker, DB metadata, editor rendering, transforms, backup/restore, PDF/image export, broken-file handling |
| Links | Insert clickable links and preserve URL/label | Not implemented as rich content | Safe URL validation, tap/open behavior, edit/delete, backup and export fallback |
| PDF import | Import and view original PDF with page navigation | Not implemented; current code exports PDF only | Preserve original PDF bytes/vector content; robust page renderer, large-file handling and import tests |
| PDF annotation | Pen, highlighter, comments, text, signatures/forms where supported | Not implemented | Non-destructive annotation layer, coordinate mapping, save/reopen and export fidelity |
| PDF page operations | Insert/delete/reorder, merge and split | Not implemented | Preserve original page quality and metadata; validate malformed/encrypted/large PDFs |
| PDF export | Export modified documents without rasterizing original pages at low resolution | Export-only implementation exists | Validate mixed RTL text, fonts, vector ink, images, PDF background pages and fidelity on multiple viewers |
| Audio | Record, pause/resume, attach, playback, seek, rename/delete; later time-linked writing and transcription | Not implemented | Runtime permissions, lifecycle safety, storage, playback UI, timestamps, backup and interruption tests |
| Search | Search titles and text; handwriting search after recognition is reliable | Partial | Verify indexing/update behavior; add attachment/PDF metadata and handwriting-derived text only after validated recognition |
| Backup/restore | Full editable package including notes, pages, strokes, attachments and required metadata; move between devices | Partial | Current README describes JSON backup; it is not encrypted and media are not yet integrated. Need versioned package, attachment integrity, atomic restore and round-trip tests |
| Security | Note lock by PIN/biometric; actual encryption of note content and attachments; backup protection | Not implemented | Cryptographic key management, Android Keystore, biometric gating, encrypted attachments/database or payloads, recovery policy, encrypted backup tests |
| Privacy | No note-content upload; offline core functions | Partial | Audit every permission, SDK, network path and first-run model download disclosure; confirm no telemetry/ad SDK |
| Accessibility/localization | Arabic/English, RTL/LTR, readable controls and adaptive layouts | Partial | Full translation coverage, mixed-direction tests, TalkBack, font scaling and tablet/foldable QA |
| Import/export | PDF, images, text, native editable ELIOS package | Partial | Complete all formats and preserve text, media, strokes, links and page structure |
| Performance/reliability | Smooth writing, large notes, no data loss, cross-device support | Not verified | Instrumented tests, stress tests, crash recovery, low-memory tests and real Samsung/Xiaomi/Lenovo devices |

## v56 follow-up implementation

1. Added a real Rename note action to active-library and archive note menus. The dialog saves through `NotesRepository.saveTitle`; the observed Room flows refresh visible titles and title-based search.
2. Added `NoteTitlePolicy` to trim whitespace, remove ISO control characters, reject blank values and cap titles at 120 characters. Added four JVM tests.
3. Kept the editor top-bar title field as a direct-edit path. Trash items remain non-editable until restored.
4. Bumped app version to 0.3.8 / versionCode 11.

These are source changes; Android Compose compilation, Room runtime, and device interaction have not been verified in this environment.

## Concrete v54 source findings

1. App version is 0.3.7 / versionCode 10; Room schema is still v4.
2. The editor/document model currently exposes plain text and strokes in `PageContent`; rich-text spans and media are not integrated into the load/save/render pipeline.
3. `NoteElementType` declares IMAGE, VIDEO, AUDIO and PDF_CONTENT, but declarations alone do not provide media persistence or UI support.
4. `PdfExporter` exists; import, annotation and structural PDF operations are not implemented end-to-end.
5. `NoteDao.updateTitle` and `NotesRepository.saveTitle` exist. A source-wide search found no UI call site for `saveTitle`; therefore note renaming is not yet a complete user-facing feature.
6. The handwriting recognizer uses ML Kit Digital Ink Recognition with Arabic/English model choices. Source code exists, but Gradle/API linkage, first-use downloads, recognition accuracy and stylus behavior have not been tested on a physical device. Automatic mode's heuristic is not a substitute for mixed-script segmentation or calibrated confidence.
7. The original strokes are retained and the recognized text is reviewed before insertion in the current flow. Do not regress this safety property.
8. The backup is JSON and is explicitly unencrypted; it cannot yet represent future media attachments completely.
9. The source archive does not include a usable Gradle wrapper JAR. The previous environment had no Android SDK or Gradle installation and no network access; full Android build and device testing were therefore not possible there.

## Mandatory implementation and release rules

- Do not build a fake UI or leave dead controls. Every visible control must complete its advertised action.
- Before changing Room entities, define a migration, export schema, rollback/data-safety behavior, and migration tests. Never use destructive migration or `REPLACE` semantics that can cascade-delete note pages/elements.
- Every element type must round-trip through create/edit/save/close/reopen/backup/restore/export.
- PDF source pages must remain vector/original quality where possible; do not silently flatten them into low-resolution images.
- Keep recognition local after model download, disclose first-use model downloads, and never upload note content. Do not claim Arabic/English accuracy without a representative device benchmark.
- Preserve original ink and allow the user to review, edit, choose font/style/size, and explicitly insert/replace recognized text.
- Keep all user-facing product copy free of AI branding or assistant references.
- Do not claim parity with Samsung Notes in the absence of a feature-by-feature verified checklist. Match familiar workflows closely while retaining independent branding and assets.
- A feature is complete only when code, persistence, UI, recovery, export/backup integration (where applicable), automated tests and device tests all pass.

## Release gate

Do not call any APK final or error-free until: clean Gradle build; full unit and instrumentation tests; Room migration tests from every supported schema; static/resource checks; APK inspection; install/upgrade tests; offline tests; Arabic/English handwriting benchmark; PDF/media/backup round-trip tests; crash/data-recovery tests; and physical phone/tablet testing have passed. Record device models, Android versions, test inputs, failures and fixes.

## v57 attachment-storage foundation

| Requirement area | Current status | Remaining acceptance work |
|---|---|---|
| Images, audio, video, PDFs and other attachments | Private binary storage foundation added in v57; not yet exposed in the UI | SAF/photo picker import, Room element metadata, preview/render, edit/remove, reference-safe deletion, backup/restore of binary blobs, and export tests |
| Attachment data safety | Streamed import with byte limit, SHA-256 content identity, temporary-file cleanup and exact-byte reads | Android process-death tests, disk-full/failure tests, DB/blob consistency recovery, and end-to-end lifecycle tests |


## v58 attachment integration follow-up

| Requirement area | Current status | Remaining acceptance work |
|---|---|---|
| Attachment import and persistence | System document picker imports files into private content-addressed storage; versioned references are stored as Room note elements and listed after page reload | Android picker/device tests, image preview, media playback/open, PDF viewer/annotation, attachment removal UI and process-death recovery |
| Attachment integrity | SHA-256 identity, bounded streaming copy, temp-file cleanup, DB commit cleanup attempt, and reference-count-aware deletion API | Orphan reconciliation after crashes, disk-full tests, content hash verification on reads, and end-to-end lifecycle tests |
| Backup/restore | Media-bearing JSON backups are deliberately rejected rather than silently omitting binary data | Replace JSON-only format with a versioned archive containing metadata plus streamed binary blobs; verify and restore atomically with checksums |


## v59 attachment lifecycle update

| Requirement area | Status after v59 | Remaining acceptance work |
|---|---|---|
| Attachment open/remove | Persisted attachment references now carry element IDs; editor can remove a selected attachment; open uses private FileProvider URI and verifies SHA-256 before handing off | Android device/runtime tests; viewer compatibility; inline image preview and in-app PDF/audio/video handling |
| Attachment integrity | SHA-256 is recomputed before open; same-length tampering is covered by a regression test | Disk corruption, process death, storage pressure and concurrent reference tests on device |
| Backup/restore | Still safely blocked for notes containing media; no silent omission | Versioned archive with metadata and binary blobs, streaming checksums, atomic restore and full round-trip tests |

Version 0.4.1 / versionCode 14. This is source-level work only; no Android APK or device validation is claimed.

## v60 — backup archive foundation (partial)
- Requirement: binary backup container with manifest, streaming, size limits, and checksum verification.
- Source: `app/src/main/java/com/eliosnotes/app/data/backup/BackupArchiveCodec.kt`.
- Tests: `app/src/test/java/com/eliosnotes/app/data/backup/BackupArchiveCodecTest.kt`.
- Status: archive codec and validation foundation implemented; **not yet integrated** into repository backup/restore, Android file picker, or atomic database restore. Existing JSON backup restrictions remain in force. This requirement is not complete.

## v61 — archive export integrity hardening (partial)
- Requirement: detect attachment corruption during archive creation, not only after a later extraction.
- Source: `BackupArchiveCodec.write` hashes each streamed blob and compares it with its declared SHA-256; metadata is included in the total archive byte limit.
- Test: regression case rejects same-length tampering before the archive is completed.
- Status: archive primitive is safer, but end-to-end binary backup/restore remains unavailable until repository and Android picker integration, staged file installation, and transactional merge/recovery are implemented and tested.


## v62 — archive metadata integrity (partial)
| Requirement | Implementation | Status / remaining work |
|---|---|---|
| Detect metadata tampering in binary backup | Archive format v2 manifest records `database.json` SHA-256 and byte count; extraction verifies both and cleans staging on failure | Codec-level integrity only; still not connected to repository or Android picker |
| Reject unsupported archive versions | Strict manifest version check with regression test | Codec-level only |
| End-to-end binary backup/restore | No change in v62 | Still pending repository export, staged blob installation, atomic Room merge/recovery, SAF picker, and round-trip tests |

Verification: standalone Kotlin compile; 3/3 archive smoke checks and 2/2 integrity rejection checks. Gradle/JUnit/Android/device testing not performed. Android app version remains 0.4.1 / versionCode 14.


## v63 — same-length attachment corruption repair
| Requirement | Implementation | Status / remaining work |
|---|---|---|
| Re-import repairs damaged content-addressed blobs | Existing destination is SHA-256 checked, not merely length checked; damaged file is quarantined and replaced from a fully streamed/hash-verified temporary file | Storage-level fix and regression smoke test passed; multi-process concurrency and Android process-death behavior still need testing |
| Full binary backup / restore | No end-to-end integration change in v63 | Still pending repository + SAF integration, staging/install recovery, transactional Room merge, and full round-trip tests |

Verification: standalone Kotlin compile and executable same-length-corruption repair smoke test passed; 5 resource XML files parsed; 125 Arabic/English string keys match. Gradle/JUnit/Android/device tests not performed. App remains 0.4.1 / versionCode 14.


## v64 — binary backup export integration (partial)
- Added a repository export path that snapshots folders, notes, pages and all elements, extracts every media reference, verifies each referenced private blob by SHA-256, and writes metadata plus deduplicated content-addressed blobs through the version-2 streaming ZIP archive codec.
- Added archive verification that extracts to temporary staging, verifies archive metadata/blob checksums, parses the embedded backup JSON, and checks that the referenced attachment set exactly matches packaged blobs. Staging is removed in a finally block.
- Added a separate Android SAF “Full backup (ZIP)” export action. It reopens and verifies the written document and deletes the destination document on failure. Existing JSON backup and restore remain unchanged.
- App version advanced to 0.4.2 / versionCode 15 because full ZIP export is now user-accessible.
- Not complete: ZIP restore/import is not integrated. Atomic installation of blobs with Room merge/recovery, conflict remapping, orphan reconciliation, Android runtime validation and full round-trip tests remain pending. Do not claim binary backup/restore complete.
- Verification in this environment: standalone Kotlin codec/storage checks and resource/ZIP checks only; Gradle, JUnit, Android build and device tests were not run.


## v65 — everyday interaction and accidental deletion protection
- Product priority: reduce accidental data loss in common note-management flows before adding secondary polish.
- Library note action `Move to trash`: now requires explicit confirmation.
- Editor overflow action `Move to trash`: now requires the same confirmation; on confirm, pending editor changes are flushed before the soft-delete operation is queued.
- The dialog states that trashed notes can be restored for 30 days. Permanent deletion remains a separate, explicitly confirmed action.
- Arabic/English string resources were added in parity.
- Status: source-level implementation complete; Compose compilation and Android UI/device interaction tests still required.
- App version: 0.4.3 / versionCode 16.


## v65 — UX safety and title-entry consistency
- Library and editor both require explicit confirmation before moving an active note to trash; cancel is non-destructive, confirm uses the existing soft-delete flow.
- The confirmation communicates the 30-day recovery window. Permanent deletion continues to require its own confirmation.
- The editor title field now uses `NoteTitlePolicy.sanitizeDraft`: it removes ISO control characters, caps live input at 120 characters, and intentionally permits an empty draft so the library can show the localized Untitled label.
- Added two unit test cases for blank editor drafts and combined length/control-character sanitization.
- Status: implementation is source-complete; no Gradle/Compose/JUnit or Android UI/device execution was possible here.
- App version: 0.4.3 / versionCode 16.


## v66 — autosave failure recovery for everyday study use
- User-experience requirement: if saving fails, the user must receive truthful feedback and a clear recovery action rather than a misleading “retrying automatically” message.
- Added a localized Retry action to the editor save-failure banner. Retrying captures the current title and all pages again, then uses the existing ordered save queue and sequence guards.
- The feature does not silently discard edits and does not weaken the protected-payload rules.
- Status: source-level implementation complete; still requires Gradle/Compose/JUnit and real-device validation, including simulated storage-full and process interruption.
- App version: 0.4.4 / versionCode 17.


## v67 — prevent loss during editor exit (0.4.5 / build 18)
- Back navigation now waits for a full current-document snapshot to complete in the ordered save queue. If persistence fails, the editor stays open and the user receives a localized explanation.
- Moving a note to Trash is gated on successful awaited persistence; failed saves do not hide the note.
- This is a source-level safeguard; Android build, runtime interruption and device verification remain pending.


## v68 — low-friction, safe folder management
| User need | Implementation | Status / remaining validation |
|---|---|---|
| Avoid accidentally losing folder organization | Deleting a folder requires confirmation and explains that all notes remain in All notes; underlying repository transaction detaches notes before deleting the folder | Source-level implementation; Compose/device interaction tests pending |
| Avoid stale navigation after deleting an open folder | Clears active folder selection and returns to Folders tab after confirmation | Source-level implementation; runtime test pending |
| Clean, uncluttered library header | Removed duplicate app-name title in top bar | Source-level inspection |

App version: 0.4.6 / versionCode 19. Verification does not include Android build or device testing.


## v69 — predictable library search (0.4.7 / build 20)
| User need | Implementation | Status / remaining validation |
|---|---|---|
| Search folders without confusion | Folder tab now filters folder names and labels the field as folder search | Source-level implementation; Compose/device validation pending |
| Know when a hidden query is still active | Closing search clears the query; an inline clear action is available | Source-level implementation |
| Understand empty views | Separate states for no folders, no matching folders, empty folder notes, empty Favorites, and search no-results | Source-level implementation; UX/device validation pending |

Verification: source assertions, XML parse, translation-key parity, and archive integrity. Android build and device tests not run.


## v70 — inline image attachment thumbnails (2026-11-16)

- Review finding: attachments were persisted and listed below each page, but image attachments appeared only as filenames and MIME/byte-count metadata. Students had to leave the note and open another app just to identify a photo or scanned handout.
- Added a compact 56dp image thumbnail beside image attachment rows. Non-image attachments retain their existing filename and open flow.
- Thumbnail decoding runs on `Dispatchers.IO`, first reads image bounds, then decodes a sampled RGB_565 bitmap with a maximum decoded dimension of approximately 512px. This avoids decoding full-resolution camera images solely for a small preview.
- Thumbnail failure (unsupported/corrupt image) falls back to a neutral placeholder; tapping the attachment still uses the existing SHA-256 verification and secure FileProvider open flow. Removing an attachment remains an explicit action.
- App version advanced to 0.4.8 / versionCode 21.
- Validation: source-level checks for IO dispatch, bounds-first sampled decoding, image-only rendering, preserved secure-open path, XML parsing, translation-key parity, and ZIP integrity. No Gradle/Compose compile, JUnit, Android runtime, memory profiling, or physical-device testing was available. This is not a verified APK.

### Media preview status clarification
Image attachments now have a bounded-memory thumbnail in the editor's attachment list. This is not an inline page canvas object: image placement, resize/rotate/layering, image crop/editing, and PDF in-page rendering remain unimplemented. Audio/video playback and an in-app PDF viewer remain outstanding.


## v71 traceability update (2026-11-16)
- Image attachments: improved from thumbnail-only listing to thumbnail tap -> in-app sampled-image preview dialog; original-file open remains available from the attachment row. This is still partial: no inline canvas placement, crop, resize, rotate, layering, full-resolution zoom, or editing.
- Attachment metadata: file size is presented in localized human-readable units rather than raw bytes.
- Validation remains source-level only; Compose compilation, device interaction, TalkBack, and memory profiling are outstanding.


## v72 — complete-backup restore source implementation (2026-11-16)
| Requirement | Implementation | Status / remaining validation |
|---|---|---|
| Restore a complete ZIP backup including attachments | Added separate SAF ZIP restore flow; verifies archive extraction, manifest, metadata checksum, blob hashes and exact media-reference/blob set | Source implemented; Android/Room/device round-trip tests pending |
| Never overwrite existing user notes | Existing note IDs are skipped; note IDs remain stable for repeat-restore idempotency; folder IDs are remapped on collision; page/element IDs are regenerated; element rows use ABORT insert | Source-level safeguards; collision/fault-injection tests pending |
| Preserve relationships | First metadata pass validates unique IDs and folder→note→page→element references before file/database mutation | Source-level validation; malformed archive test suite pending |
| Roll back failed restore | Install blobs before Room transaction; on failure delete only newly installed unreferenced blobs; keep pre-existing/shared blobs | Partial atomicity; process death can leave an orphan until future reconciliation |
| Preserve legacy JSON restore | Kept JSON picker and format; hardened parser and remapped folder/page/element IDs; insert-only element writes | Source implemented; regression tests pending |

Version: 0.5.0 / versionCode 23. Build, JUnit, Room instrumentation, process-death, storage-full and physical-device testing were not run. ZIP restore is not yet verified for production use.


### v72 source verification record
- XML: 6/6 parsed.
- Arabic/English string resources: 138/138 matching keys, no duplicates.
- Source assertions passed for ZIP SAF integration, metadata relationship checks, exact archive blob-reference matching, idempotent note-ID collision behavior, page/element remapping and insert-only writes.
- Standalone Kotlin archive/storage smoke test passed: streaming archive round-trip, SHA-256 validation and same-length corrupted blob repair.
- Android Gradle/Compose, JUnit, Room integration, process-death/storage failure and device tests were not run.


## v73 — orphan attachment reconciliation (2026-11-16)
| Requirement | Implementation | Status / remaining validation |
|---|---|---|
| Derive live attachment references from Room | Read all `note_elements`; decode all known media element payloads; deduplicate by SHA-256 + extension | Source implemented; Room/JVM execution pending |
| Fail closed on corrupt media metadata | Any undecodable media payload or unknown element type makes the snapshot unsafe and disables attachment-blob deletion | Source implemented; regression test added, not executed |
| Match stored blobs safely | Only exact `<hash>.<extension>` files in the matching two-character shard and canonical app-private attachment path are candidates; file bytes must hash to filename hash | Source implemented; JVM execution pending |
| Protect recent and shared files | 24-hour grace period; all live reference keys preserved, including references shared by multiple elements | Source implemented; regression tests added, not executed |
| Protect unknown paths/names | Unexpected files, folders, symlinks, malformed names and mismatched content hashes are skipped | Source implemented; regression tests added, not executed |
| Clean import temporary files | Only old `import-*.part` and `damaged-*.bak` files in the app's `.tmp` directory are eligible | Source implemented; regression test added, not executed |
| Serialize with repository operations | Same repository `Mutex` covers Room snapshot and file reconciliation; file work uses `Dispatchers.IO` | Source implemented; concurrency instrumentation pending |
| Avoid restore interference | Both restore paths use the same mutex; reconciliation runs only after acquiring it | Source-reviewed; process-death and restore integration tests pending |
| Report cleanup outcome | Structured cleaned/skipped/error counts plus unsafe-reference flag; startup logs result | Source implemented; Android runtime verification pending |

App version: 0.5.1 / versionCode 24. No database schema change. The requested filesystem-failure and ZIP-restore repeated-import integration cases remain untested pending a configured Room/Android test environment.

### v73 verification record
- Added JUnit tests for the core file/reference reconciliation cases; tests were **not run** because Gradle/Gradle wrapper JAR and Kotlin compiler are unavailable in the environment.
- Static/resource/archive checks and v72→v73 diff review are recorded in `AUDIT_REPORT.md`.
- No Android build, Room instrumentation, process-death/storage-full fault injection, or physical-device test is claimed.


## v74 — storage boundary and archive extraction regression coverage (2026-11-16)
| Requirement | Implementation / test | Status / remaining validation |
|---|---|---|
| Never traverse outside app-private attachment storage during reconciliation | Added regression coverage for symlinked shard and blob paths; existing canonical-parent checks remain unchanged | Production storage source compiled and standalone smoke case passed; JUnit execution pending |
| Reject ZIP path traversal | Added test for `../escape.txt`; extraction must reject and clear staging without writing outside it | Archive codec compiled and standalone malicious-archive smoke case passed; JUnit execution pending |
| Preserve existing restore semantics | No changes to repository restore, Room entities/DAOs, transaction logic, or backup schema | Source diff confirms no restore behavior changes; Room/device fault injection remains pending |

App version: 0.5.2 / versionCode 25. No database migration. Five standalone Kotlin smoke checks passed; no Gradle/JUnit/Android/device result is claimed.


## v75 — Arabic-aware local search refinement (2026-11-16)

| Requirement | v75 implementation | Status / remaining validation |
|---|---|---|
| Search note titles and text | Library comparison now uses a shared Unicode-aware normalizer for title and stored searchable body text | Source implemented; JUnit and device search tests not executed |
| Search Arabic without exact diacritic entry | Combining marks and tatweel are ignored for matching | Source and test cases added; broader Arabic corpus validation pending |
| Tolerate common Arabic spelling/input variants | Alef variants (`آ`, `أ`, `إ`, `ٱ`) compare as `ا`; alef-maqsura (`ى`) compares as ya (`ي`) | Source and test cases added; linguistic review pending |
| Search folders consistently | Folder names use the same normalized comparison as notes | Source implemented; Compose/device validation pending |
| Preserve user-authored content | Normalization is applied only to temporary comparison strings; Room content and backup data are untouched | Source review; no DB/schema/payload change |
| Preserve existing app data and restore guarantees | No Room schema, migration, DAO, entity, attachment, backup, or restore implementation changed | Source diff review; integration/device tests remain pending |

App version: 0.5.3 / versionCode 26. Room schema remains version 4. No migration.

### v75 verification record
- v74 input ZIP CRC/integrity: PASS (60 entries).
- ZIP path and duplicate-entry checks: PASS.
- Source wiring/version/schema assertions: PASS.
- All project XML resources parsed; Arabic/English string resources retain 138 matching keys with no duplicates.
- Four new JUnit test cases were added but not executed.
- Gradle, Kotlin compilation, Compose, APK, lint, Room/instrumentation and physical-device tests were not run because Gradle, wrapper scripts/JAR, `kotlinc`, Android SDK and ADB are unavailable in this environment.

### Traceability boundary
This v75 change improves only the matching behavior of existing local search. It does not implement OCR, handwriting search, rich text, inline image editing, PDF import/annotation, audio/video, note encryption, or full production verification. Existing v74 storage/restore validation limitations remain in force.


## v76 — parity baseline and execution plan (2026-11-16)
| Requirement | v76 action | Status / remaining validation |
|---|---|---|
| Preserve existing notes and features | No production Kotlin, schema, migration, payload or backup format changed | Source diff confirms documentation/version-only changes |
| Establish Samsung Notes parity scope with original ELIOS identity | Added source-backed feature matrix and v77–v83 release gates | Planning baseline; parity is not yet achieved |
| Deliver handwriting recognition and beautification | Recorded separate reversible requirements; identified existing ML Kit path and gaps | Recognition is partial; beautification not implemented; accuracy not measured |
| Local-only phone/tablet product | Recorded local-first/no-cloud constraint, manual transfer requirement and adaptive device scope | Existing local storage exists; full-device validation pending |

App version: 0.5.4 / versionCode 27. Room schema remains version 4. No migration.

### v76 verification record
- v75 input archive integrity: PASS (62 entries).
- XML parse and Arabic/English resource parity: PASS (138 matching keys).
- Static source and diff assertions: PASS.
- Gradle/JUnit/Android/Room/device validation: NOT RUN; no Gradle executable, wrapper scripts/JAR, Android SDK or ADB available.

### Traceability boundary
v76 documents the baseline and plan only. It does not claim implementation of handwriting beautification, zoom, rich text, PDF import/annotation, media playback/recording, or full device compatibility.


## v77 traceability update

- Page insertion at a chosen position: `PageOrderPolicy.insert`, `NotesRepository.insertPageAt`, `EditorSession.insertPageAt`, editor menu actions.
- Page reordering: `PageOrderPolicy.move` / `reorderByIds`, `NotesRepository.reorderPages`, `EditorSession.movePage`, editor menu actions.
- Viewport zoom/pan: transient `zoomScale` and `panOffset` in `EditorScreen`; no stored geometry is rewritten.
- Regression safeguards: page identity and content remain attached to page IDs; repository operations are transactional; `PageOrderPolicyTest` covers ordering rules.
- Not implemented in v77: page duplication, drag-and-drop sorter, thumbnails, cross-page text flow, and real-device gesture validation.


## v78 traceability update

- CI quality gates: `.github/workflows/build-apk.yml` runs lint, JVM tests, debug assembly, Room schema export assertion, and emulator instrumentation tests. Workflow configured; remote execution not yet observed.
- Room page transaction regression: `NotesRepositoryPageTransactionTest` exercises repository insert/reorder against in-memory Room, checks stable IDs and opaque element preservation, and verifies invalid reorder rollback behavior. Test added; not executed locally.
- Pure page presentation preservation: `PageOrderPolicyTest.insertPreservesPagePresentationSettings`. Test added; not executed locally.
- Room schema version remains v4; no migration or production persistence code change in v78.
- Not implemented: thumbnail sorter, drag-and-drop page reorder, safe page duplication, cross-page text flow, stylus tilt/button support, handwriting beautification.


## v79 traceability — document page management

| Requirement | v79 implementation | Evidence / status |
|---|---|---|
| Navigate a multi-page note visually | Page overview dialog with previews and page summaries | Source added; Android UI build/device verification pending |
| Reorder pages without losing content | Explicit move-up / move-down controls use existing stable-ID repository reorder transaction | Existing repository path retained; device verification pending |
| Duplicate a page completely | New page and element identities; page metadata and payload fields copied transactionally | Room instrumentation tests added; not run locally |
| Preserve future/unknown payloads | Payload JSON and version copied verbatim without decoding | Instrumentation regression test added; not run locally |
| Preserve media after duplication | Attachment reference payload shared; existing blob reference count governs deletion | Instrumentation test covers reference payload and shared-blob lifetime; execution awaits CI |
| Avoid Room migration risk | Existing Room v4 schema retained | Source inspection; KSP schema generation awaits CI |
| Produce GitHub build artifact | Workflow builds debug APK and uploads SHA-256 | Workflow configured; not yet executed / green |


## v80 traceability — page drag reorder and stylus input arbitration

| Requirement | v80 implementation | Evidence / status |
|---|---|---|
| Reorder pages by touch gesture | Dedicated long-press drag handle in page overview; target row detection and edge auto-scroll | Compose source implemented; emulator/physical-device gesture tests not run |
| Preserve page identity and content during reorder | Complete stable-ID order validation; save barrier; Room transaction; observable order updates only after commit | Existing repository transaction reused; new policy test added, Gradle/Room execution pending |
| Keep arrow reordering available | Existing move-up/down actions now use the same awaited persistence path | Source implemented; UI runtime pending |
| Distinguish stylus from touch input | Pure `InkPointerPolicy` shared by ink and lasso input layers | Five policy tests added; 13 standalone executable assertions passed; Android pointer dispatch pending |
| Suppress simultaneous palm-like touch while pen is active | Concurrent touch pointers are consumed during active stylus/eraser gesture | Limited mitigation only; isolated palm classification and hardware behavior remain unverified |
| Preserve stored data compatibility | No Room schema, element payload, attachment or backup format change | Source diff; Room schema remains v4 |
| Build directly from a ZIP stored in GitHub | Separate bootstrap workflow validates archive, extracts it and runs CI/build/emulator tests | Workflow authored; remote GitHub run not yet observed |

App version: 0.5.8 / versionCode 31. Room schema v4; no migration.


## v81 traceability — per-page paper and expanded templates

| Requirement | v81 implementation | Evidence / status |
|---|---|---|
| Independent page backgrounds | `EditorSession.setBackground(pageId, argb)` and `PagePresentationPolicy.withBackground` update only the selected page | Pure policy smoke 7/7; Room/Compose persistence integration pending CI |
| Independent page templates | Selected-page template update; supported IDs include BLANK, RULED, GRID, DOTS, MUSIC, CORNELL, ISOMETRIC, PLANNER | Five JUnit cases added; standalone policy smoke passed; visual rendering pending device/PDF checks |
| Useful paper templates | `PageBackgrounds` draws music staff, Cornell layout, isometric grid and planner grid | Source implemented; visual review on phone/tablet and PDF pending |
| Preserve non-empty content during orientation change | Validated orientation policy applies only to selected empty page | Pure policy smoke passed; integration test pending |
| Reject unknown template selection | `PagePresentationPolicy.withTemplate` rejects unsupported requested IDs; renderer leaves unknown persisted values visually blank | Pure policy smoke passed; forward-compatibility review recorded |
| ZIP-to-APK handoff version consistency | Bootstrap expects v81 archive and verifies versionName/versionCode after safe extraction | YAML parse passed; malicious and valid archive execution tests pending GitHub CI |

App version: 0.5.9 / versionCode 32. Room schema v4; no migration.


## v82 traceability — handwriting smoothing and build contract

| Requirement | v82 implementation | Evidence / status |
|---|---|---|
| Handwriting beautification is separate from Ink-to-Text | New geometry-only `InkBeautifier`; does not call recognition/OCR | Pure Kotlin compile and 4 focused test methods passed using a temporary assertion harness; Arabic/English visual/device corpus still pending |
| Preview before applying | Before/after stroke preview with Light / Medium / Strong selection | Compose source added; Android/Compose compilation and UI interaction not run |
| Preserve original and undo | Immutable input, stable stroke IDs/style/endpoints; Apply enters existing EditorSession undo stack | Core behavior tested; integrated undo/redo and Room persistence require Android tests |
| API target contract | Explicit `minSdk 23`, `targetSdk 36` | Source inspection; Gradle build not run |
| Safe source ZIP build | v82 bootstrap pins archive/version and validates paths, duplicates, type conflicts, size and CRC | Local fixture checks recorded in V82_PHASE7_REPORT.md; remote GitHub Actions not observed |

App version: 0.6.0 / versionCode 33. Room schema v4; no migration.

### Remaining original-specification requirements

Rich text, PDF import/annotation/page manipulation, audio recording/playback and time-linked notes, video playback, tags, note locking/encryption, full stylus tilt/buttons and reliable device palm rejection remain incomplete or unverified. The custom ink engine has not been replaced with the specified Jetpack Ink 1.0.0 integration. Phone/tablet and cross-vendor physical-device QA remains outstanding.
